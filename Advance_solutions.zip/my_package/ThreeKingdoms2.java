package my_package;

import java.util.Arrays;
import java.util.Scanner;

import my_util.DynamicArray;
import my_util._Queue;

public class ThreeKingdoms2 {
	static int[][] map;
	static double[][] distance;
	static int[][] ourCastle;
	static DynamicArray<DynamicArray<int[]>> otherKingdoms;
	
	private static int cost(int cell) {
		if(cell==0) return 1;
		else if(cell==1) return 3;
		else if(cell==2) return 5;
		else if(cell==4) return 3;
		else if(cell==6) return 3;
		else return -1;
	}
	private static void minDistanceToAllZone() {
		_Queue<int[]> q = new _Queue<>(1000);
		for(int[] root: ourCastle) {
			q.add(root);
			distance[root[0]][root[1]] = 0;
		}
		
		int[][] directions = {{1,0},{-1,0},{0,1},{0,-1}};
		while(!q.isEmpty()) {
			int[] cur = q.poll();
			int x = cur[0], y = cur[1];
			
			for(int[] d: directions) {
				int dx = d[0], dy = d[1];
				
				if(!isOutOfBound(x+dx, y+dy) && cost(map[x+dx][y+dy]) != -1 ) {
					double cur_dist = distance[x][y] + (cost(map[x][y]) + cost(map[x+dx][y+dy]))/2.0;
				    if(cur_dist < distance[x+dx][y+dy]) {
						q.add(new int[] {x+dx,y+dy});
						distance[x+dx][y+dy] = cur_dist;
					}
				}
			}
		}
		
	}
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=map.length || y>=map[0].length);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++) {	
			int N = sc.nextInt();
			int K = sc.nextInt();
			
			
			otherKingdoms = new DynamicArray<>();
			for(int k=0; k<K; k++) {
				if(k==0) {
					int C = sc.nextInt();
					ourCastle = new int[C][2]; // toa do cac castle cua ta
					
					for(int c=0; c<C; c++) {
						ourCastle[c][0] = sc.nextInt() - 1;
						ourCastle[c][1] = sc.nextInt() - 1;
					}
				}
				else {
					int C = sc.nextInt();
					DynamicArray<int[]> kingdom = new DynamicArray<>();
					for(int c=0; c<C; c++) {
						int x = sc.nextInt();
						int y = sc.nextInt();
						kingdom.add(new int[] {x-1,y-1});
					}
					otherKingdoms.add(kingdom);
				}
				
			}
			
			map = new int[N][N];
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					map[i][j] = sc.nextInt();
				}
			}
			// distance map init
			distance = new double[N][N];
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					distance[i][j] = 9999;
				}
			}
			
			minDistanceToAllZone();
			
			// Print the answer to standard output(screen).
			System.out.print("\n#"+test_case+" ");
			for(int i=0; i<otherKingdoms.size(); i++) {
				int sum = 0;
				for(int j=0; j<otherKingdoms.get(i).size(); j++) {
					int x = otherKingdoms.get(i).get(j)[0];
					int y = otherKingdoms.get(i).get(j)[1];
					sum += distance[x][y];
				}
				System.out.print(sum+" ");
			}
		}
		sc.close();
	}

}
