package my_package;

import java.util.Arrays;

public class BabyGin {
	public static boolean babyGin(int[] cards) {
		int[] count = new int[10];
		for(int n: cards) {
			count[n]++;
		}
		
		int numTriplete = 0, numRun = 0;
		for(int i=0; i<10; i++) {
			if(count[i]>=3) {// c� trip
				count[i] -= 3;
				numTriplete++;
				i--;
			}
		}
		
		for(int i=1; i<9; i++) {
			if(count[i-1]!=0 && count[i]!=0 && count[i+1]!=0) {// c� run
				numRun++;
				count[i-1]--;
				count[i]--;
				count[i+1]--;
				i--;
			}
		}
		return (numTriplete+numRun==2);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] A = {1,2,2,3,3,4};
		System.out.println(babyGin(A));
	}

}
