package my_package;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PancakeSorting {
	public static int[] pancakeSort(int[] arr) {
		int j=arr.length;
		int[] result = new int[arr.length];

		while(j > 0) {
			int max_index = argmax(arr, 0, j);
			flip(arr, max_index+1);
			flip(arr, j);
			result[j-1] = arr[j-1];
			j--;
			//System.out.println(Arrays.toString(result));
		}
		return result;
	}
	public static int argmax(int[] arr, int start, int end) { // Tim chi so phan tu max trong khoang start -> end (exclude)
		int max = -9999;
		int argmax = 0;
		for(int i=start; i<end; i++) {
			if(arr[i] > max) {
				max = arr[i];
				argmax = i;
			}
		} 
		return argmax;
	}
	public static void flip(int[] arr, int k) { // dao nguoc k phan tu dau tien
		int i=0, j=k-1;
		while(i < j) {
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			i++; j--;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] A = {2,5,6,1,64,33,21,65,75};
		System.out.println(Arrays.toString(pancakeSort(A)));
	}

}
