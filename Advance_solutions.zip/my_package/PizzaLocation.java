package my_package;

import java.util.Scanner;

public class PizzaLocation {
	static int numRes;
	static int RADIUS;
	
	static int numLoc;
	static int[] xLoc, yLoc;
	
	static int numHouse;
	static int[] xHouse, yHouse;
	static int[] houseChecked;
	static int[] people;
	static int maxPeople;
	static int total;
	
	static boolean[] located;
	static double[][] distance;    // [location][house]
	
	public static void backtrack(int index, int location) {
		if(index==numRes) {
			maxPeople = Math.max(maxPeople, total);
			return;
		}
		for(int j=location; j<numLoc; j++) {
			if(!located[j]) {
				placeRestaurant(j);
				backtrack(index+1, j);
				removeRestaurant(j);
			}
		}
	}
	private static void placeRestaurant(int location) {
		located[location] = true;
		for(int j=0; j<numHouse; j++) {
			if(distance[location][j] <= RADIUS) {
				if(houseChecked[j]==0)
					total += people[j];
				houseChecked[j]++;
			}
		}
	}
	private static void removeRestaurant(int location) {
		located[location] = false;
		for(int j=0; j<numHouse; j++) {
			if(distance[location][j] <= RADIUS) {
				if(houseChecked[j]==1)
					total -= people[j];
				houseChecked[j]--;
			}
		}
	}
	private static void calcDistance() {
		for(int i=0; i<numLoc; i++) {
			int x1=xLoc[i], y1=yLoc[i];
			for(int j=0; j<numHouse; j++) {
				int x2=xHouse[j], y2=yHouse[j];
				distance[i][j] = Math.sqrt(Math.pow(x1-x2, 2) + Math.pow(y1-y2, 2));
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			numRes = sc.nextInt();
			RADIUS = sc.nextInt();
			numLoc = sc.nextInt();
			
			xLoc = new int[numLoc];
			yLoc = new int[numLoc];
			for(int i=0; i<numLoc; i++) {
				xLoc[i] = sc.nextInt();
				yLoc[i] = sc.nextInt();
			}
			
			numHouse = sc.nextInt();
			houseChecked = new int[numHouse];
			xHouse = new int[numHouse];
			yHouse = new int[numHouse];
			people = new int[numHouse];
			for(int i=0; i<numHouse; i++) {
				xHouse[i] = sc.nextInt();
				yHouse[i] = sc.nextInt();
				people[i] = sc.nextInt();
			}
			
			total=0;
			maxPeople = 0;
			
			located = new boolean[numLoc];
			distance = new double[numLoc][numHouse];
			
			calcDistance();
			backtrack(0, 0);
			
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+ maxPeople);
		}
		sc.close();
	}
}
