package my_package;

import java.util.Arrays;
import java.util.Scanner;

import my_util._Stack;

public class PasswordGenerator {
	public static void generate(int[] nums) {		
		while(true) {
			int minus = 1;
			for(int i=0; i<8; i++) {
				if(minus>5) {
					shiftLeft(nums, i);
					break;
				}
				
				nums[i] = nums[i] - minus;
				if(nums[i] <= 0) {
					nums[i] = 0;
					shiftLeft(nums, i+1);
					return ;
				};
				minus++;
			}
		}
	}
	private static void shiftLeft(int[] nums, int steps) {
		int N = nums.length;
		int[] temp = new int[2*N];
		for(int i=0; i<temp.length; i++) {
			temp[i] = nums[i%N];
		}
		for(int i=0; i<nums.length; i++) {
			nums[i] = temp[steps++];
		}
	}
	public static String toString(int[] nums) {
		String res = "";
		for(int i=0; i<nums.length-1; i++) {
			res += nums[i] + " ";
		}
		res += nums[nums.length-1]+"";
		return res;
	}

	public static String generate2(String s) {
		_Stack<Character> stack = new _Stack<>(100);
		char[] chr = s.toCharArray();
		stack.push(chr[0]);
		
		for(int i=1; i<chr.length; i++) {
			if(chr[i] == stack.peek()) {
				stack.pop();
				continue;
			}
			stack.push(chr[i]);
		}
		
		if(stack.isEmpty()) return null;
		char[] pass = new char[stack.size()];
		for(int i=pass.length-1; i>=0; i--) {
			pass[i] = stack.pop();
		}
		return new String(pass);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=10;

		for(int test_case = 1; test_case <= T; test_case++)
		{
			sc.nextInt();
			String input = sc.nextLine();
			
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+ generate2(input));
		}
		sc.close();
	}

}
