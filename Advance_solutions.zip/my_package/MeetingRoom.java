package my_package;

import java.util.Scanner;

import my_util._Array;

public class MeetingRoom {
	public static int assignRooms(int[][] times) {
		int[] startTimes = new int[501];
		int[] finishTimes = new int[times.length];
		for(int i=0; i<times.length; i++) {
			finishTimes[i] = times[i][1];
			startTimes[finishTimes[i]] = times[i][0];
		}
		
		_Array.sort(finishTimes, 0, finishTimes.length-1);
		
		int ans=1;
		int prev_end = finishTimes[0];
		for(int i=1; i<finishTimes.length; i++) {
			int start = startTimes[finishTimes[i]];
			if(start >= prev_end) {
				ans++;
				prev_end = finishTimes[i];
			}
		}
		return ans;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int[][] times = new int[N][2];
			for(int i=0; i<N; i++) {
				sc.nextInt();
				times[i][0] = sc.nextInt();
				times[i][1] = sc.nextInt();
			}
			// Print the answer to standard output(screen).
			System.out.println("Case "+"#" + test_case+"\n" + assignRooms(times));
		}
		sc.close();
	}

}
