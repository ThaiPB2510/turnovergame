package my_package;

import java.util.Arrays;
import java.util.Scanner;

public class GNS {
	public static int convert(String code) {
		if(code.equals("ZRO"))
			return 0;
		else if(code.equals("ONE"))
			return 1;
		else if(code.equals("TWO"))
			return 2;
		else if(code.equals("THR"))
			return 3;
		else if(code.equals("FOR"))
			return 4;
		else if(code.equals("FIV"))
			return 5;
		else if(code.equals("SIX"))
			return 6;
		else if(code.equals("SVN"))
			return 7;
		else if(code.equals("EGT"))
			return 8;
		else if(code.equals("NIN"))
			return 9;
		return -1;
	}
	public static String convertBack(int n) {
		if(n==0) return "ZRO";
		else if(n==1) return "ONE";
		else if(n==2) return "TWO";
		else if(n==3) return "THR";
		else if(n==4) return "FOR";
		else if(n==5) return "FIV";
		else if(n==6) return "SIX";
		else if(n==7) return "SVN";
		else if(n==8) return "EGT";
		else if(n==9) return "NIN";
		return "";
	}
	public static String sortGNS(String s) {
		String[] arr = s.split(" ");
		int[] freq = new int[10];
		
		for(String t: arr) {
			freq[convert(t)]++;
		}
		String ans = "";
		int endHere = 10;
		for(int i=9; i>=0; i--) {
			if(freq[i] > 0) break;
			endHere = i;
		}
		for(int i=0; i<= ((endHere==10)? 9: endHere); i++) {
			int k = freq[i];
			while(k-- > 0) {
				if(i==endHere && k==1) {
					ans += convertBack(i);
					break;
				}
				ans += convertBack(i) + " ";
			}
		}
		//System.out.println(ans);
		return ans;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		sc.nextLine();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			sc.nextLine();
			String input = sc.nextLine();
			
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+"\n"+sortGNS(input));
		}
		sc.close();
		
	}

}
