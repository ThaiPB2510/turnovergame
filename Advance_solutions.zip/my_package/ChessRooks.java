package my_package;

import java.util.Scanner;

public class ChessRooks {
	static char[][] board;
	static int[][] mask;
	static int maxCount = 0;
	static int count=0;
	static int N;
	
	public static void backtrack(int row, int col) {
		if(row==N-1) {
			maxCount = Math.max(count, maxCount);
			return;
		}
		
		for(int r=row; r<N; r++) {
			for(int c=0; c<N; c++) {
				if(r==row && c==col) continue; 
				if(board[r][c]=='.' && !isUnderAttack(r, c)) {
					placeRook(r, c);
					backtrack(r, c);		
					removeRook(r, c);
				}
			}
		}
		
	}
	private static boolean isUnderAttack(int r, int c) {
		return mask[r][c] < 0;
	}
	private static void placeRook(int r, int c) {
		count++;
		
		int i = r+1;
		while(i<N && board[i][c]!='X') mask[i++][c]--;
		i = r-1;
		while(i>=0 && board[i][c]!='X') mask[i--][c]--;
		
		int j = c+1;
		while(j<N && board[r][j]!='X') mask[r][j++]--;
		j = c-1;
		while(j>=0 && board[r][j]!='X') mask[r][j--]--;
	}
	private static void removeRook(int r, int c) {
		count--;
		int i = r+1;
		while(i<N && board[i][c]!='X') mask[i++][c]++;
		i = r-1;
		while(i>=0 && board[i][c]!='X') mask[i--][c]++;
		
		int j = c+1;
		while(j<N && board[r][j]!='X') mask[r][j++]++;
		j = c-1;
		while(j>=0 && board[r][j]!='X') mask[r][j--]++;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			N = sc.nextInt();
			sc.nextLine();
			board = new char[N][N];
			mask = new int[N][N];
			count = 0;
			maxCount = 0;
			
			for(int i=0; i<N; i++) {
				board[i] = sc.nextLine().toCharArray();
//				sc.nextLine();
			}
			
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					if(board[i][j]=='.') {
						placeRook(i, j);
						backtrack(i, j);
						removeRook(i, j);
					}
				}
			}
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+maxCount);
			
		}
		sc.close();
	}
/*
5
4
.X..
....
XX..
....
2
XX
.X
3
.X.
X.X
.X.
3
...
.XX
.XX
4
....
....
....
....
*/
}
