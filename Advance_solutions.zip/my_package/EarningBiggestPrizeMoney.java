package my_package;

import java.util.Scanner;

import my_util.MaxHeap;
import my_util._Array;
import my_util._HashMap;

public class EarningBiggestPrizeMoney {
	static String max = "0";
	public static void findBiggestNumber(String s, int k) {
		if(Integer.parseInt(s) > Integer.parseInt(max))
			max = new String(s);
		
		if(k==0) return;
		
		for(int i=0; i<s.length()-1; i++) {
			for(int j=i+1; j<s.length(); j++) {
				if(s.charAt(j) > s.charAt(i)) {
					s = swap(s, i, j);
					findBiggestNumber(s, k-1);
					s = swap(s, i, j);
				}
			}
		}
	}
	private static String swap(String s, int i, int j) {
		char[] chr = s.toCharArray();
		char temp = chr[i];
		chr[i] = chr[j];
		chr[j] = temp;
		return new String(chr);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int input = sc.nextInt();
			int k = sc.nextInt();
			String s = input+"";
			max = "0";
			findBiggestNumber(s, k);
			// Print the answer to standard output(screen).
			System.out.println("Case #" + test_case+"\n"+max);
		}
		sc.close();
	}

}