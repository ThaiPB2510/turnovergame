package my_package;

import java.util.Arrays;
import java.util.Scanner;

public class UpgradePC {
	static int[] marketPrice;    // [coupon][device], coupon 0 means market price
	static int[] couponPrice;
	static boolean[] used;     // kiem tra coupon da dc dung chua
	static int[] needs;			// list necessary devices
	static int[][] adj_matrix;
	static int ans;
	
	public static void backtrack(int index, int cost) {
		if(cost>ans) return;
		if(index==needs.length) {
			if(cost<ans) {
				ans = cost;
			}
			return;
		}
		
		// mua bang goi khuyen mai
		for(int coupon=-1; coupon<couponPrice.length; coupon++) {
			if(coupon==-1)  {  // mua tren cho Troi
				backtrack(index+1, cost+marketPrice[needs[index]]);
				continue;
			}
			
			if(adj_matrix[coupon][needs[index]]==1) {
				if(used[coupon]) 
					backtrack(index+1, cost);
				else {
					used[coupon] = true;
					backtrack(index+1, cost + couponPrice[coupon]);
					used[coupon] = false;
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			marketPrice = new int[N];
			for(int i=0; i<N; i++) {
				marketPrice[i] = sc.nextInt();
			}
			
			int M = sc.nextInt();
			couponPrice = new int[M];
			used = new boolean[M];
			adj_matrix = new int[M][N];
			for(int i=0; i<M; i++) {
				couponPrice[i] = sc.nextInt();
				int numDevices = sc.nextInt();
				for(int j=0; j<numDevices; j++) {
					int device = sc.nextInt();
					adj_matrix[i][device-1] = 1;
				}
			}
			
			int L = sc.nextInt();
			needs = new int[L];
			for(int i=0; i<L; i++) {
				needs[i] = sc.nextInt()-1;
			}

			ans = 99999;
			backtrack(0,0);
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+ans);
		}
		sc.close();
	}
/*
1
5
20 15 17 18 25
4
30 3 1 2 5
25 2 2 3
35 3 1 3 5
20 2 3 4
3 2 4 5
 */
}