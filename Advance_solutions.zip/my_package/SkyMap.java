package my_package;

import java.util.Scanner;

import my_util._Stack;

public class SkyMap {
	static int[][] sky;
	static int maxStars = 0;
	public static int countConstellations() {
		int N = sky.length;
		int ans = 0;
		for(int i=0; i<N; i++) {
			for(int j=0; j<N; j++) {
				if(sky[i][j]==1) {
					DFS(i,j, 1);
					ans++;
				}
			}
		}
		return ans;
	}
	private static void DFS(int x, int y, int count) {
		_Stack<int[]> st = new _Stack<>(2500);
		st.push(new int[] {x,y});
		sky[x][y] = 0;
		
		int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
		while(!st.isEmpty()) {
			int[] cur = st.pop();
			x = cur[0];
			y= cur[1];
			
			for(int[] d: directions) {
				int dx=d[0], dy=d[1];
				if(!isOutOfBound(x+dx, y+dy) && sky[x+dx][y+dy]==1) {
					st.push(new int[] {x+dx, y+dy});
					sky[x+dx][y+dy] = 0;
					count++;
				}
			}
		}
		maxStars = Math.max(maxStars, count);
	}
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=sky.length || y>=sky[0].length);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			sky = new int[N][N];
			maxStars = 0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					sky[i][j] = sc.nextInt();
				}
			}
			
			int ans = countConstellations();
			// Print the answer to standard output(screen).
			System.out.println(ans+" "+maxStars);
		}
		sc.close();
	}

}
