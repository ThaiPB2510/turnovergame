package my_package;
import java.util.Arrays;
import java.util.Scanner;

import my_util._String;
import my_util._String.*;

public class Palindrome2 {
	public static int findLongestPalindrome(String text) {
        int N = text.length();
        if (N < 2) 	return N;
        
        N = 2 * N + 1; // Position count
        int[] L = new int[N + 1]; // LPS Length Array
        L[0] = 0;
        L[1] = 1;
        int C = 1, R=2, i=0; // centerPosition, centerRightPosition, currentRightPosition
        int iMirror; // currentLeftPosition
        int maxLPSLength = 0;
        int maxLPSCenterPosition = 0;
        int start = -1, end=-1, diff=-1;
       
        for (i = 2; i < N; i++) {
            iMirror = 2 * C - i;
            L[i] = 0;
            diff = R - i;
 
            if (diff > 0)
                L[i] = Math.min(L[iMirror], diff);
 
            while (((i + L[i]) + 1 < N && (i - L[i]) > 0) &&
                               (((i + L[i] + 1) % 2 == 0) ||
                         (text.charAt((i + L[i] + 1) / 2) ==
                          text.charAt((i - L[i] - 1) / 2)))) {
                L[i]++;
            }
 
            if (L[i] > maxLPSLength) // Track maxLPSLength
            {
                maxLPSLength = L[i];
                maxLPSCenterPosition = i;
            }
 
            if (i + L[i] > R) {
                C = i;
                R = i + L[i];
            }
        }
 
//        start = (maxLPSCenterPosition - maxLPSLength) / 2;
//        end = start + maxLPSLength - 1;
        return maxLPSLength;
    }
	public static int solve(char[][] board) {
		int N = board.length;
		int maxLen = 0;
		
		for(char[] row: board) {
			maxLen = Math.max(maxLen, findLongestPalindrome(new String(row)));
			if(maxLen==N) return maxLen;
		}
		for(int j=0; j<N; j++) {
			char[] col = new char[N];
			for(int i=0; i<N; i++) {
				col[i] = board[i][j];
			}
			
			maxLen = Math.max(maxLen, findLongestPalindrome(new String(col)));
			if(maxLen==N) return maxLen;
		}
		return maxLen;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=10;
		
		for(int test_case = 1; test_case <= T; test_case++) {
			sc.nextLine();
			char[][] board = new char[100][100];
			for(int i=0; i<100; i++) {
				board[i] = sc.nextLine().toCharArray();
			}
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+ solve(board));
		}
	}

}
