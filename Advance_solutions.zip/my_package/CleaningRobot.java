package my_package;

import java.util.Arrays;
import java.util.Scanner;

import my_util._Queue;

public class CleaningRobot {
	static int N,M;
	static final int CLEAN=0, DIRTY=1, OBS=2, START=3;
	static int[][] map;
	
	static int[][] dirtyTiles;     //[index][toa do gach ban]
	static int[][] distance;		// [index 1][index 2]
	static boolean[] cleaned;		//[index dirty tile]
	static _Queue<Integer> qx;
	static _Queue<Integer> qy;
	static int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
	static int ans;
	
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=N || y>=M);
	}
	private static int minMoves(int start, int end) {
		qx = new _Queue<>(500);
		qy = new _Queue<>(500);
		boolean[][] visited = new boolean[N][M];
		
		int x=dirtyTiles[start][0], y=dirtyTiles[start][1];
		qx.add(x);
		qy.add(y);
		visited[x][y] = true;
		
		int step=0;
		while(!qx.isEmpty()) {
			int size = qx.size();
			for(int i=0; i<size; i++) {
				x = qx.poll();
				y = qy.poll();
				if(x==dirtyTiles[end][0] && y==dirtyTiles[end][1]) {
					return step;
				}
				
				for(int[] d: directions) {
					int newX = x+d[0];
					int newY = y+d[1];
					if(!isOutOfBound(newX, newY) && !visited[newX][newY] && map[newX][newY]!=OBS) {
						visited[newX][newY] = true;
						qx.add(newX);
						qy.add(newY);
					}
				}
			}
			step++;
		}
		return -1;
	}
	public static void calcDistance() {
		for(int i=0; i<dirtyTiles.length-1; i++) {
			for(int j=i+1; j<dirtyTiles.length; j++) {
				distance[i][j] = distance[j][i] = minMoves(i, j);
			}
		}
	}
	public static void backtrack(int index, int numCleaned, int cur_moves) {
		if(numCleaned==dirtyTiles.length-1) {
			ans = Math.min(ans, cur_moves);
			return;
		}
		
		for(int next=1; next<dirtyTiles.length; next++) {
			if(!cleaned[next] && distance[index][next]!=-1) {
				cleaned[next] = true;
				
				backtrack(next, numCleaned+1, cur_moves+distance[index][next]);
				
				cleaned[next] = false;
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			N = sc.nextInt();
			M = sc.nextInt();
			map = new int[N][M];
			int numDirt=0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<M; j++) {
					map[i][j] = sc.nextInt();
					if(map[i][j]==DIRTY)
						numDirt++;
				}
			}
			
			dirtyTiles = new int[numDirt+1][2];    // toa do cac dirty tile (+ o xuat phat)
			distance = new int[numDirt+1][numDirt+1];     // khoang cach cac gach ban voi nhau, index 0 la o xuat phat
			cleaned = new boolean[numDirt+1];
			int k=1;
			for(int i=0; i<N; i++) {
				for(int j=0; j<M; j++) {
					if(map[i][j]==START)
						dirtyTiles[0] = new int[] {i,j};
					if(map[i][j]==DIRTY) {
						dirtyTiles[k++] = new int[]{i,j};
					}
				}
			}
			
			ans =9999;
			calcDistance();
			cleaned[0] = true;
			backtrack(0, 0, 0);
			
			// Print the answer to standard output(screen).
			if(ans==9999) ans = -1;
			System.out.println("Case #"+test_case+"\n"+ans);
		}
		sc.close();
	}
/*
1
5 7
0 0 0 0 0 0 0
0 3 0 0 0 1 0
0 0 0 0 0 0 0
0 1 0 0 0 1 0
0 0 0 0 0 0 0
 */
}
