package my_package;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SVMCName {
	static Set<String> data = new HashSet<>();
	public static String[] generateAll(String[] names) {
		String[] result = new String[names.length];
		Map<String, Integer> id_map = new HashMap<>();
		
		for(int i=0; i<names.length; i++) {
			String nameID = generateID(names[i]);
			
			if(id_map.containsKey(nameID)) {
				id_map.put(nameID, id_map.get(nameID) + 1);
				nameID = nameID + id_map.get(nameID);
				result[i] = nameID;
			} 
			else {
				id_map.put(nameID, 1);
				result[i] = nameID;
			}
		}
		return result;
	}
	public static String generateID(String name) {
		String[] subnames = name.split(" ");
		String result = "";
		String first = subnames[subnames.length-1].toLowerCase();
		result += first+".";
		
		for(int i=0; i<subnames.length-1; i++) {
			result += subnames[i].toLowerCase().charAt(0) +"";
		}
		
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] names = {"Phung Huy Hoang", "Nguyen The Nam", "Vu Ngoc Lam", "Pham Ngoc Son", "Nguyen Thanh Nam", "Pham Ngoc Son", "Phung Huy Hoang", "Nguyen Thanh Nam"};
		System.out.println(Arrays.toString(generateAll(names)));
	}

}
