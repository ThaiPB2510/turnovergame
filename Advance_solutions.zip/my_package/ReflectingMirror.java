package my_package;

import java.util.Scanner;

public class ReflectingMirror {
	static int[][] grid;
	static int count;
	static int cur_direct;
	static final int UP=0, DOWN=1, LEFT=2, RIGHT=3;
	
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=grid.length || y>=grid[0].length);
	}
	private static void goRight(int[] cell) {
		int x=cell[0], y=cell[1];
		y++;
		while(!isOutOfBound(x, y) && grid[x][y] == 0) {
			y++;
		}
		cell[0]=x; cell[1]=y;
	}
	private static void goLeft(int[] cell) {
		int x=cell[0], y=cell[1];
		y--;
		while(!isOutOfBound(x, y) && grid[x][y] == 0) {
			y--;
		}
		cell[0]=x; cell[1]=y;
	}
	private static void goUp(int[] cell) {
		int x=cell[0], y=cell[1];
		x--;
		while(!isOutOfBound(x, y) && grid[x][y] == 0) {
			x--;
		}
		cell[0]=x; cell[1]=y;
	}
	private static void goDown(int[] cell) {
		int x=cell[0], y=cell[1];
		x++;
		while(!isOutOfBound(x, y) && grid[x][y] == 0) {
			x++;
		}
		cell[0]=x; cell[1]=y;
	}

	public static void reflectingMirror(int[] cell) {
		goRight(cell);    // start going
		cur_direct = RIGHT;
		// stop here
		while(!isOutOfBound(cell[0], cell[1])) {
			//System.out.println("check");
			if(grid[cell[0]][cell[1]]==1) {
				count++;
				if(cur_direct==RIGHT) {
					goUp(cell);
					cur_direct = UP;
				}
				else if(cur_direct==DOWN) {
					goLeft(cell);
					cur_direct = LEFT;
				}
				else if(cur_direct==LEFT) {
					goDown(cell);
					cur_direct = DOWN;
				}
				else if(cur_direct==UP) {
					goRight(cell);
					cur_direct = RIGHT;
				}
			}
			else if(grid[cell[0]][cell[1]]==2) {
				count++;
				if(cur_direct==RIGHT) {
					goDown(cell);
					cur_direct = DOWN;
				}
				else if(cur_direct==DOWN) {
					goRight(cell);
					cur_direct = RIGHT;
				}
				else if(cur_direct==LEFT) {
					goUp(cell);
					cur_direct = UP;
				}
				else if(cur_direct==UP) {
					goLeft(cell);
					cur_direct = LEFT;
				}
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int N = sc.nextInt();
			grid = new int[N][N];
			count=0;
			
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					grid[i][j] = sc.nextInt();
				}
			}
			
			int[] start = {0,0};
			reflectingMirror(start);
			
			// Print the answer to standard output(screen).
			System.out.println("#"+test_case+" "+count);
		}
		sc.close();
	}

}
