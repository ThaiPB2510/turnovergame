package my_package;

import java.beans.Visibility;
import java.util.Scanner;

import my_util._Queue;

public class CrazyKing {
	static char[][] area;
	static boolean[][] visited;
	
	public static int shortestPath(int[] start, int[] end) {
		_Queue<Integer> qx = new _Queue<>(1000);
		_Queue<Integer> qy = new _Queue<>(1000);
		int x = start[0];
		int y = start[1];
		visited[x][y] = true;
		qx.add(x);
		qy.add(y);
		
		int ans=0;
		int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
		while(!qx.isEmpty()) {
			int size = qx.size();
			for(int i=0; i<size; i++) {
				x = qx.poll();
				y = qy.poll();
				
				if(x==end[0] && y==end[1]) 
					return ans;
				
				for(int[] d: directions) {
					int dx=d[0], dy=d[1];
					if(!isOutOfBound(x+dx, y+dy) && !visited[x+dx][y+dy] && area[x+dx][y+dy]!='Z') {
						qx.add(x+dx);
						qy.add(y+dy);
						visited[x+dx][y+dy] = true;
					}
				}
			}
			ans++;
		}
		return -1;
	}
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=area.length || y>=area[0].length);
	} 
	private static void placeKnight(int x, int y) {
		int[][] directions = {{1,2},{-1,2},{1,-2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
		for(int[] d: directions) {
			if(!isOutOfBound(x+d[0], y+d[1]) && area[x+d[0]][y+d[1]]!='A' && area[x+d[0]][y+d[1]]!='B')
				area[x+d[0]][y+d[1]] = 'Z';
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int M = sc.nextInt();
			int N = sc.nextInt();
			sc.nextLine();
			area = new char[M][N];
			visited = new boolean[M][N];
			int start_x=0, start_y=0;
			int end_x=0, end_y=0;
			for(int i=0; i<M; i++) {
				area[i] = sc.nextLine().toCharArray();
			}
			
			for(int i=0; i<M; i++) {
				for(int j=0; j<N; j++) {
					if(area[i][j]=='Z')
						placeKnight(i, j);
					else if(area[i][j]=='A') {
						start_x = i;
						start_y= j;
					}
					else if(area[i][j]=='B') {
						end_x = i;
						end_y = j;
					}
				}
			}
			
			// Print the answer to standard output(screen).
			System.out.println(shortestPath(new int[] {start_x, start_y}, new int[] {end_x, end_y}));
		}
		sc.close();
	}
/*
4
5 5
.Z..B
..Z..
Z...Z
.Z...
A....
3 2
ZB
.Z
AZ
6 5
....B
.....
.....
..Z..
.....
A..Z.
3 3
ZZ.
...
AB.
 */
}
