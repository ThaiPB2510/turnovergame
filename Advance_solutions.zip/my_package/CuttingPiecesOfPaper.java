package my_package;

import java.util.Scanner;

public class CuttingPiecesOfPaper {
	static int blue, white;
	static int[][] paper;

	private static boolean isWhite (int x, int y, int n){
		for(int i = x; i<x+n; i++){
			for(int j = y; j<y+n; j++){
				if (paper[i][j]!=0){
					return false;
				}		
			}
		}
		return true;
	}
	private static boolean isBlue(int x, int y, int n){
		for(int i = x; i< x + n; i++){
			for(int j = y; j< y+n; j++){
				if (paper[i][j]!=1){
					return false;
				}		
			}
		}
		return true;
	}
	public static void cutPieces(int x, int y, int n){
		if(n==0) return;

		if (isWhite(x,y,n)){
			white++;
		}
		else if (isBlue(x,y,n)){
			blue++; 
		}
		else {
			cutPieces(x, y, n/2);    // piece I
			cutPieces(x, y+n/2, n/2);   // piece II
			cutPieces(x+n/2, y, n/2);  // piece III
			cutPieces(x+n/2, y+n/2, n/2);	// piece IV
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int N = sc.nextInt();
			paper = new int[N][N];
			blue = 0;
			white=0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					paper[i][j] = sc.nextInt();
				}
			}
			
			cutPieces(0,0,N);
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+white+" "+blue);
		}
		sc.close();
	}

}
