package my_package;

import java.util.Scanner;

public class TurnOverGame {
	static char[][] board;
	static int[][] directions = {{-1,0},{1,0},{0,1},{0,-1}};
	static int minCount;
	
	private static void findMinOperation(int x, int y, int count) {
		if(x==4) {
			return;
		}
		// NO CHANGE
		if(isFinish()) { // check done
			minCount = Math.min(minCount, count);
		}
		else {
			int newX = (y==3) ? x+1 : x;
			int newY = (y==3) ? 0 : y+1;
			findMinOperation(newX, newY, count);   //backtracking
		}
		
		// CHANGE
		if(isFinish()) { // check done
			minCount = Math.min(minCount, count);
		}
		else {
			changeColor(x, y);   // place candidate
			count++;
			
			int newX = (y==3) ? x+1 : x;
			int newY = (y==3) ? 0 : y+1;
			findMinOperation(newX, newY, count);   //backtracking
	
			changeColor(x, y);   // remove candidate
			count--;	
		}
	}
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=4 || y>= 4);
	}
	private static void changeColor(int x, int y) {
		board[x][y] = (board[x][y]=='b') ? 'w' : 'b';
		for(int[] d: directions) {
			int newX = x+d[0];
			int newY = y+d[1];
			if(!isOutOfBound(newX, newY)) {
				if(board[newX][newY]=='b')
					board[newX][newY] = 'w';
				else
					board[newX][newY] = 'b';
			}
		}
	}
	private static boolean isFinish() {
	char c = board[0][0];
		for(int i=0; i<4; i++) {
			for(int j=0; j<4; j++) {
				if(board[i][j]!=c)
					return false;
			}
		}
		return true;	
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		sc.nextLine();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			board = new char[4][4];
			minCount = Integer.MAX_VALUE;
			for(int i=0; i<4; i++) {
				board[i] = sc.nextLine().toCharArray();
			}
			
			findMinOperation(0, 0, 0);
			
			// Print the answer to standard output(screen).
			if(minCount==Integer.MAX_VALUE)
				System.out.println("Case #" + test_case+"\n"+"impossible");
			else 
				System.out.println("Case #" + test_case+"\n"+ minCount);
		}
		sc.close();
	}
}

