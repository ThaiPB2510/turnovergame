package my_package;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LetterCombination {
	public static List<String> letterCombination(char[] letters) {
		final int NUM_LETTERS = 10;
		List<String> result = new ArrayList<>();
		char[] combo = new char[3];
		
		for(int i=0; i<NUM_LETTERS; i++) {
			combo[0] = letters[i];
			
			for(int j=0; j<NUM_LETTERS; j++) {
				if(j==i) continue;
				if(letters[j] > letters[i]) { 
					combo[1] = letters[j];
					
					for(int k=0; k<NUM_LETTERS; k++) {
						if(k==j || k==i) continue;
						if(letters[k] > letters[j]) {
							combo[2] = letters[k];
							result.add(new String(combo));
						}
					}
				}
			}
		}
		return result;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] A = {'G','J','A','C','O','Q','P','Y','Z','X'};
		Arrays.sort(A);
		System.out.println(Arrays.toString(A));
		System.out.println(letterCombination(A));
	}
}
