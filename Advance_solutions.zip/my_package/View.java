package my_package;

import java.util.Arrays;
import java.util.Scanner;

public class View {
	public static int viewBuilding(int[] building) {
		int[] left_side = new int[building.length];
		int[] right_side = new int[building.length];
		
		for(int i=2; i<building.length-2; i++) {
			left_side[i] = building[i] - Math.max(building[i-1], building[i-2]);
			if(left_side[i] < 0) left_side[i] = 0;
			right_side[i] = building[i] - Math.max(building[i+1], building[i+2]);
			if(right_side[i] < 0) right_side[i] = 0;
		}
//		System.out.println(Arrays.toString(left_side));
//		System.out.println(Arrays.toString(right_side));
//		
		int count=0;
		for(int i=2; i<building.length; i++) {
			count += Math.min(left_side[i], right_side[i]);
		}
		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int L = sc.nextInt();
			int[] building = new int[L];
			for(int i=0; i<L; i++) {
				building[i] = sc.nextInt();
			}
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+viewBuilding(building));
		}
	}

}
