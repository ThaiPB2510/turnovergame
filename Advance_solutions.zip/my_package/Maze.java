package my_package;

import java.util.Arrays;
import java.util.Scanner;

import my_util._Queue;

public class Maze {
	public static int hasPath(char[][] mat) {
		_Queue<int[]> q = new _Queue<>(1000);
		
		q.add(new int[] {1,1});
		mat[1][1] = '1'; // visit checked
		
		int[][] directions = {{-1,0},{1,0},{0,1},{0,-1}};
		while(!q.isEmpty()) {
			int size = q.size();
			for(int i=0; i<size; i++) {
				int[] cur = q.poll();
				int x = cur[0], y=cur[1];
				if(mat[x][y] == '3') return 1;
				mat[x][y] = '1';	// visited
				
				for(int[] d: directions) {
					int dx = d[0];
					int dy = d[1];
					if(mat[x+dx][y+dy] != '1') {
						q.add(new int[] {x+dx,y+dy});
					}
				}
			}
		}
		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=10;

		for(int test_case = 1; test_case <= T; test_case++)
		{
			sc.nextLine();
			char[][] mat = new char[16][16];
			for(int i=0; i<16; i++) {
				mat[i] = sc.nextLine().toCharArray();
			}
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" " + hasPath(mat));
		}
		sc.close();
	}

}
