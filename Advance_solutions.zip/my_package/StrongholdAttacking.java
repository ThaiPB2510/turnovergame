package my_package;

import java.util.Arrays;
import java.util.Scanner;

import my_util.DynamicArray;
import my_util.MaxHeap;

public class StrongholdAttacking {
	static DynamicArray<DynamicArray<Integer>> neighbors;
	static int[] weight; 
	static int[][] adj_matrix;
	static int sumAllWeights;
	
	public static int minStoneMachines() {
		// Prim's Algorithm
		int N = neighbors.size();
		boolean[] visited = new boolean[N];
		int cur = 0;    // duyet tu node 0
		visited[cur] = true;    //them 0 vao visited
		int num_visited = 1;   // dem so luong node da duyet
		DynamicArray<Integer> available = new DynamicArray<>();
		int MSTWeight = 0;
		
		while(num_visited<=N) {
			//System.out.println("current: "+cur);
			int next = findNeighborWithMaxWeight(cur, visited);
			if(next==-1) 
				break;
			visited[next] = true;
			MSTWeight += weight[cur] + weight[next];
			cur = next;
			num_visited++;
		}
		
		return sumAllWeights - MSTWeight;
	}
	private static int findNeighborWithMaxWeight(int node, boolean[] visited, DynamicArray<Integer> available) {
		DynamicArray<Integer> neigh = neighbors.get(node);
		int max = -1;
		int target_node = -1;
		
		for(int i=0; i<neigh.size(); i++) {
			if(weight[neigh.get(i)] > max && !visited[neigh.get(i)]) {
				max = weight[neigh.get(i)];
				target_node = neigh.get(i);
			}
		}
		
		return target_node;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int M = sc.nextInt();  // so thanh tri
			weight = new int[M];
			adj_matrix = new int[M][M];
			neighbors = new DynamicArray<>();
			sumAllWeights = 0;
			
			for(int i=0; i<M; i++) {
				neighbors.add(new DynamicArray<Integer>());
				sc.nextInt();   //so hieu thanh tri
				weight[i] = sc.nextInt(); // so may ban da
				int numNeighbor = sc.nextInt();  //so thanh tri lien ket voi i
				
				for(int j=0; j<numNeighbor; j++) {
					int k = sc.nextInt();  // so hieu thanh tri lien ket
					adj_matrix[i][k] = 1;
					neighbors.get(i).add(k);
				}
			}
			
			// tinh sum all weights
			for(int i=0; i<M-1; i++) {
				for(int j=i+1; j<M; j++) {
					if(adj_matrix[i][j]==1) {
						sumAllWeights += weight[i] + weight[j];
					}
				}
			}
//			
//			for(int i=0; i<neighbors.size(); i++) {
//				neighbors.get(i).printElements();
//			}
			
			int ans = minStoneMachines();
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+ans);
		}
		sc.close();
	}
/*
1
4
0 1 2
1 3
1 1 2
0 2
2 3 2
1 3
3 2 2
0 2
*/

}
