package my_package;

import java.util.Scanner;

import my_util._Stack;

public class StockExchange {
	public static int maxProfit(int[] prices) {
		int profit=0;
		int max=prices[0];
		int i=0;
		int end=0;

		while(i<prices.length) {
			int bought = 0;
			max = prices[i];
			end = 0;

			for(int j=i+1; j<prices.length; j++) {
				if(prices[j] > max) {
					max = prices[j];
					end = j-i;
				}
			}
			for(int k=i; k<i+end; k++) bought += prices[k];
			
			profit += max*end - bought; 
			i = i+end+1;
		}
		return profit;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=5;

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int[] prices = new int[N];
			for(int i=0; i<N; i++) {
				prices[i] = sc.nextInt();
			}
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" " + maxProfit(prices));
		}
		sc.close();
	}

}
