package my_package;

import java.util.Scanner;

public class Painting {
	static int ans;
	static int N;
	static int[][] area;
	static int[] visited; //mark color for pieces

	private static boolean isSafe(int vertex, int checkcolor){
		for (int j = 1; j <= N; j++){
			if (area[vertex][j] == 1 && checkcolor == visited[j]){
				return false;
			}
		}
		return true;
	}

	public static void paint(int step){ // new piece to paint
		if (step > N) {
			ans++;
			return;
		}
		for(int color=1; color<=4; color++){ 
			if(visited[step] == 0){
				if(isSafe(step, color)){
					visited[step] = color;
					paint(step+1);
					visited[step] = 0; //Backtrack
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			N = sc.nextInt();
			visited = new int[N+1];
			area = new int[N+1][N+1];
			ans = 0;
			
			for(int i=1; i<=N; i++) {
				for(int j=1; j<=N; j++) {
					area[i][j] = sc.nextInt();
				}
			}
			
			paint(1);
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+ans);
			
		}
		sc.close();
	}

}
