package my_package;

import java.util.Scanner;

public class ThreeKingdoms1 {
	static int M,N,K;
	static int[] cost, basePower, increment;
	static boolean[] isPicked;
	static int curStrength;
	static int ans;

	private static void pickArmy(int id) {
		for(int i=0; i<K; i++) {
			if(isPicked[i]) {
				curStrength += increment[i];
			}
		}
		if(id!=-1) {
			M -= cost[id];
			isPicked[id] = true;
			curStrength += basePower[id];
		}
	}
	private static void unpickArmy(int id) {
		if(id!=-1) {
			M += cost[id];
			curStrength -= basePower[id];
			isPicked[id] = false;
		}
		for(int i=0; i<K; i++) {
			if(isPicked[i]) {
				curStrength -= increment[i];
			}
		}
	}
	private static boolean isAffordable() {
		for(int i=0; i<K; i++) {
			if(isPicked[i]) continue;
			if(M>=cost[i])
				return true;
		}
		return false;
	}
	public static void backtrack(int index) {
		if(index==N) {
			ans = Math.max(ans, curStrength);
			return;
		}
		//System.out.println(curStrength);
		if(!isAffordable()) {
			pickArmy(-1);
			backtrack(index+1);
			unpickArmy(-1);
			return;
		}
		for(int army=0; army<K; army++) {
			if(!isPicked[army] && M>=cost[army]) {
				pickArmy(army);  
				backtrack(index+1);
				unpickArmy(army);
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			M = sc.nextInt();
			N = sc.nextInt();
			K = sc.nextInt();
			cost = new int[K];
			basePower = new int[K];
			increment = new int[K];
			isPicked = new boolean[K];
			
			for(int k=0; k<K; k++) {
				cost[k] = sc.nextInt();
				basePower[k] = sc.nextInt();
				increment[k] = sc.nextInt();
			}
			
			ans = 0;
			curStrength = 0;
			backtrack(0);
			// Print the answer to standard output(screen).
			System.out.println("#"+test_case+" "+ans);
		}
		sc.close();
	}

}
