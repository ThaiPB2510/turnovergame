package my_package;

import java.util.Scanner;

public class _8Queens {
	static int[][] board;
	static int[][] mask;
	static int max_score = 0;
	static int cur_score = 0;
	
	public static void backtrack(int row) {
		if(row==8) {
			max_score = Math.max(cur_score, max_score);
			return;
		}
		
		for(int col=0; col<8; col++) {
			if(!isUnderAttack(row, col)) {
				placeQueen(row, col);
				
			    backtrack(row+1);
				
				removeQueen(row, col);
			}
		}
	}
	private static boolean isUnderAttack(int r, int c) {
		return mask[r][c] < 0;
	}
	private static void placeQueen(int r, int c) {
		cur_score += board[r][c];
		for(int i=0; i<8; i++) mask[i][c]--;  // phong toa cot
		for(int j=0; j<8; j++) mask[r][j]--; // phong toa hang
		
		for(int k=-7; k<=7; k++) {      
			if(r+k>=0 && c+k>=0 && r+k<8 && c+k<8)   // phong toa cheo chinh
				mask[r+k][c+k]--;
			if(r+k>=0 && c-k>=0 && r+k<8 && c-k<8)   // phong toa cheo phu
				mask[r+k][c-k]--;
		}
	}
	private static void removeQueen(int r, int c) {
		cur_score -= board[r][c];
		for(int i=0; i<8; i++) mask[i][c]++;		// mo cot
		for(int j=0; j<8; j++) mask[r][j]++;		// mo hang
		
		for(int k=-7; k<=7; k++) {
			if(r+k>=0 && c+k>=0 && r+k<8 && c+k<8)    // mo cheo chinh
				mask[r+k][c+k]++;
			if(r+k>=0 && c-k>=0 && r+k<8 && c-k<8)    // mo cheo phu
				mask[r+k][c-k]++;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			max_score = 0;
			int num_board = sc.nextInt();
			System.out.println("Case #"+test_case);
			
			for(int i=0; i<num_board; i++) {
				sc.nextLine();
				board = new int[8][8];
				mask = new int[8][8];
				cur_score = 0;
				for(int r=0; r<8; r++) {
					for(int c=0; c<8; c++) {
						board[r][c] = sc.nextInt();
					}
				}
				
				backtrack(0);
				// Print the answer to standard output(screen).
				System.out.println(max_score);
			}
			
		}
		sc.close();
	}

}
