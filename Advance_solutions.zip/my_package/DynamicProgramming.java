package my_package;

public class DynamicProgramming {
	public static int maxProfit(int[] prices) {
        if(prices.length==1) return 0;
        int profit=0;
        for(int i=0; i<prices.length-1; i++) {
        	if(prices[i+1] > prices[i])
        		profit += prices[i+1] - prices[i];
        }
        return profit;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] A = {7,6,4,3,1};
		System.out.println(maxProfit(A));
	}

}
