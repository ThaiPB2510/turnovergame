package my_package;

import java.util.Arrays;
import java.util.Scanner;

import my_util._Queue;

public class PipeNetwork {
	static int[][] map;
	static boolean[][] seen;
	static int limit;
	static final int UP=0, DOWN=1, LEFT=2, RIGHT=3;
	static _Queue<int[]> q;
	static int total;
	
	private static int[] getValidConnectedPipes(int id, int direct) {
		switch(id) {
		case 1:
			switch(direct) {
			case UP: 
				return new int[] {1,2,5,6};
			case DOWN:
				return new int[] {1,2,4,7};
			case LEFT:
				return new int[] {1,3,4,5};
			case RIGHT:
				return new int[] {1,3,6,7};
			}
		case 2:
			switch(direct) {
			case UP: 
				return new int[] {2,5,6,1};
			case DOWN:
				return new int[] {2,1,4,7};
			default: 
				return null;
			}
		case 3:
			switch(direct) {
			case LEFT:
				return new int[] {3,1,4,5};
			case RIGHT:
				return new int[] {3,1,6,7};
			default:
				return null;
			}
		case 4:
			switch(direct) {
			case UP: 
				return new int[] {1,2,5,6};
			case RIGHT:
				return new int[] {1,3,6,7};
			default:
				return null;
			}
		case 5:
			switch(direct) {
			case DOWN:
				return new int[] {1,2,4,7};
			case RIGHT:
				return new int[] {1,3,6,7};
			default:
				return null;
			}
		case 6:
			switch(direct) {
			case DOWN:
				return new int[] {1,2,4,7};
			case LEFT:
				return new int[] {1,3,4,5};
			default:
				return null;
			}
		case 7:
			switch(direct) {
			case UP: 
				return new int[] {1,2,5,6};
			case LEFT:
				return new int[] {1,3,4,5};
			default:
				return null;
			}
		}
		return null;
	}
	private static boolean canConnect(int pipe1, int pipe2, int direct) {
		if(pipe2==0) return false;
		int[] neigh = getValidConnectedPipes(pipe1, direct);
		if(neigh==null) return false;
		
		for(int i=0; i<neigh.length; i++) {
			if(neigh[i]==pipe2)
				return true;
		}
		return false;
	}
	private static int[] left(int[] cell) {
		return new int[] {cell[0], cell[1]-1};
	}
	private static int[] right(int[] cell) {
		return new int[] {cell[0], cell[1]+1};
	}
	private static int[] up(int[] cell) {
		return new int[] {cell[0]-1, cell[1]};
	}
	private static int[] down(int[] cell) {
		return new int[] {cell[0]+1, cell[1]};
	}

	public static void solve(int x, int y) {
		q.add(new int[] {x,y});
		seen[x][y] = true;

		int step = 1;
		while(!q.isEmpty()) {
			int size = q.size();
			for(int i=0; i<size; i++) {
				int[] cur = q.poll();
				x=cur[0]; y=cur[1];
				int pipe_id = map[x][y];
				
				if(!isOutOfBound(left(cur))) {
					int[] left = left(cur);
					int pipe2_id = map[left[0]][left[1]];
					if(!seen[left[0]][left[1]] && canConnect(pipe_id, pipe2_id, LEFT)) {
						//System.out.println(Arrays.toString(left));
						q.add(left);
						seen[left[0]][left[1]] = true;
						total++;
					}
				}
				if(!isOutOfBound(right(cur))) {
					int[] right = right(cur);
					int pipe2_id = map[right[0]][right[1]];
					if(!seen[right[0]][right[1]] && canConnect(pipe_id, pipe2_id, RIGHT)) {
						//System.out.println(Arrays.toString(right));
						q.add(right);
						seen[right[0]][right[1]] = true;
						total++;
					}
				}
				if(!isOutOfBound(up(cur))) {
					int[] up = up(cur);
					int pipe2_id = map[up[0]][up[1]];
					if(!seen[up[0]][up[1]] && canConnect(pipe_id, pipe2_id, UP)) {
						//System.out.println(Arrays.toString(up));
						q.add(up);
						seen[up[0]][up[1]] = true;
						total++;
					}
				}
				if(!isOutOfBound(down(cur))) {
					int[] down = down(cur);
					int pipe2_id = map[down[0]][down[1]];
					if(!seen[down[0]][down[1]] && canConnect(pipe_id, pipe2_id, DOWN)) {
						//System.out.println(Arrays.toString(down));
						q.add(down);
						seen[down[0]][down[1]] = true;
						total++;
					}
				}				
			}
			step++;
			if(step==limit) break;
		}
	}
	private static boolean isOutOfBound(int[] cell) {
		int x=cell[0], y=cell[1];
		return (x<0 || y<0 || x>=map.length || y>=map[0].length);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int N = sc.nextInt();
			int M = sc.nextInt();
			map = new int[N][M];
			seen = new boolean[N][M];
			q = new _Queue<>(1000);
			
			int start_x = sc.nextInt();
			int start_y = sc.nextInt();
			limit = sc.nextInt();
			total = 1;
			
			for(int i=0; i<N; i++) {
				for(int j=0; j<M; j++) {
					map[i][j] = sc.nextInt();
				}
			}
			
			solve(start_x, start_y);
			
			// Print the answer to standard output(screen).
			System.out.println("Case #" + test_case+"\n"+ total);
		}
		sc.close();
	}

}
