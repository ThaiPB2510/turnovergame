package my_package;

import java.util.Scanner;

import my_util._Queue;

class Node {
	public int direction;
	public int x;
	public int y;
	public Node(int x, int y, int dir) {
		direction = dir;
		this.x = x;
		this.y = y;
	}
}
public class FastRobot {
	static char[][] maze;
	static final int NORTH=0, SOUTH=1, WEST=2, EAST=3;

	public static int minDirectionChange(int[] start, int[] target) {
		int N = maze.length;
		int M = maze[0].length;
		_Queue<Node> q = new _Queue<>(5000);
		boolean[][] visited = new boolean[N][M];
		
		int x=start[0], y=start[1];
		if(!isOutOfBound(x+1, y)) q.add(new Node(x+1, y, SOUTH));
		if(!isOutOfBound(x-1, y)) q.add(new Node(x-1, y, NORTH));
		if(!isOutOfBound(x, y+1)) q.add(new Node(x, y+1, EAST));
		if(!isOutOfBound(x, y-1)) q.add(new Node(x, y-1, WEST));
		
		while(!q.isEmpty()) {
			Node cur = q.poll();
			int x = cur.x, y = cur.y;
			int freqRotation = cur.freqRotation;
			
			if(x==target[0] && y==target[1]) {
				return freqRotation;
			}
			
			if(!isOutOfBound(x+1, y) && maze[x+1][y]=='0' && !visited[x+1][y]) 
				updateNextMove(q, visited, cur, x+1, y, NORTH);
			if(!isOutOfBound(x-1, y) && maze[x-1][y]=='0' && !visited[x-1][y]) 
				updateNextMove(q, visited, cur, x-1, y, SOUTH);
			if(!isOutOfBound(x, y-1) && maze[x][y-1]=='0' && !visited[x][y-1]) 
				updateNextMove(q, visited, cur, x, y-1, WEST);
			if(!isOutOfBound(x, y+1) && maze[x][y+1]=='0' && !visited[x][y+1]) 
				updateNextMove(q, visited, cur, x, y+1, EAST);
		}
		return -1;
	}
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=maze.length || y>=maze[0].length);
	}
	private static void updateNextMove(_Queue<Node> q, boolean[][] visited, Node cur, int nextX, int nextY, int direction) {
		if(!isOutOfBound(nextX, nextY) && maze[nextX][nextY]==0) {
			Node next;
			int rot = cur.freqRotation;
			if(cur.direction==-1 || cur.direction==direction)
				next = new Node(nextX, nextY, rot, direction);
			else next = new Node(nextX, nextY, rot+1, direction);
			
			q.add(next);
			visited[nextX][nextY] = true;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int M = sc.nextInt();
			maze = new char[N][M];
			
			int[] start = new int[2];
			int[] target = new int[2];
			start[1] = sc.nextInt()-1;
			start[0] = sc.nextInt()-1;
			target[1] = sc.nextInt()-1;
			target[0] = sc.nextInt()-1;
			sc.nextLine();
			for(int i=0; i<N; i++) {
				maze[i] = sc.nextLine().toCharArray();
			}
			
			// Print the answer to standard output(screen).
			System.out.println(minDirectionChange(start, target));
		}
		sc.close();
	}

}
