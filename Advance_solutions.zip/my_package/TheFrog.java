package my_package;

import java.util.Scanner;

public class TheFrog {
	static Leaf[] leaves;
	static boolean[] visited;
	static int[] distance;
	static int near, far;
	
	private static int leafDistance(Leaf l1, Leaf l2) {
		int x1 = l1.x, y1=l1.y;
		int x2= l2.x, y2=l2.y;
		int r1=l1.radius, r2=l2.radius;
		int dist = (int)Math.sqrt(Math.pow(x1-x2, 2)+Math.pow(y1-y2, 2)) - r1 - r2;
		
		if(dist <= 40)
			return 1;
		else if(dist <= 90)
			return 10;
		return 999999;
	}
	
	public static void solve(int cur) {
		distance[cur] = 0;
		int N = leaves.length;
		
		while(!visited[N-1]) {
			int next=-1;
			int temp = Integer.MAX_VALUE;
			for(int i=0; i<N; i++) {
				if(!visited[i] && distance[i] <= temp) {
					temp = distance[i];
					next = i;
				}
			}
			
			visited[next] = true;
			for(int i=0; i<N; i++) {
				if(!visited[i]) {
					temp = distance[next] + leafDistance(leaves[next], leaves[i]);
					distance[i] = Math.min(temp, distance[i]);
				}
			}
		}
		if(distance[N-1]<999999) {
			near = distance[N-1]%10;
			far = distance[N-1]/10;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		sc.nextLine();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int N = sc.nextInt();
			leaves = new Leaf[N];
			visited = new boolean[N];
			distance = new int[N];
			near = far = 999999;
			
			for(int i=0; i<N; i++) {
				int x = sc.nextInt();
				int y = sc.nextInt();
				int r = sc.nextInt();
				leaves[i] = new Leaf(x, y, r);
				distance[i] = Integer.MAX_VALUE;
			}
			
			solve(0);
			// Print the answer to standard output(screen).
			if(far==999999) System.out.println(-1);
			else System.out.println(far+" "+near);
		}
		sc.close();
	}

}
class Leaf {
	int x;
	int y;
	int radius;
	public Leaf(int x, int y, int radius) {
		this.x = x;
		this.y = y;
		this.radius = radius;
	}
}