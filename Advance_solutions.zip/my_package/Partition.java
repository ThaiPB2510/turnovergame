package my_package;

import java.util.Scanner;

import my_util._Array;

public class Partition {
	public static int minTimePartition(int[] groups) {
		int temp, pos1, pos2;
		for(int i=1; i<groups.length; i++) {
			
		}
	}
	private static int partition(int index, int[] prefix) {
		if(index==0) return 0;
		return prefix[index] + partition(index-1, prefix);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int[] groups = new int[N];
			for(int i=0; i<N; i++) {
				groups[i] = sc.nextInt();
			}
			// Print the answer to standard output(screen).
			System.out.println("Case "+"#" + test_case+"\n" + minTimePartition(groups));
		}
		sc.close();
	}

}
