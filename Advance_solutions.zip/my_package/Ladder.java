package my_package;

import java.util.Scanner;

public class Ladder {
	static int[][] mat = new int[1000][1000];
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int T=1;

		for(int test_case = 1; test_case <= T; test_case++) {
			sc.nextInt();
			for(int i=0; i<1000; i++) {
				for(int j=0; j<1000; j++) {
					mat[i][j] = sc.nextInt();
				}
			}
			
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+ climbLadder(mat));
		}	
    }
    public static int climbLadder(int[][] mat) {
		int last_r = mat.length-1;
		
		int start = 0;
		for(int j=0; j<mat[0].length; j++) {
			if(mat[last_r][j]==2)	{
				start = j;
				break;
			}
		}
		
		int c = start;
		int r = last_r;
		while(r>0) {
			if(c>1 && mat[r][c-1]==1) {
				while(c>=0 && mat[r][c-1]==1) c--;
				r--;
				continue;
			}
			else if(c+1<mat[0].length && mat[r][c+1]==1) {
				while(c<mat[0].length && mat[r][c+1]==1) c++;
				r--;
				continue;
			}
			if(mat[r-1][c]==1) {
				r--;
				continue;
			}
		}
		
		return c;
	}
/*
1 0 0 0 1 0 1 0 0 1
1 0 0 0 1 0 1 1 1 1
1 0 0 0 1 0 1 0 0 1
1 0 0 0 1 1 1 0 0 1
1 0 0 0 1 0 1 0 0 1
1 1 1 1 1 0 1 1 1 1
1 0 0 0 1 0 1 0 0 1
1 1 1 1 1 0 1 0 0 1
1 0 0 0 1 1 1 0 0 1
1 0 0 0 1 0 1 0 0 2
*/
}
