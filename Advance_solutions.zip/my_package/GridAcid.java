package my_package;

import java.util.Scanner;

import my_util._Queue;

public class GridAcid {
	static final int STONE=0, SPECIAL_METAL=1, EMPTY=2;
	static int[][] grid;
	static int[] empty_cell;
	static boolean[][] isFilled;
	static int numMetal;
	static int time_1, time_2;
	
	static int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
	static _Queue<Integer> qx, qy;
	
	private static boolean isEmptyCellFilled() {
		int x = empty_cell[0];
		int y = empty_cell[1];
		for(int[] d: directions) {
			int neiX = x+d[0];
			int neiY = y+d[1];
			if(isOutOfBound(neiX, neiY) || !isFilled[neiX][neiY])
				return false;
		}
		return true;
	}
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=grid.length || y>=grid[0].length);
	}
	public static void spreadingAcid(int[] start) {
		qx = new _Queue<>(10000);
		qy = new _Queue<>(10000);
		int x = start[0], y=start[1];
		qx.add(x);
		qy.add(y);
		isFilled[x][y] = true;
		
		time_1 = -1;
		boolean flag1 = false;
		time_2 = 0;
		int numMelt = 1;
		while(!qx.isEmpty()) {
			if(isEmptyCellFilled() && flag1==false) {		// update duy nhat 1 lan
				time_1 = time_2+1;
				isFilled[empty_cell[0]][empty_cell[1]] = true;
				flag1 = true;
				numMelt++;
			}
			
			int size = qx.size();
			for(int i=0; i<size; i++) {
				x = qx.poll();
				y = qy.poll();
				
				for(int[] d: directions) {
					int newX = x+d[0];
					int newY = y+d[1];
					if(!isOutOfBound(newX, newY) && !isFilled[newX][newY] && grid[newX][newY]==SPECIAL_METAL) {
						isFilled[newX][newY] = true;
						qx.add(newX);
						qy.add(newY);
						numMelt++;
					}
				}
			}
			time_2++;
		}
		if(numMelt<numMetal) time_2 = -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int N = sc.nextInt();
			int M = sc.nextInt();
			grid = new int[N][M];
			isFilled = new boolean[N][M];
			
			int startR = sc.nextInt()-1;
			int startC = sc.nextInt()-1;
			
			numMetal=0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<M; j++) {
					grid[i][j] = sc.nextInt();
					if(grid[i][j]!=STONE)
						numMetal++;
					if(grid[i][j]==EMPTY)
						empty_cell = new int[]{i,j};
				}
			}
			
			spreadingAcid(new int[] {startR, startC});
			
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+time_1+" "+time_2);
		}
		sc.close();
	}
/*
5
4 5
2 4
1 0 1 0 1
1 0 1 1 1
1 1 2 1 1
1 0 1 0 1
3 3
1 2
1 1 0
1 2 1
0 1 1
3 3
1 1
1 1 1
1 2 1
0 1 1
3 3
3 3
1 1 1
1 2 1
0 1 1
4 4
2 3
0 0 1 0
0 1 1 1
1 1 2 1
1 0 1 1
 */
}
