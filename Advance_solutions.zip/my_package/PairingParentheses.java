package my_package;
import java.util.Scanner;

import my_util._Stack;

public class PairingParentheses {
	public static int isValid(String s) {
        if(s.length() % 2 != 0) 
        	return 0;
        
        _Stack<Character> stack = new _Stack<>(1000);
        stack.push(s.charAt(0));
        for(int i=1; i<s.length(); i++) {
        	if(!stack.isEmpty()) {
        		char bracket = stack.peek();
        		if(s.charAt(i)==closeBracket(bracket)) {
        		    stack.pop();
        		    continue;
        		}
        	}
        	stack.push(s.charAt(i));
        }
        return stack.isEmpty() ? 1 : 0;
    }
	private static char closeBracket(char bracket) {
		if(bracket=='(')
			return ')';
		else if(bracket=='[')
			return ']';
		else if(bracket=='{')
			return '}';
		else if(bracket=='<')
			return '>';
		return ' ';
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=10;

		for(int test_case = 1; test_case <= T; test_case++)
		{
			sc.nextLine();
			String input = sc.nextLine();
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+isValid(input));
		}
		sc.close();
	}

}
