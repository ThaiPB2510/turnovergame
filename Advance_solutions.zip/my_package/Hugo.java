package my_package;

import java.util.Arrays;
import java.util.Scanner;

public class Hugo {
	static int N,M;
	static int[][] flames;
	static int[][] fireTime;
	static int[][] diamond;
	static boolean[][] isWater;
	static boolean[][] isExit;
	static boolean[][] visited;
	static int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
	
	static int maxDiamond;	
	
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=N || y>=M);
	}
	private static void spreadingFire(int x, int y) {
		for(int[] d: directions) {
			int dx=d[0], dy=d[1];
			int newX = x+dx;
			int newY = y+dy;
			if(!isOutOfBound(newX, newY) && !isWater[newX][newY] && fireTime[newX][newY] > fireTime[x][y]+1) {
				fireTime[newX][newY] = fireTime[x][y]+1;
				spreadingFire(newX, newY);
			}
		}
	}
	public static void backtrack(int r, int c, int time, int took) {
		if(time >= fireTime[r][c])
			return;
		
		if(isExit[r][c]) {
			maxDiamond = Math.max(maxDiamond, took);
		}
		
		for(int[] d: directions) {
			int newR = r+d[0];
			int newC = c+d[1];
			if(!isOutOfBound(newR, newC) && !visited[newR][newC] && fireTime[newR][newC]>time+1) {
				visited[newR][newC] = true;			
				
				if(isWater[newR][newC]) {
					backtrack(newR, newC, time+2, took+diamond[newR][newC]);
				}
				else {
					backtrack(newR, newC, time+1, took+diamond[newR][newC]);
				}
				
				visited[newR][newC] = false;
			}
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			N = sc.nextInt();
			M = sc.nextInt();
			int startX = sc.nextInt()-1;
			int startY = sc.nextInt()-1;
			
			// Ngon Lua
			int numFlames = sc.nextInt();
			flames = new int[numFlames][2];
			fireTime = new int[N][M];
			for(int i=0; i<N; i++) {
				for(int j=0; j<M; j++) {
					fireTime[i][j] = 9999;
				}
			}
			for(int i=0; i<numFlames; i++) {
				flames[i][0] = sc.nextInt()-1;
				flames[i][1] = sc.nextInt()-1;
				fireTime[flames[i][0]][flames[i][1]] = 1;
			}
			
			// Ho Nuoc
			int numLakes = sc.nextInt();
			isWater = new boolean[N][M];
			for(int i=0; i<numLakes; i++) {
				int x = sc.nextInt()-1;
				int y = sc.nextInt()-1;
				isWater[x][y] = true;
			}
			// Loi thoat
			int numExits = sc.nextInt();
			isExit =  new boolean[N][M];
			for(int i=0; i<numExits; i++) {
				int x=sc.nextInt()-1;
				int y=sc.nextInt()-1;
				isExit[x][y] = true;
			}
			// Kim cuong
			diamond = new int[N][M];
			for(int i=0; i<N; i++) {
				for(int j=0; j<M; j++) {
					diamond[i][j] = sc.nextInt();
				}
			}
			
			visited =  new boolean[N][M];
			maxDiamond=-1;
			
			// Loang ngon lua
			for(int[] flame: flames) {
				spreadingFire(flame[0], flame[1]);
			}
			
			// bat dau duyet
			visited[startX][startY] = true;
			backtrack(startX, startY, 1, diamond[startX][startY]);
			
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+maxDiamond);
		}
		sc.close();
	}
/*
1
4 4 1 2
2 1 1 4 1
4 1 3 2 1 3 3 3 4
2 2 4 3 4
0 0 10 20
9 3 2 5
0 0 0 0
0 10 0 100
 */
}
