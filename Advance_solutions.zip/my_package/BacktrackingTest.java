package my_package;

import java.util.ArrayList;
import java.util.List;

public class BacktrackingTest {
	static int[] nums;
	static int[] mask;
	public static void generateNumbersSum(int index, int curSum) {
		if(curSum > 20 || index>nums.length) return;
		if(curSum==20) {
			for(int i=0; i<mask.length; i++) {
				if(mask[i]==1) System.out.print(nums[i]+" ");
			}
			System.out.println();
			return;
		}
		
		for(int i=index; i<nums.length; i++) {
			curSum += nums[i];
			mask[i] = 1;
			generateNumbersSum(i+1, curSum);
			curSum -= nums[i];
			mask[i] = 0;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		nums = new int[]{5,10,15,20,3,7,11,9};
		mask = new int[nums.length];
		generateNumbersSum(0, 0);
	}

}
