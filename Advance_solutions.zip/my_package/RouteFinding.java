package my_package;

import java.util.Arrays;
import java.util.Scanner;

import my_util._Queue;

public class RouteFinding {
	public static int hasRoute(int[] road1, int[] road2) {
		_Queue<Integer> q = new _Queue<>(1000);
		q.add(0);
		
		boolean[] visited = new boolean[100];
		visited[0] = true;
		
		while(!q.isEmpty()) {
			int cur = q.poll();
			if(cur==99) return 1;
			
			visited[cur] = true;
			if(road1[cur] != 0 && !visited[road1[cur]]) {
				q.add(road1[cur]);
			}
			if(road2[cur] != 0 && !visited[road2[cur]]) {
				q.add(road2[cur]);
			}
		}
		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=10;

		for(int test_case = 1; test_case <= T; test_case++)
		{
			sc.nextInt();
			int num_roads = sc.nextInt();
			int[] road1 = new int[100];
			int[] road2 = new int[100];
			for(int i=0; i<num_roads; i++) {
				int l1 = sc.nextInt();
				int r1 = sc.nextInt();
				if(road1[l1] == 0)
					road1[l1] = r1;
				else 
					road2[l1] = r1;
			}
			
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+hasRoute(road1, road2));
		}
		sc.close();
	}

}
