package my_package;

import java.util.Scanner;

public class CoverWithDominos {
	static int[][] board;
	static boolean[][] checked;
	static boolean[][] used_dominos;    // [number1][number2]
	
	static int ans;
	static final int HORIZ=0, VERTI=1;
	
	public static void backtrack(int r, int c) {
		if(r==board.length) {
			ans++;
			return;
		}
		if(checked[r][c]==true) {
			int newR = (c==board[0].length-1) ? r+1 : r;
			int newC = (c==board[0].length-1) ? 0 : c+1;
			backtrack(newR, newC);
			return;
		};
					
		// lap ngang
		if(!isOutOfBound(r, c+1) && !checked[r][c+1]) {
			int num1 = board[r][c];
			int num2 = board[r][c+1];
			if(!used_dominos[num1][num2]) {
				placeDomino(r, c, num1, num2, HORIZ);
				int newR = (c==board[0].length-1) ? r+1: r;
				int newC = (c==board[0].length-1) ? 0 : c+1;
				backtrack(newR, newC);
				removeDomino(r, c, num1, num2, HORIZ);
			}
		}
		
		// lap doc
		if(!isOutOfBound(r+1, c) && !checked[r+1][c]) {
			int num1 = board[r][c];
			int num2 = board[r+1][c];
			if(!used_dominos[num1][num2]) {
				placeDomino(r, c, num1, num2, VERTI);
				int newR = (c==board[0].length-1) ? r+1: r;
				int newC = (c==board[0].length-1) ? 0 : c+1;
				backtrack(newR, newC);
				removeDomino(r, c, num1, num2, VERTI);
			}
		}
		
	}
	private static void placeDomino(int r, int c, int num1, int num2, int direct) {
		used_dominos[num1][num2] = used_dominos[num2][num1] = true;
		if(direct==HORIZ) {
			checked[r][c] = true;
			checked[r][c+1] = true;
		}
		else if(direct==VERTI) {
			checked[r][c] = true;
			checked[r+1][c] = true;
		}
	}
	private static void removeDomino(int r, int c, int num1, int num2, int direct) {
		used_dominos[num1][num2] = used_dominos[num2][num1] = false;
		if(direct==HORIZ) {
			checked[r][c] = false;
			checked[r][c+1] = false;
		}
		else if(direct==VERTI) {
			checked[r][c] = false;
			checked[r+1][c] = false;
		}
	}
	private static boolean isOutOfBound(int r, int c) {
		return (r<0 || c<0 || r>=board.length || c>=board[0].length);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			board = new int[7][8];
			checked = new boolean[7][8];
			used_dominos = new boolean[7][7];
			ans = 0;
			for(int i=0; i<7; i++) {
				for(int j=0; j<8; j++) {
					board[i][j] = sc.nextInt();
				}
			}
			
			backtrack(0, 0);
			
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+ans);
		}
		sc.close();
	}
}
