package my_package;

import java.util.Scanner;

import my_util._Queue;

public class FarmProtection {
	static int[][] mat;
	public static int countPeaks() {
		int N = mat.length;
		int M = mat[0].length;
		int count = 0;
		
		for(int i=0; i<N; i++) {
			for(int j=0; j<M; j++) {
				if(mat[i][j]!=0) {
					count++;
					BFS(i, j);
				}
			}
		}
		return count;
	}
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=mat.length || y>=mat[0].length);
	}

	private static void BFS(int x, int y) {
		_Queue<int[]> q = new _Queue<>(49001);
		q.add(new int[] {x,y});
		mat[x][y] = 0;
		
		int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
		while(!q.isEmpty()) {
			int[] cur = q.poll();
			x = cur[0]; 
			y = cur[1];
			
			for(int[] d: directions) {
				int dx = d[0];
				int dy = d[1];
				//System.out.println(q.toString());
				if(!isOutOfBound(x+dx, y+dy) && mat[x+dx][y+dy]!=0) {
					q.add(new int[] {x+dx,y+dy});
					mat[x+dx][y+dy] = 0;
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int N = sc.nextInt();
			int M = sc.nextInt();
			mat = new int[N][M];
			
			for(int i=0; i<N; i++) {
				for(int j=0; j<M; j++) {
					mat[i][j] = sc.nextInt();
				}
			}
			
			// Print the answer to standard output(screen).
			System.out.println("#"+test_case+" "+countPeaks());
		}
		sc.close();
	}

}
