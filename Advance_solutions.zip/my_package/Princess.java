package my_package;

import java.util.Scanner;

import my_util._Queue;

public class Princess {
	static int step;
	static int[][] maze;
	static int[] princessPos;
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=maze.length || y>=maze.length);
	}
	public static void findPrincess() {
		int N = maze.length;
		_Queue<int[]> q= new _Queue<>(500);
		boolean[][] visited = new boolean[N][N];
		
		q.add(new int[] {0,0});
		visited[0][0] = true;
		
		int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
		while(!q.isEmpty()) {
			int size = q.size();
			for(int i=0; i<size; i++) {
				int[] cur = q.poll();
				int x=cur[0], y=cur[1];
				if(maze[x][y]==2) {
					princessPos = new int[] {x,y};
					return;	
				}
				
				for(int[] d: directions) {
					int dx=d[0], dy=d[1];
					if(!isOutOfBound(x+dx, y+dy) && !visited[x+dx][y+dy] && maze[x+dx][y+dy]!=0) {
						q.add(new int[] {x+dx,y+dy});
						visited[x+dx][y+dy] = true;
					}
				}
			}
			step++;
		}
		step = -1;
	}
	public static void findExit() {
		if(step==-1) {
			return;
		}
		int N = maze.length;
		_Queue<int[]> q= new _Queue<>(200);
		boolean[][] visited = new boolean[N][N];
		
		q.add(princessPos);
		visited[princessPos[0]][princessPos[1]] = true;
		
		int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
		while(!q.isEmpty()) {
			int size = q.size();
			for(int i=0; i<size; i++) {
				int[] cur = q.poll();
				int x=cur[0], y=cur[1];
				if(x==N-1 && y==N-1) {
					return;	
				}
				
				for(int[] d: directions) {
					int dx=d[0], dy=d[1];
					if(!isOutOfBound(x+dx, y+dy) && !visited[x+dx][y+dy] && maze[x+dx][y+dy]!=0) {
						q.add(new int[] {x+dx,y+dy});
						visited[x+dx][y+dy] = true;
					}
				}
			}
			step++;
		}
		step = -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{	
			int N = sc.nextInt();
			maze = new int[N][N];
			step = 0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					maze[i][j] = sc.nextInt();
				}
			}
			
			findPrincess();
			findExit();
			// Print the answer to standard output(screen).
			System.out.println(step);
		}
		sc.close();
	}
/*
2
5
1 0 1 1 0
1 0 0 0 0
1 1 2 1 1
1 1 0 0 0
1 1 1 1 1
6
1 1 0 2 1 1
0 1 0 1 0 1
0 1 0 1 0 1
0 0 0 1 0 1
0 0 0 1 0 1
1 1 1 1 0 1
 */
}
