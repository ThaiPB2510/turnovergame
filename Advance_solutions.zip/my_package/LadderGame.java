package my_package;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class LadderGame {
	public static int ladderGame(int[][] mat, int bomb, int finalRow) {
		// mat[i][j]=1 tuc la dau mut doan thang, -1 la giua doan thang
		int num_players = mat[0].length;
		
		for(int player=0; player<num_players; player++) {
			int c = player;
			int r=0;
			while(r <= finalRow) {
				if(r==finalRow && c==bomb) return player+1;
				if(mat[r][c]!=1) {
					r++;
				}
				else { 
						
					if(c==mat[0].length-1 || mat[r][c+1]==0) {
						c--;
						while(mat[r][c]==-1) c--;
					}
					else if(c==0 || mat[r][c-1]==0) {
						c++;
						while(mat[r][c]==-1) c++;
					}
					else if(mat[r][c-1]==1 && mat[r][c+1]==1) {
						if(c%2==0) c = c + 1;
						else c = c - 1;
					}
					r++;
				}
			}
		}
		return 0;
	}
	

	public static void main(String[] args) {
		// System.setIn(newFileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int T = 9;
		for(int test_case = 1; test_case <= T; test_case++) {
			int N = sc.nextInt();  //cols
			int B = sc.nextInt(); // bomb
			int M = sc.nextInt();  //num. lines
			int finalRow = 0;
			
			int[][] mat = new int[N][N];
			for(int i=0; i<M; i++) {
				int r1 = sc.nextInt();
				int c1 = sc.nextInt();
				int r2 = sc.nextInt();
				int c2 = sc.nextInt();
				
				int start = Math.min(c1-1, c2-1);
				int end = Math.max(c1-1, c2-1);
				mat[r1-1][start] = 1;
				mat[r1-1][end] = 1;
				
				while(++start<end) {
					mat[r1-1][start] = -1;
				}
				
				finalRow = Math.max(finalRow, r1);
			}
			
			
			//System.out.println(Arrays.deepToString(mat));
			
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case +" "+ladderGame(mat, B-1, finalRow));
			
		}
		
		sc.close();
	}

}
