package my_package;

import java.util.Scanner;

public class SkyTour {
	static int N;
	static int[][] map;
	static int E;
	static int ans;
	
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=map.length || y>=map[0].length);
	}
	public static void backtrack(int r, int c, int stars, int energy) {
		if(energy<0) return;
		if(c==N-1) {
			ans = Math.max(ans, stars);
			return;
		}
		if(energy==0) {
			backtrack(r, c+1, stars+map[r][c+1], energy);
			return;
		}
		
		for(int i=-2; i<=2; i++) {
			if(!isOutOfBound(r+i, c+1)) {
				if(i==-2)   // 2 up
					backtrack(r+i, c+1, stars+map[r+i][c+1], energy-4);
				else if(i==-1)
					backtrack(r+i, c+1, stars+map[r+i][c+1], energy-2);
				else if(i==0)
					backtrack(r+i, c+1, stars+map[r+i][c+1], energy);
				else if(i==1)
					backtrack(r+i, c+1, stars+map[r+i][c+1], energy-1);
				else if(i==2)
					backtrack(r+i, c+1, stars+map[r+i][c+1], energy-2);
			}
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			E = sc.nextInt();
			N = sc.nextInt();
			map = new int[3][N];
		
			for(int i=0; i<3; i++) {
				for(int j=0; j<N; j++) {
					map[i][j] = sc.nextInt();
				}
			}
			
			ans=0;
			backtrack(1, -1, 0, E);
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" " + ans);
		}
		sc.close();
	}

}
