package my_package;

import java.util.Arrays;
import java.util.Scanner;

import my_util.DynamicArray;
import my_util._Queue;

public class TradePointS6 {
	static int N;
	static int[][] map;
	static int[][] newMap;
	static boolean[][] isExchanged;
	static int numArea;
	static int freq;
	
	static _Queue<Integer> qx;
	static _Queue<Integer> qy;
	
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=N || y>=N);
	}
	public static void countArea() {
		for(int i=0; i<N; i++) {
			for(int j=0; j<N; j++) {
				if(newMap[i][j]!=-1) {
					DFS(i, j, newMap[i][j]);
					numArea++;
				}
			}
		}
	}
	private static void DFS(int r, int c, int target) {
		if(isOutOfBound(r, c) || newMap[r][c]!=target)
			return;

		newMap[r][c] = -1;
		DFS(r-1, c, target);
		DFS(r+1, c, target);
		DFS(r, c-1, target);
		DFS(r, c+1, target);
	}
	
	private static void updateMap() {
		for(int i=0; i<map.length; i++) {
			for(int j=0; j<map[0].length; j++) {
				if(map[i][j]==0 && !isExchanged[i][j]) {
					exchangeHighestFrequencyBooth(i, j);
				}
			}
		}
		//System.out.println(Arrays.deepToString(newMap));
	}
	private static void exchangeHighestFrequencyBooth(int x, int y) {
		qx = new _Queue<Integer>(1000);
		qy = new _Queue<Integer>(1000);
		boolean[][] visited = new boolean[N][N];
		
		qx.add(x);
		qy.add(y);
		visited[x][y] = true;
		
		DynamicArray<int[]> zeroBooths = new DynamicArray<>();
		zeroBooths.add(new int[] {x,y});
		
		// BFS neighbor booths
		int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
		int[] count = new int[6];
		while(!qx.isEmpty()) {
			x = qx.poll();
			y = qy.poll();
			
			for(int[] d: directions) {
				int newX = x+d[0];
				int newY = y+d[1];
				if(!isOutOfBound(newX, newY) && !visited[newX][newY]) {
					if(map[newX][newY]==0) {
						visited[newX][newY] = true;
						qx.add(newX);
						qy.add(newY);
						zeroBooths.add(new int[] {newX, newY});
					}
					else {
						freq = 0;
						getFrequency(newX, newY, map[newX][newY], visited);
						count[map[newX][newY]] += freq;
					}
				}
			}
		}
		// get booth to exchange
		int booth_max = 0;
		int max = -1;
		for(int i=0; i<6; i++) {
			if(count[i] >= max) {
				max = count[i];
				booth_max = i;
			}
		}
		
		// exchange
		for(int i=0; i<zeroBooths.size(); i++) {
			int[] cell = zeroBooths.get(i);
			newMap[cell[0]][cell[1]] = booth_max;
			isExchanged[cell[0]][cell[1]] = true;
		}
	}
	private static void getFrequency(int x, int y, int target, boolean[][] visited) {
		if(isOutOfBound(x, y) || visited[x][y])
			return;
		if(map[x][y] != target) return;
		
		visited[x][y] = true;
		freq++;
		getFrequency(x+1, y, target, visited);
		getFrequency(x-1, y, target, visited);
		getFrequency(x, y+1, target, visited);
		getFrequency(x, y-1, target, visited);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			N = sc.nextInt();
			map = new int[N][N];
			newMap = new int[N][N];
			isExchanged = new boolean[N][N];
			numArea = 0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					newMap[i][j] = map[i][j] = sc.nextInt();
				}
			}
			
			updateMap();
			countArea();
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+numArea);
		}
		sc.close();
	}

}