package my_package;

import java.util.Scanner;

import my_util._Queue;

public class ChessKnight {
	static int[][] board;
	static int[][] directions = {{1,2},{-1,2},{1,-2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
	static int num_enemies;
	static int eaten;
	static int ans;
	static _Queue<Integer> qx;
	static _Queue<Integer> qy;
	
//	public static void solve(int x, int y) {
//		if(eaten==num_enemies) {
//			ans = Math.min(ans, numMoves);
//			return;
//		}
//		findNearestEnemy(x, y, 0);
//	}
	public static void findNearestEnemy(int x, int y, int curMoves) {
		if(curMoves==num_enemies) {
			ans = Math.min(ans, curMoves);
			return;
		}
		
		boolean[][] seen = new boolean[board.length][board[0].length];
		qx.clear();
		qy.clear();
		qx.add(x);
		qy.add(y);
		seen[x][y] = true;
		
		while(!qx.isEmpty()) {
			int size = qx.size();
			for(int i=0; i<size; i++) {
				x = qx.poll();
				y = qy.poll();
				if(board[x][y]==1) {
					board[x][y] = 0;
					return;
				}
				
				for(int[] d: directions) {
					int dx = d[0], dy= d[1];
					
					if(!isOutOfBound(x+dx, y+dy) && !seen[x+dx][y+dy]) {
						qx.add(x+dx);
						qy.add(y+dy);
						seen[x+dx][y+dy] = true;
						eaten++;
						findNearestEnemy(x, y, curMoves);
						eaten--;
					}
				}
			}
			curMoves++;
		}
		
	}
	
	private static boolean isOutOfBound(int x, int y) {
		return (x<0 || y<0 || x>=board.length || y>=board[0].length);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int M = sc.nextInt();
			board = new int[N][M];
			num_enemies = 0;
			eaten = 0;
			
			int start_x = 0, start_y = 0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<M; j++) {
					board[i][j] = sc.nextInt();
					if(board[i][j]==3) {
						start_x = i;
						start_y = j;
					}
					else if(board[i][j]==1)
						num_enemies++;
				}
			}
			
			qx = new _Queue<>(10000);
			qy = new _Queue<>(10000);
			ans = 9999;
			findNearestEnemy(start_x, start_y, 0);
			// Print the answer to standard output(screen).
			System.out.println("Case #"+test_case+"\n"+ans);
		}
		sc.close();
	}
/*
1
10 10
1 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 1 0 0
0 1 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 3 0 0 0
0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 1

 */
}
