package my_package;

import java.util.Arrays;

import my_util._Stack;

public class DFSExample {
	static int[][] edges;
	static int[][] adj_matrix;
	static int[] result;
	static int k;
	static boolean[] visited;
	
	public static void DFS(int cur) {
		if(isDone())
			return;
		
		for(int i=0; i<adj_matrix.length; i++) {
			if(adj_matrix[cur][i]==1 && !visited[i]) {
				visited[i] = true;
				result[k++] = i;
				DFS(i);
			}
		}
	}
	private static boolean isDone() {
		for(int i=0; i<visited.length; i++) {
			if(visited[i]==false)
				return false;
		}
		return true;
	}
	
	public static void DFSwithStack() {
		_Stack<Integer> stack = new _Stack<>(10);
		boolean[] seen = new boolean[8];
		stack.push(1);
		seen[1] = true;
		
		result[0] = 1;
		k=1;
		while(!stack.isEmpty()) {
			int cur = stack.pop();
			if(!seen[cur]) {
				seen[cur] = true;
				result[k++] = cur;
			}
			
			for(int i=7; i>=0; i--) {
				if(adj_matrix[cur][i]==1 && !seen[i]) {
					stack.push(i);
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		edges = new int[][] {{1,2},{1,3},{2,4},{2,5},{4,6},{5,6},{6,7},{3,7}};
		adj_matrix = new int[8][8];
		
		for(int[] edge: edges) {
			int x = edge[0], y=edge[1];
			adj_matrix[x][y] = 1;
			adj_matrix[y][x] = 1;
		}
		
		
		//System.out.println(Arrays.toString(result));
	}

}
