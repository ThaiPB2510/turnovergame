package my_package;

import java.util.Scanner;

public class Magnetic {
	public static int magneticCollision(int[][] mags) {
		int ans = 0; 
		int n = mags.length;
		for(int j = 0; j < n; j++) { 
			boolean isNPole = false; 
			for (int i = 0; i < n; i++) { 
				if (mags[i][j]==2 && isNPole==true) { 
					ans++; 
					isNPole = false; 
				} 
				else if (mags[i][j] == 1) 
					isNPole = true; 
			} 
		}
		return ans;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=10;

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int[][] mags = new int[N][N];
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					mags[i][j] = sc.nextInt();
				}
			}
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" "+magneticCollision(mags));
		}
	}

}
