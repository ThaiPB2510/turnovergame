package my_package;

import java.util.Scanner;

public class MountainWalking {
	
    public static int minimumGap(int[][] heights) {
        int left = 0;
        int right = 110;
        int N = heights.length;
        
        while(left<right){
            int mid = left + (right-left)/2;
            boolean[][] visited = new boolean[N][N];
            
            if(hasPath(heights, 0, 0, visited, mid, heights[0][0], heights[0][0])) {
                right = mid;
            }
            else
                left = mid + 1;
        }
        return left;
    }
    static int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}};
    private static boolean hasPath(int[][] heights, int i, int j, boolean visited[][], int gap, int minH, int maxH){
    	int N = heights.length;
    	//System.out.println(i+" "+j+" "+minH);
        if(i==N-1 && j== N-1) return true;
        
        visited[i][j] = true;
        for(int d[]: directions) {
            int x = i + d[0];
            int y = j + d[1];
            if(x<0 || y<0 || x>=N || y>=N || visited[x][y]) continue;
            
            int curMin = Math.min(minH, heights[x][y]);
            int curMax = Math.max(maxH, heights[x][y]);
            if(curMax - curMin <= gap) {
                if(hasPath(heights,x,y,visited, gap, curMin, curMax)) 
                	return true;
            }
        }
        return false;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int[][] heights = new int[N][N];
		
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					heights[i][j] = sc.nextInt();
				}
			}
			// Print the answer to standard output(screen).
			System.out.println("#" + test_case+" " + minimumGap(heights));
		}
		sc.close();
	}
/*
61 49 32 34 28

100 65 0 10 89

34 99 40 86 4

10 97 49 21 30

95 33 79 51 65
 */
}
