#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;

int n, k, ans;
int map[21][21];
int visit[21];

int q[1000];
int front, rear; 

void resetmap(){
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <= n; j++){
			map[i][j] = 0;
		}
	}
}
void resetvisit(){
	for (int i = 1; i <= n; i++){
		visit[i] = 0;
	}
}
void bfs(int i){

	front = 0; rear = 0;
	q[rear++] = i;

	visit[i] = 1;

	while (front != rear){
		int tempi = q[front++];
		for (int j = 1; j <= n; j++){
			if (map[tempi][j] == 1 && visit[j] == 0){
				visit[j] = visit[tempi] + 1;
				if (ans < visit[j]) ans = visit[j];

				q[rear++] = j;
			}
		}
	}

}

int main(){
	freopen("input.txt", "r", stdin);
	int T, tc;
	cin >> T;
	for (tc = 1; tc <= T; tc++){
		cin >> n >> k;
		ans = 0;
		resetmap();
		int i, j;
		for (int t = 1; t <= k; t++){
			cin >> i >> j;
			map[i][j] = 1;
			map[j][i] = 1;
		}
		
		for (i = 1; i <= n; i++){
			resetvisit();
			bfs(i);
		}

		cout <<"#" << tc << " " << --ans << endl;
	}
	return 0;
}
//Input
//2
//6 5
//2 6
//2 1
//2 5
//5 3
//5 4
//7 8
//1 2
//2 3
//3 4
//4 5
//5 6
//2 5
//6 3
//4 7

//Output
//#1 3
//#2 4