#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define size 100
int n, a[size][size], b[size][size];

void updateA (){
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <=n; j++){
			if (a[i][j] != b[i][j]) a[i][j] = b[i][j];
		}
	}
}

int main(){
	freopen("input.txt", "r", stdin);
	int year = 0, i, j, x, y;
	scanf("%d", &n);
	for (i = 1; i <= n; i++){
		for (j = 1; j <=n; j++){
			scanf("%d", &a[i][j]);
			b[i][j] = a[i][j];
		}
	}

	bool haveChange = true;
	while (haveChange){
		haveChange = false;
		for (i = 2; i < n; i++){
			for (j = 2; j < n; j++){
				if (a[i][j] == 0 && (a[i+1][j] + a[i-1][j] + a[i][j-1] + a[i][j+1]) == 1) {

					haveChange = true;

					// 4 directions
					if (a[i+1][j]==1){
						x=i; y=j;
						while (a[++x][y]==1 && x <= n) b[x][y]=0;
					}
					else if (a[i-1][j]==1){
						x=i; y=j;
						while (a[--x][y]==1 && x >=1) b[x][y]=0;
					}
					else if (a[i][j+1]==1){
						x=i; y=j;
						while (a[i][++y]==1 && y<=n) b[x][y]=0;
					}
					else if (a[i][j-1] == 1){
						x=i; y=j;
						while (a[i][--y]==1 && y >=1) b[x][y]=0;
					}		
					
				}
			}
		}

		if (haveChange) year++;
		updateA ();
	}

	printf("%d", year);

	return 0;
}