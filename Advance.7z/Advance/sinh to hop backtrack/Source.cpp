#include <iostream>
using namespace std;

void backtrack(int step){
	if(step == k){
		for(int i=0; i<k;i++){
			cout << ans[i]<<" ";
		}
		cout << endl;
	}
	

}
int main(){}