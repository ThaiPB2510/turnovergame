#include<iostream>
using namespace std;
int m,n;
char arr[22][22];
int check[22][22];
int flag=0;
int Dx[4] = {-1,0,1,0};
int Dy[4] = {0,-1,0,1};
int VR_x[2];
int VR_y[2];
void input(){
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			cin >> arr[i][j];
			check[i][j] = 0;
		}
	}
}

void output(){
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			cout << arr[i][j] <<" ";
		}
		cout << endl;
	}
}
void DFS(int x,int y){
	if(x==VR_x[1] && y==VR_y[1]){
		flag =1;
	}
	else {
		check[x][y]=1;
		for(int i=0;i<4;i++){
			if(arr[x+Dx[i]][y+Dy[i]]=='.' && check[x+Dx[i]][y+Dy[i]]==0 && x+Dx[i] < n && x+Dx[i] >=0 && y+Dy[i] < m && y+Dy[i]>=0){
				DFS(x+Dx[i], y+Dy[i]);
			}
		}
	}
}

int main(){
	freopen("input.txt","r",stdin);
	int T=0,t=1,loca=0;
	cin >> T;
	while(t<=T){
		cin>>m;
		cin>>n;
		input();


		for(int i=0;i<n;i=i++){
			if(arr[0][i]=='.'){
				VR_x[loca]=0;
				VR_y[loca]=i;
				loca++;
			}
		}

		if (m!=1){
		for(int i=0;i<n;i=i++){
			if(arr[m-1][i]=='.'){
				VR_x[loca]=m-1;
				VR_y[loca]=i;
				loca++;
			}
		}
		}

		for(int i=1;i<m-1;i=i++){
			if(arr[i][0]=='.'){
				VR_x[loca]=i;
				VR_y[loca]=0;
				loca++;
			}
		}

		if(n!=1){
		for(int i=1;i<m-1;i=i++){
			if(arr[i][n-1]=='.'){
				VR_x[loca]=i;
				VR_y[loca]=n-1;
				loca++;
			}
		}
		}

		DFS(VR_x[0], VR_y[0]);



		if(flag == 1 && loca ==2)
			cout << "valid" << " "<< endl;
		else
			cout << "invalid" << " "<< endl;

		//cout << endl;
		//output();
		loca=0;
		flag=0;
		t++;
	}
	return 0;
}