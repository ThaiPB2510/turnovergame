#include<iostream>
using namespace std;
char arr[10000];
int stack[10000];
int size = 10000;
int top=-1;
int check = 1;

void reset(){
	arr[0] = 0;
}

void init(){
	top=-1;
}

void push(int value){
		top++;
		stack[top]=value;
}
int pop(){
	int value=0;
		value = stack[top];
		top--;
	return value;
}

void input(int n){
	for(int i=0;i<n;i++){
		cin >> arr[i];
	}
}

int main(){
	int t=1, n=0, T=0;
	freopen("input.txt", "r", stdin);
	while(t<=10){
		init();
		cin >> n;
		input(n);
		for(int i=0;i<n;i++){
			if(arr[i]=='{')
				push(1);
			else if(arr[i]=='[')
				push(2);
			else if(arr[i]=='(')
				push(3);
			else if(arr[i]=='<')
				push(4);

			if(arr[i] == '}'){
				if(pop() != 1){
					check=0;
					break;}}

			else if(arr[i] == ']'){
				if(pop() != 2){
					check=0;
					break;}}

			else if(arr[i] == ')'){
				if(pop() != 3){
					check=0;
					break;}}

			else if(arr[i] == '>'){
				if(pop() != 4){
					check=0;
					break;}}
		}
		cout <<t<<" "<<check<<endl;
		check=1;
		t++;
	}
	return 0;
}
