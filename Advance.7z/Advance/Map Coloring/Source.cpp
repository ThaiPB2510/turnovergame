#include <iostream>
using namespace std;
int a[2000];
int arr[1000][1000];
int visited[1000][1000];
int result = 0;
int queue[100000];
int front=-1, rear=-1;

void inQueue(int value){
	rear++;
	queue[rear]=value;
}

int deQueue(){
	front++;
	return queue[front];
}

void input(int m, int n){
	for(int i=0;i<=m;i++){
		for(int j=0;j<=n;j++){
			visited[i][j]=0;
		}
	}
	for(int i=1; i<=n; i++){
		cin >> a[i];
	}
	for(int i=1; i<=n; i=i+2){
		arr[a[i]][a[i+1]]=1;
	}
}

void show(int n){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

void BFS(int x, int y, int n){
	front=-1;
	rear=-1;
	int step=0;
	inQueue(x);
	inQueue(y);
	inQueue(step);
	visited[x][y]=1;
	while(front != rear){
		x = deQueue();
		y = deQueue();
		step = deQueue();
		arr[x][y] = step+1;
		visited[x][y] = 1;
		for(int i=1; i<=n; i++){
			if(arr[y][i] == 1 && visited[y][i] == 0){
				visited[y][i] = 1;
				inQueue(y);
				inQueue(i);
				inQueue(step+1);
			}
		}
	}
}

int main(){
	//freopen("input.txt","r",stdin);
	int T=0, t=1, m=0, n=0, check[1000];
	cin >> T;
	while(t<=T){
		int flag =0;
		cin >> m >> n;
		input(m,n*2);
		for(int i=1;i<=m;i++){
			if(arr[1][i]==1){
				BFS(1,i,m);
				break;
			}
		}

		/*int tmp=0;
		for(int i=1;i<=m;i++){
			for(int j=1; j<=m;j++){
				if(tmp<arr[i][j])
					tmp=arr[i][j];
			}
			check[i] = tmp;
			tmp=0;
		}*/

		//for(int i=1;i<=m;i++){
		//	if(check[i]%2 != 0)
		//		check[i] = 0;
		//	else
		//		check[i] = 1;
		//}
		cout <<"#"<<t<<" ";
			for(int i=1;i<=m;i++){
				cout << check[i] << " ";
			}
			cout << endl;
		t++;
	}
	return 0;
}