#include<iostream>
using namespace std;
int chessBox[10][10];
int visit[9];
int ans[93][10];
int row = 0;
int arr[9];
void reset(){
	for(int i=0;i<10;i++){
		for(int j=0;j<10;j++){
			chessBox[i][j]=0;
		}
	}

	for(int i=0;i<93;i++){
		for(int j=0; j<10;j++){
			ans[i][j]=0;
		}
	}
	for(int i=0;i<9;i++)
		visit[i]=0;

}

void xuat(){
	row++;
	for(int i=1;i<=8;i++){
		ans[row][i] = arr[i];
	}

}

int abs(int x){
	if(x<0){
		return x*(-1);
	}
	return x;
}

int check(int step, int y){
	for(int i=1; i<step; i++){
		if(arr[i]==y || abs(arr[i]-y) == abs(i-step))
			return 0;
	}
	return 1;
}

void backtrack(int step){
	if(step == 9){
		xuat();
		return;
	}
	for(int i=1;i<=8;i++){
		if(check(step,i)== 1){
			arr[step]=i;
			backtrack(step+1);
		}
	}
}
int main(){
	int T=0, t=1, sum=0,sumMax=0, n=0;
	int abc[9][9];
	reset();
	backtrack(1);
	//freopen("input.txt","r",stdin);
	cin >> T;
	while(t<=T){
		cin >> n;
		cout <<"Case #"<<t<<endl;
		while(n>0){
			for(int i=1;i<=8;i++){
				for(int j=1;j<=8;j++){
					cin >> abc[i][j];
				}
			}
			sum=0;
			for(int i=1;i<=92;i++){
				for(int j=1;j<=8;j++)
					sum = sum + abc[j][ans[i][j]];
				if(sumMax < sum)
					sumMax = sum;
				sum=0;
			}
			cout << sumMax << endl;
			sumMax=0;
			sum=0;
			n--;
		}
	
	t++;
	}
	//	for(int i=1;i<93;i++){
	//	for(int j=1; j<9;j++){
	//		cout << ans[i][j] << " ";
	//	}
	//	cout << endl;
	//}

	return 0;
}