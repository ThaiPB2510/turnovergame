#include <iostream>
using namespace std;
int rear = -1, front = -1;
int queue[20000];
void enQueue(int value){
	if(rear == 20000-1){
		rear=0;
		queue[rear]=value;
	}
	else{
		rear ++;
		queue[rear]=value;
	}
}
void BFS(){
	
}