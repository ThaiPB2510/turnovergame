#include<iostream>
using namespace std;

int arr[101][101];
int N, T;
int st[10001], en[10001], val[10001], soLuongCanh, p[101], ans;


void make_set(int x) {
	p[x] = x;
}

int find_set(int x) {
	if (x == p[x]) {
		return x;
	} else {
		return find_set(p[x]);
	}
}


void _union(int x, int y) {
	p[find_set(y)] = find_set(x);
}


int main()
{
	//freopen("input.txt","r",stdin);
	cin>>T;
	for (int tc=1;tc<=T; tc++) {
		cin>>N;
		ans = 0;
		for (int i=0; i<N; i++) {
			for (int j=0; j<N; j++) {
				cin>>arr[i][j];
			}
		}

		soLuongCanh = 0;
		for (int i=0; i<N; i++) {
			for (int j = i + 1; j<N; j++) {
				st[soLuongCanh] = i;
				en[soLuongCanh] = j;
				val[soLuongCanh] = arr[i][j];
				soLuongCanh++;
			}
		}

		for (int i=0; i<soLuongCanh - 1; i++) {
			for (int j=i+1; j<soLuongCanh; j++) {
				if (val[j] < val[i]) {
					int temp = val[i];
					val[i] = val[j];
					val[j] = temp;

					temp = st[i];
					st[i] = st[j];
					st[j] = temp;

					temp = en[i];
					en[i] = en[j];
					en[j] = temp;
				}
			}
		}

		/*for (int i=0; i<soLuongCanh; i++) {
			cout<<st[i]<<" "<<en[i]<<" "<<val[i]<<endl;
		}*/
		for (int i=0; i<N; i++) {
			make_set(i);
		}

		for (int i=0; i<soLuongCanh; i++) {
			if (find_set(st[i]) != find_set(en[i])) {
				ans += val[i];
				_union(st[i], en[i]);
			}
		}

		cout<<"Case #"<<tc<<endl;
		cout<<ans<<endl;
	}
	return 0;
}


