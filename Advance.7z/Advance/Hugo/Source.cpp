#include<iostream>
using namespace std;

int diamond_max=0;
int sum_diamond=0;
int tmp_fire[48];
int fire[16][16];
int lake[16][16];
int exit_hugo[16][16];
int diamond[16][16];
int visit_hugo[16][16];
int hugo_x=0;
int hugo_y=0;
int queue[200000];
int rear=-1, front=-1;
int dx[4]={-1,0,0,1};
int dy[4]={0,-1,1,0};
int m=0,n=0;
int numbe_fire=0, numbe_lake=0, numbe_exit=0;

void reset(){
	for(int i=0;i<16;i++){
		for(int j=0;j<16;j++){
			fire[i][j]=0;
			diamond[i][j]=0;
			visit_hugo[i][j]=0;
			exit_hugo[i][j]=0;
		}
	}
	for(int i=0;i<16;i++){
		for(int j=0;j<16;j++){
			lake[i][j]=1;
		}
	}
}
void input(){
	int x=0,y=0;
	cin >> m >> n;
	cin >> hugo_x >> hugo_y;
	cin >> numbe_fire;
	for(int i=1;i<=numbe_fire*3;i=i+3){
		cin >> x >> y;
		tmp_fire[i] = x;
		tmp_fire[i+1] = y;
		tmp_fire[i+2] =  1;
	}

	cin >> numbe_lake;
	for(int i=1;i<=numbe_lake;i++){
		cin >> x >> y;
		lake[x][y] = 2;
	}
	cin >> numbe_exit;
	for(int i=1;i<=numbe_exit;i++){
		cin >> x >> y;
		exit_hugo[x][y] = 1;
	}
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin >> diamond[i][j];
		}
	}
}

void enQueue(int value){
	if(rear == 200000-1){
		rear=0;
		queue[rear]=value;
	}
	else{
		rear++;
		queue[rear]=value;
	}

}

int deQueue(){
	if(front == 200000-1){
		front=0;
		return queue[front];
	}
	else{
		front++;
		return queue[front];

	}
}

void BFS(){
	int x=0; int y=0;
	front = -1;
	rear = -1;
	int step=1;
	for(int i=1;i<=numbe_fire*3;i=i+3){
		enQueue(tmp_fire[i]);
		enQueue(tmp_fire[i+1]);
		enQueue(tmp_fire[i+2]);
		fire[tmp_fire[i]][tmp_fire[i+1]]=1;
	}
	while(front != rear){
		x=deQueue();
		y=deQueue();
		step=deQueue();
		for(int i=0;i<4;i++){
			if(x+dx[i] > 0 && x+dx[i] <= m && y+dy[i] > 0 && y+dy[i]<=n && lake[x+dx[i]][y+dy[i]] != 2 && fire[x+dx[i]][y+dy[i]]==0){
				fire[x+dx[i]][y+dy[i]] = step+1;
				enQueue(x+dx[i]);
				enQueue(y+dy[i]);
				enQueue(step+1);
			}
		}
	}
}

void backtrack(int x, int y, int score  ){

	if(exit_hugo[x][y] == 1 && diamond_max <= score){
		diamond_max = score;
	}

	for(int i=0;i<4;i++){
		if((x+dx[i] >0 && x+dx[i] <=m && y+dy[i] >0 && y+dy[i] <= n) && visit_hugo[x+dx[i]][y+dy[i]] == 0 && (fire[x+dx[i]][y+dy[i]] > (visit_hugo[x][y] + lake[x+dx[i]][y+dy[i]])  || fire[x+dx[i]][y+dy[i]] == 0)){
			
			visit_hugo[x+dx[i]][y+dy[i]] = visit_hugo[x][y] + lake[x+dx[i]][y+dy[i]] ;
			
			backtrack(x+dx[i], y+dy[i], score + diamond[x+dx[i]][y+dy[i]] );
			
			visit_hugo[x+dx[i]][y+dy[i]] = 0;
		}

	}

}
int main(){
	int T=0, t=1;
	//freopen("input.txt","r",stdin);
	cin >> T;
	while(t<=T){
		reset();
		input();
		BFS();
		/*for(int i=1;i<=numbe_fire*3;i=i+3){
			fire[tmp_fire[i]][tmp_fire[i+1]]=1;
		}*/
		diamond_max=-1;
		visit_hugo[hugo_x][hugo_y]=1;
		backtrack(hugo_x, hugo_y, diamond[hugo_x][hugo_y]);
		cout << "Case #"<<t<<endl<<diamond_max<<endl;
		t++;
	}
	return 0;
}

