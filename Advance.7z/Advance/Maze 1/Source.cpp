#include<iostream>
using namespace std;
int arr[102][102];
char arr1[102][102];
int queue[50000];
int rear=-1;
int front=-1;
int dx[4]={-1,0,1,0};
int dy[4]={0,1,0,-1};
int countt=0;
int dich_x=0, dich_y=0;
void input(int n){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			cin>> arr1[i][j];
		}
	}
		for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
		arr[i][j] = arr1[i][j]-'0' ;
		}
	}
}

void show(int n){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			cout << arr[i][j] <<" ";
		}
		cout << endl;
	}
}
void init(){
	front=-1;
	rear=-1;
}
void inqueue(int value){
	rear++;
	queue[rear]=value;
}

int dequeue(){
	front++;
	return queue[front];
}
void BFS(int x, int y, int n){
	init();
	int step=1;
	inqueue(x);
	inqueue(y);
	inqueue(4);
	arr[x][y]=3;
	while(front != rear){
		x=dequeue();
		y=dequeue();
		step=dequeue();
		for(int i=0;i<4;i++){
			if(arr[x+dx[i]][y+dy[i]]== 0 && x+dx[i] >=0 && x+dx[i]<n && y+dy[i] >=0 && y+dy[i] <n ){
				arr[x+dx[i]][y+dy[i]] = step+1;
				inqueue(x+dx[i]);
				inqueue(y+dy[i]);
				inqueue(step+1);
			}
		}
	}
}

int main(){
	//freopen("input.txt","r",stdin);
	int T=0,n=0;
	int countt=0, max=0;
	int t=1;
	while(t<=10){
		cin >>T;
		n=16;
		input(n);
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				if(arr[i][j]==3){
					dich_x=i;
					dich_y=j;
				}
			}
			for(int j=0;j<n;j++){
				if(arr[i][j]==2){
					BFS(i,j,n);
				}
			}
		}

		if(arr[dich_x+1][dich_y] > 1 || arr[dich_x-1][dich_y] > 1 || arr[dich_x][dich_y+1] > 1 || arr[dich_x][dich_y-1] > 1 ){
			cout<<"#"<<T<<" 1"<<endl;
		}
		else
			cout<<"#"<<T<<" 0"<<endl;
		t++;
	}
	return 0;
}