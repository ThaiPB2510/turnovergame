#include <iostream>
using namespace std;

int arr[1001];
int arr_count[201];
void input(){
	for(int i = 0; i<1000; i++){
		cin >> arr[i];
	}
}

void reset(){
	for(int i=0; i<201;i++){
		arr_count[i] = 0;
	}
}

int main(){
	int t=1;
	int T;
	int score=0, temp=0;
	//freopen("input.txt","r",stdin);
	while(t<=10){
		cin >>T;
		input();
		reset();
		for(int i=0;i<1000;i++){
			arr_count[arr[i]]++;
		}
		for(int i=1;i<201;i++){
			if(temp <= arr_count[i] ){
				temp = arr_count[i];
				score = i;
			}
		}
		cout <<"#"<<T<<" "<<score<<endl;
		score=0;
		temp=0;
		t++;
	}
	return 0;
}