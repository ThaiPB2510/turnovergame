#include<iostream>
using namespace std;
int arr[1000000];
int queue[100000];
int rear=-1;
int front=-1;
int part[1000];

void init(){
	front =-1;
	rear = -1;
}

void inqueue(int value){
	rear++;
	queue[rear]=value;
}

int dequeue(){
	front++;
	return queue[front];
}

int main(){
	int T=1;
	while(T<=12){
		cin >> m;
		cin >> n;

	
	}

}