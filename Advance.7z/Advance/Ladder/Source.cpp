#include<iostream>
using namespace std;
int arr[101][101], arr_clone[101][101];
void input(){
	for(int i=0;i<100;i++){
		for(int j=0;j<100;j++){
			cin >> arr[i][j];
		}
	}
}

void clone(){
	for(int i=0;i<100;i++){
		for(int j=0;j<100;j++){
			arr_clone[i][j] = arr[i][j];
		}
	}
}

int move(){
	int x,y;
	for(int i=0;i<100;i++){
		if(arr_clone[99][i]==2){
			x=99;
			y=i;
			while(x>0){
				if(arr_clone[x][y-1] == 1&&y-1>=0){
					x=x;
					y=y-1;
					arr_clone[x][y] = 0;
				}
				else if(arr_clone[x][y+1] == 1&&y+1<=99){
					x=x;
					y=y+1;
					arr_clone[x][y] = 0;
				}
				else if(arr_clone[x-1][y] == 1 &&x-1>=0){
					x=x-1;
					y=y;
					arr_clone[x][y] = 0;
				}
				else
					break;
			}

		}
	}
return y;
}
int main(){
	int T,t=1;
	freopen("input.txt","r",stdin);
	while(t<=10){
		cin >> T;
		input();
		clone();
		cout <<"#"<<T<< " "<<move()<<endl;
		t++;
	}
}