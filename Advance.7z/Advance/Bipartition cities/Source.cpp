#include<iostream>
using namespace std;

int queue[10000];
int front=-1, rear=-1;
int arr[1000][1000], arr1[1000], part[1000];

void init(){
	front=-1;
	rear=-1;
}

void inqueue(int value){
	rear++;
	queue[rear]=value;
}

int dequeue(){
	front++;
	return queue[front];
}

void reset(int m){
	for(int i=1;i<=m;i++){
		for(int j=1;j<=m;j++){
			arr[i][j] = 0;
		}
	}
	for(int i=1;i<m;i++){
		part[i]=0;
	}
}

void show(int n){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cout << arr[i][j]<<" ";
		}
		cout << endl;
	}
	cout<<endl;
}

void input(int n){
	for(int i=1;i<=n*2;i++){
		cin>>arr1[i];
	}
	for(int i=1; i<=n*2; i=i+2){
		arr[arr1[i]][arr1[i+1]]=1;
	}
	for(int i=1; i<=n*2; i=i+2){
		arr[arr1[i+1]][arr1[i]]=1;
	}
}

int main(){
	freopen("input.txt","r",stdin);
	int t=1,m=0,n=0,u=0,v=0,k=0,k1=0;
	while(t<=12){
		cin >> m;
		cin >> n;
		reset(m);
		input(n);
		int check=0;
		for(int i=1;i<=m;i++){
			if(part[i]==0){
				part[i]=1;
				inqueue(i);
				while(front != rear){
					u = dequeue();
					k=part[u];
					k1=3-k;
					for(int i=u+1;i<=m;i++){
						if(arr[i][u]==1){
							if(part[i]==0){
								part[i]=1;
								inqueue(i);
							}
							else
								if(part[i]==k){
									check=-1;
									break;
								}
						}
					}
					if(check==-1)
						break;
				}				
			}
			if(check==-1)
				break;
		}
		if(check==-1){
			cout << check<<endl;
		}
		else
			for(int i=1; i<=m;i++){
				cout << part[i] <<" "<<endl;
			}

			t++;
	}
	return 0;
}