#include <iostream>
using namespace std;
int arr[3001][3001];
int visited[3001][3001];
int queue[1000000];
int count1=0;
int count2=0;
int count_metal=0;
int m=0, n=0, xx=0, yy=0;
int front =-1, rear=-1;
int Dx[4] = {-1,0,0,1};
int Dy[4] = {0,-1,1,0};

void input(){
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin >> arr[i][j];
			visited[i][j]=0;
			if(arr[i][j] == 2){
				xx=i;
				yy=j;
			}
			if(arr[i][j] == 1)
				count_metal++;
		}
	}
	visited[xx][yy] = 1;
}

void enQueue(int value){
	if(rear == 1000000-1){
		rear = 0;
		queue[rear] = value;
	}
	else{
		rear++;
		queue[rear] = value;}
}

int deQueue(){
	if(front == 1000000-1){
		front = 0;
		return queue[front];
	}
	else{
		front++;
		return queue[front];}
}

void BFS(int x, int y){
	front =-1;
	rear =-1;
	int temp=0;
	enQueue(x);
	enQueue(y);
	enQueue(temp);
	visited[x][y] = 1;
	while(front != rear){
		x=deQueue();
		y=deQueue();
		temp=deQueue();
		visited[x][y] = 1;
		arr[x][y] = temp+1;
		count2 = temp+1;
		count_metal--;
		for(int i=0;i<4;i++){
			if(arr[x+Dx[i]][y+Dy[i]] == 1 && visited[x+Dx[i]][y+Dy[i]] == 0 && x+Dx[i] >0 && x+Dx[i]<=m && y+Dy[i] >0 && y+Dy[i] <= n){
				visited[x+Dx[i]][y+Dy[i]] = 1;
				enQueue(x+Dx[i]);
				enQueue(y+Dy[i]);
				enQueue(temp+1);
			}
		}
	}
}

int main(){
	freopen("input.txt","r",stdin);
	int T=0, t=1;
	cin >> T;
	while(t<=T){
		count1=0;
		count2=0;
		count_metal = 0;
		int x=0,y=0;
		cin >> m >> n >> x >> y;
		input();
		if(arr[xx+1][yy] == 0 || arr[xx-1][yy] == 0 || arr[xx][yy+1] == 0 || arr[xx][yy-1] == 0){
			cout << "Case #"<<t<<endl<<"-1 -1"<<endl;
		}
		else{
			BFS(x,y);
			arr[x][y] = 2;
			if(arr[xx+1][yy] == 1 || arr[xx-1][yy] == 1 || arr[xx][yy+1] == 1 || arr[xx][yy-1] == 1){
				cout << "Case #"<<t<<endl<<"-1 -1"<<endl;
			}
			else{
				for(int i=0;i<4;i++){
					if(count1 <= arr[xx+Dx[i]][yy+Dy[i]]){
						count1 = arr[xx+Dx[i]][yy+Dy[i]];
					}
				}
				if(count_metal != 0){
					cout << "Case #"<<t<<endl<<count1<<" -1"<<endl;
				}
				else
					cout << "Case #"<<t<<endl<<count1<< " "<<count2<<endl;
			}
		}
		t++;
	}
	return 0;
}