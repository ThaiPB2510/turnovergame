#include<iostream>
using namespace std;
int block = 0;
int max_sum=0;
int n=0, arr[110000];
void input(){
	for(int i=0;i<n;i++)
		cin >> arr[i];
}

void createBlock(int maxtmp){
	int tmp=0;
	int tmpBlock=0;
	for(int i=0;i<n;i++){
		tmp=tmp+arr[i];
		if(tmp >= maxtmp){
			tmp = arr[i];
			tmpBlock++;
		}	
	}
	if(tmpBlock == block){
		max_sum = maxtmp;
		return;
	}
	else
		createBlock(maxtmp+1);

}

int main(){
	int T=0, t=1, tmp=0, s=0;
	freopen("input.txt","r",stdin);
	cin >> T;
	while(t<=T){
		cin >> block;
		cin >> n;
		input();
		for(int i=0;i<n;i++){
			s=s+arr[i];
			if(arr[i] >= tmp)
				tmp = arr[i];}
		if(tmp==0){
			cout <<"#"<<t<<" "<< tmp << endl;
		}
		else if(block==1){
			cout <<"#"<<t<<" "<< s << endl;
		}
		else{
			createBlock(tmp+1);
			cout <<"#"<<t<<" "<< max_sum << endl;}
		max_sum= 0;
		tmp=0;
		s=0;
		t++;
	}
	return 0;
}