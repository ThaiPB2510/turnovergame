#include <iostream>
using namespace std;
int a[400];
int arr[100][100];
int visited[100];
int result = 0;

void input(int n){
	for(int i=0;i<100;i++){
		visited[i]=0;
		for(int j=0;j<100;j++){
			arr[i][j]=0;
		}
	}
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	for(int i=0; i<n; i++){
		arr[a[i]][a[i+1]]=1;
	}
}

void DFS(int k){
	if(k==99){
		result = 1;
		return;}
	visited[k]=1;
	for (int i = 0; i < 100 && result == 0; i++){
		if(arr[k][i] == 1 && visited[i] == 0){
			arr[k][i] = 0;
			DFS(i);
		}
	}

}
int main(){
	int T=1,t=0, n=0;
	freopen("input.txt","r",stdin);
	while(T<=10){
		cin >> t;
		cin >> n;
		input(n*2);
		DFS(0);
		cout <<"#"<<t<<" "<< result << endl;
		result =0;
		T++;
	}
	return 0;
}

