#include<iostream>
using namespace std;
char arr[10000];
int stack[10000];
int size = 10000;
int top=-1;
int check = 0;

void reset(){
	arr[0] = 0;
}

void init(){
	top=-1;
}

void push(int value){
		top++;
		stack[top]=value;
}
int pop(){
	int value=0;
		value = stack[top];
		top--;
	return value;
}

void input(int n){
	for(int i=0;i<n;i++){
		cin >> arr[i];
	}
}

int main(){
	//freopen("input.txt","r",stdin);
	int t=1,T=0,n=0;
	while(t<=10){
		cin>>n;
		input(n);
		for(int i=0;i<n;i++){
			if(arr[i] >='0' && arr[i] <= '9'){
				push(arr[i] - '0');
			}

			if(arr[i] == '*'){
				push(pop() * (arr[i+1]-'0'));
				i=i+1;
			}
		}
		for(int i=0;i<=top;i++){
			check=check+stack[i];
		}
		cout <<"#"<<t<<" "<<check<<endl;
		check=0;
		top=-1;
		t++;
	}
	return 0;
}