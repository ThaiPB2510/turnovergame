#include<iostream>
using namespace std;
int arr[1001];

void input(int n){
	for(int i=0;i<n;i++){
		cin >> arr[i];
	}
}
int main(){
	freopen("input.txt","r",stdin);
	int countt=0;
	int T=1,n,temp=1000;
	while(T<=10){
		cin >> n;
		input(n);
		for(int i=2;i<n-2;i++){
			if(arr[i] - arr[i-1] >= 1 && arr[i] - arr[i-2] >= 1 && arr[i] - arr[i+1] >= 1 && arr[i] - arr[i+2] >= 1){
				for(int j=i-2; j<i;j++){
					if(temp >= (arr[i] - arr[j])){
						temp = arr[i] - arr[j];
					}
				}

				for(int j=i+2; j>i;j--){
					if(temp >= (arr[i] - arr[j])){
						temp = arr[i] - arr[j];
					}
				}
				countt = countt+temp;
			}
			temp=1000;
		}
		cout <<"#"<<T<<" "<<countt<<endl;
		countt = 0;
		T++;
	}
	while(1){}
}