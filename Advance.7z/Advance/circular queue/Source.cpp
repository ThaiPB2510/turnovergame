#include<iostream>
using namespace std;
int Dx[8] = {-2,-1,1,2,2,1,-1,-2};
int Dy[8] = {1,2,2,1,-1,-2,-2,-1};
int check[1001][1001];
int loca_x[2];
int loca_y[2];
int run=0;

struct Queue 
{ 
	int rear, front; 
	int size; 
	int *queue; 
	Queue(int s) 
	{ 
		front = rear = -1; 
		size = s; 
		queue = new int[s]; 
	} 
	void enQueue(int value); 
	int deQueue(); 
	int emty();
}; 
void Queue::enQueue(int value){
	if(rear == size - 1){
		rear=0;
		queue[rear]=value;
	}
	else{
		rear++;
		queue[rear]=value;
	}
}

int Queue::deQueue(){
	if(front == size - 1){
		front =0;
		return queue[front];
	}
	else{
		front++;
		return queue[front];
	}
}

int Queue::emty(){
	if(front == rear){
		return true;
	}
	else
		return false;
}

void reset(int m, int n){
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			check[i][j]=0;
		}
	}
}

void BFS(int x, int y, int m, int n){
	run=0;
	int Size = 24000;
	Queue Q(Size);
	Q.enQueue(x);
	Q.enQueue(y);
	Q.enQueue(run);
	check[x][y]=1;
	while(!Q.emty()){
		x=Q.deQueue();
		y=Q.deQueue();
		run=Q.deQueue();
		for(int i=0;i<8;i++){
			if(x+Dx[i] <= m && x+Dx[i] >0 && y+Dy[i] <= n && y+Dy[i] >0  && check[x+Dx[i]][y+Dy[i]] == 0 ){
				check[x+Dx[i]][y+Dy[i]] = run + 1;
				Q.enQueue(x+Dx[i]);
				Q.enQueue(y+Dy[i]);
				Q.enQueue(run+1);
			}
			if(x+Dx[i] == (loca_x[1]) && y+Dy[i]== (loca_y[1])){
				return;
			}
		}
	}
}

int main(){
	//freopen("input.txt","r",stdin);
	int T=0,t=1,m,n;
	cin >> T;
	while(t<=T){
		cin >> m;
		cin >> n;
		cin >> loca_y[0];
		cin >> loca_x[0];
		cin >> loca_y[1];
		cin >> loca_x[1];
		reset(n,m);
		BFS(loca_x[0],loca_y[0], n,m);
		cout << "Case #" <<t<< " "<<endl<<check[loca_x[1]][loca_y[1]]<<endl;
		t++;
	}
	return 0;
}