#include<iostream>
using namespace std;
int arr[101][101];

void input(){
	for(int i=0;i<100;i++){
		for(int j=0;j<100;j++){
			cin >> arr[i][j];
		}
	}
}

int search_sum_max(){
	int sum_max=0, sum=0;

	for(int i=0;i<100;i++){
		for(int j=0;j<100;j++){
			sum = sum + arr[i][j];
		}
		if(sum_max <= sum)
			sum_max = sum;
		sum=0;
	}

	for(int i=0;i<100;i++){
		for(int j=0;j<100;j++){
			sum = sum + arr[j][i];
		}
		if(sum_max <= sum)
			sum_max = sum;
		sum=0;
	}

	for(int i=0;i<100;i++){
		sum = sum + arr[i][i];
	}
	if(sum_max <= sum)
		sum_max = sum;
	sum=0;

	for(int i=0;i<100;i++){
		sum = sum + arr[i][99-i];
	}
	if(sum_max <= sum)
		sum_max = sum;
	sum=0;
	return sum_max;
}
int main(){
	//freopen("input.txt","r",stdin);
	int t=1,T;
	while(t<=10){
		cin >> T;
		input();
		cout <<"#"<<T<<" "<<search_sum_max()<<endl;
		t++;
	}
}