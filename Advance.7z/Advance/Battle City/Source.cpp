#include<iostream>
using namespace std;
int m=0,n=0;
int arr[302][302];
char abc[302][302];
int loca_x[2];
int loca_y[2];
int queue[200000];
int rear=-1, front=-1;
int dx[4]={-1,0,0,1};
int dy[4]={0,-1,1,0};

void enQueue(int value){
	if(rear == 200000-1){
		rear=0;
		queue[rear]=value;
	}
	else{
		rear++;
		queue[rear]=value;
	}

}

int deQueue(){
	if(front == 200000-1){
		front=0;
		return queue[front];
	}
	else{
		front++;
		return queue[front];

	}
}
void input(){
	for(int i=0;i<=m+1;i++){
		for(int j=0;j<=n+1;j++){
			arr[i][j]=0;
		}
	}
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin >> abc[i][j];
			if(abc[i][j] == 'Y'){
				loca_x[0]=i;
				loca_y[0]=j;
			}
			if(abc[i][j] == 'T'){
				loca_x[1]=i;
				loca_y[1]=j;
				arr[i][j]=1;
			}
			if(abc[i][j] == 'B' || abc[i][j] == 'E' ){
				arr[i][j]=1;
			}
		}

	}
}
void BFS(int x, int y){
	rear=-1;
	front = -1;
	int step=1;
	enQueue(x);
	enQueue(y);
	enQueue(1);
	arr[x][y]=0;
	while(rear != front){
		x=deQueue();
		y=deQueue();
		step=deQueue();
		for(int i=0; i<4;i++){
			if(arr[x+dx[i]][y+dy[i]] == 1){
				arr[x+dx[i]][y+dy[i]] = step+1;
				enQueue(x+dx[i]);
				enQueue(y+dy[i]);
				if(abc[x+dx[i]][y+dy[i]] == 'B')
					step=step+1;
				enQueue(step+1);
			}
		}
	}


}

int main(){
	freopen("input.txt","r",stdin);
	int T=0, t=1;
	cin >> T;
	while(t<=T){
		cin >> m >> n;
		input();
		BFS(loca_x[0], loca_y[0]);
		if(arr[loca_x[1]][ loca_y[1]]==1){
			cout <<"Case #" <<t<<endl<< "-1"<<endl;
		}
		else
			cout <<"Case #" <<t<<endl<< arr[loca_x[1]][ loca_y[1]]-1<<endl;
		t++;
	}
	return 0;
}