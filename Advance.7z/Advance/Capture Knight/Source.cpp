#include<iostream>
using namespace std;
int Dx[8] = {-2,-1,1,2,2,1,-1,-2};
int Dy[8] = {1,2,2,1,-1,-2,-2,-1};
int check[1001][1001];
int loca_x[2];
int loca_y[2];
int run=0;

struct node
{
	int data;
	node *next;
};

class linked_list
{
private:
	node *front,*rear;
public:
	linked_list()
	{
		front = NULL;
		rear = NULL;
	}

	void enQueue(int n)
	{
		node *tmp = new node;
		tmp->data = n;
		tmp->next = NULL;
		if(front == NULL)
		{
			front = tmp;
			rear = tmp;
		}
		else
		{
			rear->next = tmp;
			rear = rear->next;
		}
	}

	int deQueue(){
		int value = front->data;
		node* temp = front; 
		front = front->next; 
		delete temp; 
		return value;
	}

	int emty(){
		if(front == NULL){
			return 1;
		}
		else
			return 0;
	}
};

void reset(int m, int n){
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			check[i][j]=0;
		}
	}
}

void BFS(int x, int y, int m, int n){
	linked_list linklist;
	run=0;
	linklist.enQueue(x);
	linklist.enQueue(y);
	linklist.enQueue(run);
	check[x][y]=1;
	while(!linklist.emty()){
		x=linklist.deQueue();
		y=linklist.deQueue();
		run=linklist.deQueue();
		for(int i=0;i<8;i++){
			if(x+Dx[i] <= m && x+Dx[i] >0 && y+Dy[i] <= n && y+Dy[i] >0  && check[x+Dx[i]][y+Dy[i]] == 0 ){
				check[x+Dx[i]][y+Dy[i]] =run+ 1;
				linklist.enQueue(x+Dx[i]);
				linklist.enQueue(y+Dy[i]);
				linklist.enQueue(run+1);
			}
			//if(x+Dx[i] == (loca_x[1]) && y+Dy[i]== (loca_y[1])){
			//	return;
			//}
		}
	}
}

int main(){
	freopen("input.txt","r",stdin);
	int T=0,t=1,m,n;
	cin >> T;
	while(t<=T){
		cin >> m;
		cin >> n;
		cin >> loca_y[0];
		cin >> loca_x[0];
		cin >> loca_y[1];
		cin >> loca_x[1];
		reset(n,m);
		BFS(loca_x[0],loca_y[0], n,m);
		cout << "Case #" <<t<< " "<<endl<<check[loca_x[1]][loca_y[1]]<<endl;

		t++;
	}
	return 0;
}