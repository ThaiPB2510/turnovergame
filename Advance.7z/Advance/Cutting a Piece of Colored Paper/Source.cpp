#include <stdio.h>
int blue,white,n;
int map[200][200];

int check(int x, int y, int k){
	int i,j;
	for (i=x; i<x+k; i++){
		for (j=y; j<y+k; j++){
			if (map[x][y]!=map[i][j]) return 0;
		}
	}
	if(map[x][y]==1) blue=blue++;
	if(map[x][y]==0) white=white++;
	return 1;
}

void cut(int x, int y, int k){
	if (check(x,y,k)==1) return;
	else{
		cut(x,y,k/2);
		cut(x+k/2,y,k/2);
		cut(x,y+k/2,k/2);
		cut(x+k/2,y+k/2,k/2);
	}
}


int main(void)
{
	int test_case;
	int T,i,j;
	int Answer;
	
	scanf("%d", &T);
	
	for (test_case = 1; test_case <= T; ++test_case)
	{
		blue = 0;
		white = 0;
		scanf("%d",&n);
		for(i=0; i<n; i++){
			for(j=0; j<n; j++){
				scanf("%d", &map[i][j]);
			}
		}
		cut(0,0,n);
		printf("Case #%d\n",test_case);
		printf("%d %d\n", white, blue);
	}
	return 0; 
}