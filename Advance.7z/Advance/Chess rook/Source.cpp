#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
int arr[5][5];
char abc[5][5];
int n=0, num_max=0;
int countt=0;

void reset(){
	for(int i=1;i<=4;i++){
		for(int j=1;j<=4;j++){
			arr[i][j]=0;
		}
	}
}

void seach_max(){
	int tmp=0;
	for(int i=1;i<=4;i++){
		for(int j=1;j<=4;j++){
			if(arr[i][j] > 0)
				tmp++;
		}
	}
	if(tmp>num_max)
		num_max=tmp;

}

int check(int x, int y){
	for(int i = x-1;i>=1;i--){
		if(abc[i][y] == 'X')
			break;
		if(arr[i][y]==1)
			return 0;
	}
	for(int i=x+1;i<=n;i++){
		if(abc[i][y] == 'X')
			break;
		if(arr[i][y]==1)
			return 0;
	}
	for(int i= y-1;i>=1;i--){
		if(abc[x][i] == 'X')
			break;
		if(arr[x][i]==1)
			return 0;
	}
	for(int i=y+1;i<=n;i++){
		if(abc[x][i] == 'X')
			break;
		if(arr[x][i]==1)
			return 0;
	}
	return 1;
}

void backtrack(int x){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(abc[i][j] == '.' && check(i,j)== 1 && arr[i][j]!=1){
				arr[i][j]=1;
				countt++;
				if(countt > num_max)
					num_max = countt;
				backtrack(x+1);
				countt--;
				arr[i][j]=0;
			}
		}
	}
	return;
}

int main(){
	int T=0,t=1;
	//freopen("input.txt","r",stdin);
	cin >> T;
	while(t<=T){
		cin >> n;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++)
				cin >> abc[i][j];
		}
		n=4;
		num_max = 0;
		countt=0;
		backtrack(1);
		cout << "Case #"<<t<<endl<<num_max<<endl;
		t++;
	}
	return 0;
}