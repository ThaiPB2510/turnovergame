#include <iostream>
using namespace std;
int sum(int num1, int num2){
	int s= num1+num2;
	return s;
	
}
int main(){
	int a=2;
	while(true){
		a=a+a;
		cout << a <<" ";
	}
	return 0;
}