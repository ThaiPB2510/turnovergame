#include<iostream>
#include <time.h>
using namespace std;
int number=0;
int arr[7];
int abb[7];
int abc[11][720];
int n=0;


void cutNumber(int number){
	int tmp=0;
	n=0;
	while(number>0){
		arr[n] = number%10;
		number=number/10;
		n++;
	}
	for(int i=0;i<n/2;i++){
		tmp=arr[i];
		arr[i] = arr[n-i-1];
		arr[n-i-1]=tmp;
	}
}

void createNumber(int k){
	int tmp=0;
	for(int i=0;i<n;i++){
		tmp = tmp*10 + arr[i];
	}
	for(int i=0;i<720;i++){
		if(tmp == abc[k][i]){
			break;
		}
		else if(abc[k][i]==0){
			abc[k][i] = tmp;
			break;
		}
	}
	return;
}

void hoanVi(int k){
	int tmp=0;
	if(k<=0)
		return;
	for(int l=0;l<720;l++){
		if(abc[k][l]==0){
			break;
		}
		cutNumber(abc[k][l]);
		for(int i=0; i<n;i++){
			abb[i]=arr[i];}
		for(int i=0;i<n-1; i++){
			for(int m =0; m<n;m++){
				arr[m] = abb[m];}
			for(int j=i+1;j<n;j++){
				tmp = arr[i];
				arr[i]=arr[j];
				arr[j]=tmp;
				createNumber(k-1);
			}
		}
	}
	hoanVi(k-1);
}

int main(){
	clock_t start = clock();
	int k=0, T=0, t=1;
	int max =0;
	//freopen("input.txt","r",stdin);
	cin >> T;
	while(t<=T){
		cin >> number;
		cin >> k;
		n=0;
		for(int j=0; j<=k;j++){
			for(int i=0;i<720;i++){
				abc[j][i]=0;
			}
		}
		abc[k][0]=number;
		hoanVi(k);
		for(int i=0;i<720;i++){
			if(abc[0][i]==0){
				break;
			}
			if(max <= abc[0][i]){
				max = abc[0][i];
			}
		}
		cout <<"#Case "<<t<<endl<<max<<endl;	
		max = 0;
		t++;
	}
	clock_t finish = clock();
	double duration = (double)(finish - start) / CLOCKS_PER_SEC;
	cout << endl<<duration;
	return 0;
}