#include<iostream>
#include<stdio.h>

char arr[10000];
char temp[11];
int T;

void reset(){
	arr[0] = 0;
	temp[0] = 0;
}

int dodai(char a[]){
	int dodaih=0, i;
	for(i=0; a[i] != 0; i++){
		dodaih++;
	}
	return dodaih;
}

int main(){
	int i, j, t=1, check=0, countt=0;
	freopen("input.txt","r",stdin);
	while(t<=10){
		reset();
		scanf("%d\n", &T);
		scanf("%s", &temp);
		scanf(" %[^\n]s", &arr);

		for(i=0;i<dodai(arr);i++){
			for(j=0; j < dodai(temp);j++){
				if(arr[i+j]==temp[j])
					check++;
			}
			if(check == dodai(temp))
				countt++;
			check=0;
		
		}
		std::cout <<"#"<<T<<" "<<countt<<std::endl;
           // printf("#%d %d\n", T, countt);
			countt = 0;
			check=0;
			t++;
	}
	while(1){}
	return 0;
}