#include<iostream>
using namespace std;
int arr[100][100];
int visited[1001][1001];
int check =0;
void input(int n){
	for(int i=0;i<=n;i++){
		for(int j=0;j<=n; j++){
			arr[i][j] = 0;
		}
	}
	int k=0,l=0;
	for(int i=1;i<=n;i++){
		cin >> k;
		arr[i][0]=k;
		for(int j=1;j<=k;j++){
			cin >> l;
			arr[i][j]=l;
		}
	}
}

void DFS(int x, int y){
	if(visited[x][y]==1){
		check =1;
		return;
	}
	visited[x][y]=1;
	DFS(y,x);

}

int main(){
	int T=0,t=1, n=0;
	freopen("input.txt","r",stdin);
	cin >> T;
	while(t<=T){
		cin >> n;
		input(n);
		for(int i=1;i<=n;i++){
			if(check == 1){
				break;
			}
			if(arr[i][0] >=2){
				for(int j=1;j<=arr[i][0];j++){
					if(check == 1){
						break;
					}
					DFS(i,j);
				}
			}
		}
		if(check==1)
			cout <<"Case #"<<t<<endl<<"Yes"<<endl;
		else
			cout <<"Case #"<<t<<endl<<"No"<<endl;

		check=0;
		t++;
	}
	return 0;
}