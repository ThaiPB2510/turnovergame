#include<iostream>
using namespace std;
int arr[502][502];
int queue[50000];
int rear=-1;
int front=-1;
int dx[4]={-1,0,1,0};
int dy[4]={0,1,0,-1};
int countt=0;
void input(int n){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			cin>> arr[i][j];
		}
	}
}


void init(){
	front=-1;
	rear=-1;
}
void inqueue(int value){
	rear++;
	queue[rear]=value;
}

int dequeue(){
	front++;
	return queue[front];
}
void BFS(int x, int y, int n){
	init();
	int step=1;
	inqueue(x);
	inqueue(y);
	inqueue(1);
	arr[x][y]=0;
	while(front != rear){
		x=dequeue();
		y=dequeue();
		step=dequeue();
		for(int i=0;i<4;i++){
			if(arr[x+dx[i]][y+dy[i]]==1 && x+dx[i] >=0 && x+dx[i]<n && y+dy[i] >=0 && y+dy[i] <n ){
				arr[x+dx[i]][y+dy[i]] = step+1;
				inqueue(x+dx[i]);
				inqueue(y+dy[i]);
				inqueue(step+1);
			}
		}
	}
}

int main(){
	//freopen("input.txt","r",stdin);
	int T=0,n=0;
	int countt=0, max=0;
	cin >> T;
	int t=1;
	while(t<=T){
		cin >>n;
		input(n);
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				if(arr[i][j]==2){
					BFS(i,j,n);
				}
			}
		}
		if(arr[0][0] ==1 || arr[n-1][n-1]==1){
			cout <<"-1"<<endl;
		}
		else
			cout <<arr[0][0]+arr[n-1][n-1]-2<<endl;
		t++;
	}
	return 0;
}