﻿#include <iostream>
using namespace std;

int A[101][101];
int D[101];
int visited[101];
int total, T;
// int count;
int n;
int min_value = 1000000;

void nhap(){
	for (int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			cin >> A[i][j];
		}
	}
}

void Prim(){
	// Kết nạp điểm 0 vào cây khung
	visited[0] = 1;

	//Đếm tổng đường đi
	total = 0;

	//Đếm số đỉnh đã nằm trong cây khung
	int count = 1;

	// khoảng cách tất cả các điểm đến cây khung (hiện tại có mỗi đỉnh 0)
	for(int i=0; i<n; i++){
		D[i] = A[0][i];
	}

	while(count < n ){
		// tìm một điểm nằm ngoài cây khung và khoảng cách từ điểm đó đến cây khung là min
		min_value = 1000000;	// khoảng cách min đến cây khung
		int index = 0;	//Vị trí của điểm mà có khoảng cách min đến cây khung
		for(int i = 0; i < n; i++){
			if(visited[i] == 0 && D[i] < min_value){
				//visited[i] = 1;
				min_value = D[i];
				index  = i;
			}
		}

		// Kết nạp điểm index vào cây khung
		visited[index] = 1;
		total += min_value;
		count++;

		//Cập nhật lại khoảng cách vào mảng
		for(int i = 0; i<n; i++){
			if(visited[i] == 0 && A[i][index] < D[i]){
				D[i] = A[i][index];
			}
		}
	}
}

int main(){
//	freopen("input.txt", "r", stdin);
	cin >> T;
	for (int test_case = 1; test_case <= T; test_case++){
		cin >> n;
		for(int i = 0; i< n; i++){
			visited[i] = 0;
		}
		nhap();
		Prim();
		cout << "Case #" << test_case << endl;
		cout << total << endl;
	}
	return 0;
}
