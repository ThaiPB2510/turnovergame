import java.util.Scanner;


public class Solution {
	static int a[];
	static int n;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		a = new int[n];
		for(int i = 0;i<n;i++){
			a[i] = sc.nextInt();
		}
		MergeSort(0,n-1);
		for(int i = 0; i<n; i++){
			System.out.print(a[i] + " ");
		}
	}

	public static void MergeSort(int start, int end) {
		if (start < end) {
			int mid = (start + end) / 2;
			MergeSort(start,mid);
			MergeSort(mid+1,end);
			Merge(start,end);
		}
	}
	public static void Merge(int start, int end){
		
		int mid = (start + end)/2;
		int b1[] = new int[n/2+1];
		int b2[] = new int[n/2+1];
		int length1 = 0;
		for(int i = 0; i<=mid;i++){
			b1[length1++] = a[i];
		}
		int length2 = 0;
		for(int i = mid + 1; i<=end; i++){
			b2[length2++] = a[i];
		}
		int i = start; int i1 = 0, i2 = 0;
		while(i1 < length1 && i2 < length2){
			if(b1[i1] < b2[i2]){
				a[i++] = b1[i++];
			}else {
				a[i++] = b2[i++];
			}
		}
		while(i1 < 1){
			a[i++] = b1[i++];
		}
		while(i2 < 1){
			a[i++] = b2[i++];
		}
	}
}
