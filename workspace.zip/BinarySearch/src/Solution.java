public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static int binarySearch(int array[], int left, int right, int x) {
		if (left > right)
			return -1;
		int mid = (left + right) / 2;

		if (x == array[mid])
			return mid;

		if (x < array[mid])
			return binarySearch(array, left, mid - 1, x);

		if (x > array[mid])
			return binarySearch(array, mid + 1, right, x);
	}

}
