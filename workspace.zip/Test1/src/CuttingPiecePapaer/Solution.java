package CuttingPiecePapaer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int[][] input = new int[129][129];
	static int n, white, blue;

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			n = sc.nextInt();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					input[i][j] = sc.nextInt();
				}
			}
			white = 0;
			blue = 0;
			cat(0, 0, n);
			System.out.println("Case #" + tc);
			System.out.println(white + " " + blue);
		}
	}

	private static void cat(int i, int j, int n) {
		// TODO Auto-generated method stub
		int check = checkMau(i, j, n);
		if (check == 2) {
			cat(i, j, n / 2);
			cat(i, j + n / 2, n / 2);
			cat(i + n / 2, j, n / 2);
			cat(i + n / 2, j + n / 2, n / 2);
		}
		if (check == 0)
			white++;
		else if(check == 1)
			blue++;
	}

	private static int checkMau(int i, int j, int n) {
		for (int x = 0; x < n; x++) {
			for (int y = 0; y < n; y++) {
				if (input[i + x][j + y] != input[i][j]) {
					return 2;
				}
			}
		}
		return input[i][j];
	}
}
