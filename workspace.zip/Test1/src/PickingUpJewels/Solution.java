package PickingUpJewels;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int n;
	static int a[][] = new int[11][11];
	static boolean visited[][] = new boolean[11][11];
	static int max;

	public static void Visit(int i, int j, int total) {
		visited[i][j] = true;
		if ((i == 0) && (j == 0) && (a[i][j] == 2)) {
			total++;
		}
		if (i == n - 1 && j == n - 1) {
			if (total > max) {
				max = total;
			}
			visited[i][j] = false;
		}
		if ((j + 1) <= (n - 1)) {// right
			if (!(visited[i][j + 1]) && (a[i][j + 1] != 1)) {
				if (a[i][j + 1] == 2) {
					Visit(i, j + 1, total + 1);
				} else {
					Visit(i, j + 1, total);
				}
			}
		}
		if (j - 1 >= 0) {// left
			if (!(visited[i][j - 1]) && (a[i][j - 1] != 1)) {
				if (a[i][j - 1] == 2) {
					Visit(i, j - 1, total + 1);
				} else {
					Visit(i, j - 1, total);
				}
			}
		}
		if (i - 1 >= 0) {// up
			if (!(visited[i - 1][j]) && (a[i - 1][j] != 1)) {
				if (a[i - 1][j] == 2) {
					Visit(i - 1, j, total + 1);
				} else {
					Visit(i - 1, j, total);
				}
			}
		}
		if (i + 1 <= n - 1) {// down
			if (!(visited[i + 1][j]) && (a[i + 1][j] != 1)) {
				if (a[i + 1][j] == 2) {
					Visit(i + 1, j, total + 1);
				} else {
					Visit(i + 1, j, total);
				}
			}
		}
		visited[i][j] = false;
	}

	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= 10; tc++) {
			n = sc.nextInt();
			max = -1;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					a[i][j] = sc.nextInt();
					visited[i][j] = false;
				}
			}
			Visit(0, 0, 0);
			System.out.println(max);
		}
	}
}
