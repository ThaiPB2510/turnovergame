package TurnOverGame;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static char board[][] = new char[4][4];
	static int mang[][] = new int[4][4];
	static int res;

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		sc.nextLine();
		for (int tc = 1; tc <= test; tc++) {
			res = 17;
			System.out.println("Case #" + tc);
			for (int i = 0; i < 4; i++) {
				String s = sc.nextLine();
				for (int j = 0; j < s.length(); j++) {
					board[i][j] = s.charAt(j);
					if (board[i][j] == 'b') {
						mang[i][j] = 1;
					} else
						mang[i][j] = 0;
				}
			}
			backtrack(0, 0);
			if (res == 17)
				System.out.println("Imposible");
			else
				System.out.println(res);
			
		}
	}

	public static int backtrack(int x, int y) {
		if (x == 15) {
			if ((check() == 0 || check() == 16) && y < res)
				res = y;
			return 0;
		}
		if (y >= res)
			return 0;
		backtrack(x + 1, y);
		changecolor(x);
		backtrack(x + 1, y + 1);
		changecolor(x);
		return 0;
	}

	public static int changecolor(int x) {
		// TODO Auto-generated method stub
		int row = x / 4;
		int col = x % 4;
		mang[row][col] ^= 1;
		if (row + 1 < 4)
			mang[row + 1][col] ^= 1;
		if (row - 1 >= 0)
			mang[row - 1][col] ^= 1;
		if (col + 1 < 4)
			mang[row][col + 1] ^= 1;
		if (col - 1 >= 0)
			mang[row][col - 1] ^= 1;
		return 0;
	}

	public static int check() {
		// TODO Auto-generated method stub
		int i, j;
		int count_b = 0;
		for (i = 0; i < 4; i++) {
			for (j = 0; j < 4; j++) {
				if (mang[i][j] == 1)
					count_b++;
			}
		}
		return count_b;
	}
}
