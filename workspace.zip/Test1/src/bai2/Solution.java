package bai2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int sbt = sc.nextInt();
			int a[] = new int[1001];
			for(int i = 0; i<1000; i++){
				a[i] = sc.nextInt();
			}
			int max = 0; 
			int giatri = 0;
			
			for(int j = 0; j<=200; j++){
				int freq = 0;
				for(int i = 0; i<1000; i++){
					if(a[i] == j){
						freq++;
					}
				}
				if(freq >=max){
					max = freq;
					giatri = j;
				}
			}
			System.out.println("#"+tc+" "+giatri);
		}
	}
}
