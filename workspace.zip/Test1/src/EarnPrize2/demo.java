package EarnPrize2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;

public class demo {
	static String s;
	static int K;
	static int num[];
	static int[] M = new int[7];

	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			s = sc.next();
			K = sc.nextInt();
			num = new int[s.length()];
			for (int i = 0; i < s.length(); i++) {
				num[i] = s.charAt(i);
			}
			M[0] = getnum();
			for (int k = 1; k < s.length(); k++) {
				play(0, k);
			}

			System.out.println("Case #" + tc);
			if (K < num.length)
				System.out.println(M[K]);
			else {
				System.out.println(M[num.length - 2 + (K - num.length) % 2]);
			}
		}
	}

	public static int getnum() {
		int r = 0;
		for (int i = 0; i < num.length; i++) {
			r = r * 10 + num[i];
		}
		return r;
	}

	public static void swap(int i, int j) {
		int tmp = num[i];
		num[i] = num[j];
		num[j] = tmp;
	}

	public static void play(int stt, int Kn) {
		if (stt == Kn) {
			// check kq
			int num = getnum();
			if (M[Kn] < num)
				M[Kn] = num;
			return;
		}
		for (int i = 0; i < num.length; i++) {
			for (int j = i + 1; j < num.length; j++) {
				swap(i, j);
				play(stt + 1, Kn);
				swap(i, j);
			}
		}

	}
}