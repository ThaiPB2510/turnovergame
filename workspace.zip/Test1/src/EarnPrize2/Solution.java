package EarnPrize2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int T, n;
	static String sothe, sotraodoi;
	static boolean[] visted;
	static int[] ketqua = new int[6];
	static int[] mang;
	static int res;

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		T = sc.nextInt();
		for (int tc = 1; tc <= T; tc++) {
			sothe = sc.next().trim();
			sotraodoi = sc.nextLine().trim();
			mang = new int[sothe.length()];
			visted = new boolean[sothe.length()];

			for (int i = 0; i < sothe.length(); i++) {
				mang[i] = Integer.parseInt(String.valueOf(sothe.charAt(i)));
			}
			n = sothe.length();
			// System.out.println("Lenght: "+ n+" sothe: "+ sothe);
			res = 0;
			Sinhhoanvi(0, n);
			System.out.println("Case #" + tc);
			System.out.println(res);
		}

	}

	private static void Sinhhoanvi(int i, int n) {
		// TODO Auto-generated method stub
		if (i == n) {
			if (check1(ketqua, n) == true && check2(ketqua, n) > res) {
				res = check2(ketqua, n);
			}
			// in(n);
		} else {
			for (int j = 0; j < n; j++) {
				if (visted[j] == false) {
					ketqua[i] = mang[j];
					visted[j] = true;
					Sinhhoanvi(i + 1, n);
					visted[j] = false;
				}
			}
		}
	}

	//
	private static int check2(int[] ketqua, int n) {
		// TODO Auto-generated method stub
		int kq = 0, chiso = 0;
		for (int i = n - 1; i >= 0; i--) {
			kq += ketqua[i] * Math.pow(10, chiso);
			chiso++;
		}
		// System.out.println("ketqua: "+kq);
		return kq;
	}

	private static boolean check1(int[] ketqua, int n) {
		// TODO Auto-generated method stub
		int dem = 0;
		for (int i = 0; i < n; i++) {
			if (mang[i] != ketqua[i])
				dem++;
		}
		int tmp1 = Integer.parseInt(sotraodoi);
		int tmp2 = dem / 2;
		int tmp3 = tmp1 - tmp2;
		if (tmp1 == 2 && dem == 0)
			return true;
		if (n == 2 && dem == 0)
			return false;
		if (tmp1 < tmp2)
			return false;
		return true;
	}

	private static void in(int n) {
		// TODO Auto-generated method stub
		for (int i = 0; i < n; i++) {
			System.out.print(ketqua[i] + " ");
		}
		System.out.println();
	}
}
/*void play(int i, int k){
if(i == leng){
bool check = false;
if((K - k)%2 != 0) {
swap(leng-1,leng-2);
check = true;
int number = convert-toNumber();
if(number > answer)
answer = number;
if(check){
swap(leng-1,leng-2);
}
return;
}
if(k < K) {
for(int index = i+1; index < leng; index++){
swap(i,index);
play(i+1, k+1);
swap(i,index);
}
}
play(i+1,k);
}*/
