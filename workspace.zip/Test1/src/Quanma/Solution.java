package Quanma;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	
	static int[] Qx = new int[10000000];
	static int[] Qy = new int[10000000];
	static int[] Qd = new int[10000000];
	static int f = -1, r1 = -1;
	static int[][] p = new int[1002][1002];
	static int[] dx = {-2,-2,-1,1,2,2,1,-1};
	static int[] dy = {-1,1,2,2,1,-1,-2,-2};
	static int res = 0;
	static int r,c,s,k;
	
	public static void Push(int x, int y, int d) {
		f++;
		Qx[f] = x;
		Qy[f] = y;
		Qd[f] = d;
	}

	public static void Pop(int[] tmp) {
		r1++;
		tmp[0] = Qx[r1];
		tmp[1] = Qy[r1];
		tmp[2] = Qd[r1];
	}
	
  	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			int n = sc.nextInt();
			int m = sc.nextInt();
			for(int i = 1; i<=1001; i++){
				for(int j = 1; j<=1001; j++){
					p[i][j] = 0;
				}
			}
			r = sc.nextInt(); c = sc.nextInt(); s = sc.nextInt(); k = sc.nextInt();
			Push(r,c,0);
			p[r][c] = 1;
			boolean check = false;
			
			while(f!=r1){
				int tmp[] = new int[3];
				Pop(tmp);
				int a = tmp[0], b = tmp[1], d = tmp[2];
				int dd = d + 1;
				for(int i = 0; i<8; i++){
					int aa = a + dx[i];
					int bb = b + dy[i];
					if(aa > 0 && aa <=n && bb > 0 && bb <=m && p[aa][bb] == 0){
						p[aa][bb] = 1;
						Push(aa,bb,dd);
						if(aa == s && bb == k){
							res =  d + 1;
							i = 8;
							f = r1;
						}
					}
				}
			}
			f = -1; r1= -1;
			
			System.out.println("Case #"+tc);
			System.out.println(res);
		}

	}

}
