package Password2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("pass.txt"));
		Scanner sc = new Scanner(System.in);
		for(int tc = 1; tc<=10; tc++){
			String n = sc.next();
			String s = sc.nextLine();
			char[] tmp = s.toCharArray();
			int i = 0;
			int l = tmp.length;
			for(i = 0; i<l-1; i++){
				if(tmp[i] == tmp[i+1]){
					for(int j = i; j<l-2; j++){
						tmp[j] = tmp[j+2];
					}
					i=0;
					l -= 2;
				}
			}
			System.out.print("#"+tc+" ");
			for(int m = 0; m<l; m++){
				System.out.print(tmp[m]);
			}
			System.out.println();
		}
	}
}
