package Calculator1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for(int tc = 1; tc<=10; tc++){
			String length = sc.nextLine();
			String s = sc.nextLine();
			String[] tmp = s.split("\\+");
			int tong = 0;
			for(int i = 0; i<tmp.length; i++){
				tong += Integer.parseInt(tmp[i]);
			}
			System.out.println("#"+tc+" "+tong);
		}
	}
}
