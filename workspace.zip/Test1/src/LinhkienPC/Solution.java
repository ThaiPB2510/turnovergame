package LinhkienPC;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution {
	static int T, n, m, answer, k, cost, mincost;
	static int a[][], need[], check[];

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		T = sc.nextInt();

		for (int tc = 1; tc <= T; tc++) {
			n = sc.nextInt();
			a = new int[100][n + 1];

			for (int i = 1; i <= n; i++) {
				a[i][0] = sc.nextInt();
				a[i][i] = 1;
			}
			m = sc.nextInt();
			for (int i = 1; i <= m; i++) {
				a[n + i][0] = sc.nextInt();
				int items = sc.nextInt();
				for (int j = 0; j < items; j++) {
					int index = sc.nextInt();
					a[n + i][index] = 1;
				}
			}
			check = new int[n + m + 1];

			k = sc.nextInt();

			need = new int[k];
			for (int i = 0; i < k; i++) {
				need[i] = sc.nextInt();
			}

			mincost = 1000000000;
			cost = 0;
			run(0);

			System.out.println("#" + tc + " " + mincost);
		}

	}

	private static void run(int i) {
		if (cost >= mincost)
			return;
		if (i == k) {
			if (cost < mincost) {
				mincost = cost;
			}
			return;
		} else {
			for (int j = 1; j <= m + n; j++) {
				if (a[j][need[i]] == 1) {
					if (check[j] == 0) {
						check[j] = 1;
						cost = cost + a[j][0];
						run(i + 1);
						cost = cost - a[j][0];
						check[j] = 0;
					} else if (check[j] == 1) {
						run(i + 1);
					}
				}
			}
		}
	}
}