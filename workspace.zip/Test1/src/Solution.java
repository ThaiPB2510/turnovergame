import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	
    public static void main(String[] args) throws FileNotFoundException {
    	System.setIn(new FileInputStream("input.txt"));
        Scanner sc = new Scanner(System.in);
        
        for(int tc = 1; tc<=10; tc++){
        	int sbt = sc.nextInt();
            int n = sc.nextInt();
            int k = sc.nextInt();
            long tong = powWord(n,k);
            System.out.println("#"+tc+" "+tong);
        }
    }

    private static long powWord(int n, int k) {
        if(k==1) return n;
        else return (n*powWord(n, k-1));
    }
}
