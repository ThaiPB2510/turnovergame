package stocl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException  {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int sbt = sc.nextInt();
		for (int tc = 1; tc <= sbt; tc++) {
			int songay = sc.nextInt();
			int[] mang = new int[songay + 1];
			for (int i = 0; i < songay; i++) {
				mang[i] = sc.nextInt();
			}

			int profit = 0;
			int dau = 0;
			int cuoi = songay - 1;
			while (dau < cuoi) {
				int[] tmp = max(dau, cuoi, mang);
				int tienvon = 0;
				int ngay = 0;
				for (int i = dau; i <= tmp[1] - 1; i++) {
					tienvon += mang[i];
					ngay++;
				}
				if (ngay != 0) {
					profit += mang[tmp[1]] * ngay  - tienvon;
				}
				dau = tmp[1] + 1;

			}
			System.out.println("#" + tc + " " + profit);

		}

	}

	private static int[] max(int dau, int cuoi, int[] mang) {
		// TODO Auto-generated method stub
		int[] kq = new int[2];
		int max = mang[dau];
		int chiso = dau;
		for (int i = dau + 1; i <= cuoi; i++) {
			if (mang[i] > max) {
				max = mang[i];
				chiso = i;
			}
		}
		kq[0] = max;
		kq[1] = chiso;
		return kq;
	}

}