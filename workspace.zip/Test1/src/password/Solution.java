package password;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner scanner = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int k = scanner.nextInt();
			int[] a = new int[8];
			for (int i = 0; i < 8; i++) {
				a[i] = scanner.nextInt();
			}
			boolean tmp = true;
			int count = 1;
			while (tmp == true) {
				int f = a[0];
				for (int i = 0; i < 7; i++) {
					a[i] = a[i + 1];
				}
				a[7] = f - count;
				count++;
				if (count == 6) 
					count = 1;
				
				if (a[7] <= 0) {
					a[7] = 0;
					tmp = false;
				}
			}
			System.out.print("#" + tc + " ");
			for (int i = 0; i < 8; i++) {
				System.out.print(a[i] + " ");
			}
			System.out.println();
		}
	}

}
