package Crypt2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int a[] = new int[1000000];
	static int b[] = new int[1000000];

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int n = sc.nextInt();
			for (int i = 0; i < n; i++) {
				a[i] = sc.nextInt();
			}
			int command = sc.nextInt();

			for (int c = 0; c < command; c++) {
				String s = sc.next();
				if (s.equals("I")) {
					int x = sc.nextInt();
					int y = sc.nextInt();
					int k = 0;
					for (int i = 0; i < x; i++) {
						b[k] = a[i];
						k++;
					}
					for (int i = 0; i < y; i++) {
						b[k] = sc.nextInt();
						k++;
					}
					for (int i = x; i < n; i++) {
						b[k] = a[i];
						k++;
					}
					for (int i = 0; i < k; i++) {
						a[i] = b[i];
					}
					n = k;
				}

				if (s.equals("D")) {
					int x = sc.nextInt();
					int y = sc.nextInt();
					for (int i = x; i < n - y; i++) {
						a[i] = a[i + y];
					}
				}
				if(s.equals("A")){
					int y = sc.nextInt();
					int[] tmp =  new int[y+1];
					
					for(int i = 0; i<y; i++){
						tmp[i] = sc.nextInt(); 
					}
					int k = 0;
					for(int i = 0; i<n; i++){
						b[k] = a[i];
						k++;
					}
					for(int i = n; i < y; i++){
						b[k] = tmp[i];
						k++;
					}
					for(int i = 0; i<k; i++){
						a[i] = b[i];
					}
					n = k;
				}
			}
			System.out.print("#" + tc + " ");
			for (int i = 0; i < 10; i++) {
				System.out.print(a[i] + " ");
			}
			System.out.println();
		}
	}

}
