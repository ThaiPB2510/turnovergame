package TheFrog;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	static int M[][] = new int[1000][1000];
	static int n;
	static int vitri[][] = new int[1000][3];
	static int visited[] = new int[1000];
	static int d[] = new int[1000];
	static int sum = 0;

	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			n = sc.nextInt();
			for (int i = 0; i < n; i++) {
				vitri[i][0] = sc.nextInt();
				vitri[i][1] = sc.nextInt();
				vitri[i][2] = sc.nextInt();
				for (int j = 0; j < i; j++) {
					int distance = (vitri[j][0] - vitri[i][0])* (vitri[j][0] - vitri[i][0])	+ (vitri[j][1] - vitri[i][1])* (vitri[j][1] - vitri[i][1]);
					int d40 = (vitri[j][2] + vitri[i][2] + 40) * (vitri[j][2] + vitri[i][2] + 40);
					int d90 = (vitri[j][2] + vitri[i][2] + 90)* (vitri[j][2] + vitri[i][2] + 90);

					if (distance <= d40) {
						M[i][j] = 1;
						M[j][i] = 1;
					} else if (distance > d40 && distance <= d90) {
						M[i][j] = 1000;
						M[j][i] = 1000;
					} else {
						M[i][j] = 1000000;
						M[j][i] = 1000000;
					}
				}
			}
			for (int i = 0; i < n; i++) {
				d[i] = 10000000;
				visited[i] = 0;
			}
			int res = dijsktra(0, n - 1);
			if (res >= 1000000) {
				System.out.println(-1);
			} else {
				System.out.println(res / 1000 + " " + res % 1000);
			}
		}
	}

	private static int dijsktra(int start, int end) {
		// TODO Auto-generated method stub
		visited[start] = 1;
		d[start] = 0;
		while (true) {
			for (int i = 0; i < n; i++) {
				if (visited[i] == 0 && M[start][i] + d[start] < d[i]) {
					d[i] = M[start][i] + d[start];
				}
			}
			int vt = -1;
			int min = 10000000;
			for (int i = 0; i < n; i++) {
				if (visited[i] == 0 && d[i] < min) {
					min = d[i];
					vt = i;
				}
			}
			if (vt == -1)
				break;
			if (vt == end) {
				return min;
			}
			start = vt;
			visited[start] = 1;

		}
		return -1;
	}
}
