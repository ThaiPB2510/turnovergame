import java.util.ArrayList;
import java.util.Scanner;


public class dscanh {
	static int n, m;
	static ArrayList<Integer> dske[] = new ArrayList[1001];
	static boolean chuaxet[] = new boolean[1001];
	static int truoc[] = new int[1001];
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		for(int i = 1; i<=n; i++){
			int u = sc.nextInt(); int v = sc.nextInt();
		}
	}

}
