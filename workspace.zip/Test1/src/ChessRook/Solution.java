package ChessRook;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static char chess[][] = new char[5][5];
	static int visited[][] = new int[5][5];
	static int n, max = 0, count = 0;

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			System.out.println("Case #" + tc);
			n = sc.nextInt();
			init();
			sc.nextLine();
			for (int i = 0; i < n; i++) {
				String s = sc.nextLine();
				for(int j = 0; j<s.length(); j++){
					chess[i][j] = s.charAt(j);
				}
			}
			max = 0;
			count = 0;

			backtrack(0);
			System.out.println(max);
		}
	}

	public static void backtrack(int x) {
		// TODO Auto-generated method stub
		if (x > n * n)
			return;
		if (x == n * n) {
			if (max < count) {
				max = count;
			}
			return;
		}
		for (int i = x; i < n * n; i++) {
			int row = i/n;
			int col = i%n;
			if(chess[row][col]=='.'&& check(i)){
				visited[row][col] = 1;
				count++;
				backtrack(i+1);
				visited[row][col] = 0;
				count--;
			}
		}
		backtrack(n*n);
	}

	public static boolean check(int x) {
		int row = x / n;
		int col = x % n;
		for (int i = row - 1; i >= 0; i--) {
			if (chess[i][col] == 'X') {
				break;
			}
			if (chess[i][col] == '.' && visited[i][col] == 1) {
				return false;
			}
		}
		for (int i = col - 1; i >= 0; i--) {
			if (chess[row][i] == 'X') {
				break;
			}
			if (chess[row][i] == '.' && visited[row][i] == 1) {
				return false;
			}
		}
		return true;

	}

	public static void init() {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				visited[i][j] = 0;
			}
		}
	}
}
