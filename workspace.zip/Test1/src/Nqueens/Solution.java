package Nqueens;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	static int board[][] = new int[8][8];
	static int sum, sumMax;
	static int visited[][] = new int[8][8];

	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			System.out.println("Case #" + tc);
			int n = sc.nextInt();
			for (int q = 0; q < n; q++) {
				init();
				for (int i = 0; i < 8; i++) {
					for (int j = 0; j < 8; j++) {
						board[i][j] = sc.nextInt();
					}
				}
				sumMax = 0;
				sum = 0;
				backtrack(0);
				System.out.println(sumMax);
			}
		}
	}

	private static void backtrack(int row) {
		// TODO Auto-generated method stub
		if (row == 8) {
			if (sumMax < sum) {
				sumMax = sum;
				return;
			}
		}
		for (int i = 0; i < 8; i++) {
			if (check(row, i)) {
				visited[row][i] = 1;
				sum += board[row][i];
				backtrack(row + 1);
				visited[row][i] = 0;
				sum -= board[row][i];
			}
		}
	}

	private static boolean check(int x, int y) {
		// TODO Auto-generated method stub
		for(int i = x-1; i >= 0; i--){
			if(visited[i][y] == 1){
				return false;
			}
		}
		int a = x - 1;
		int b = y + 1;
		while(a >= 0 && b < 8){
			if(visited[a][b]==1){
				return false;
			}
			a--;
			b++;
		}
		a = x - 1;
		b = y - 1;
		while(a >= 0 && b >= 0){
			if(visited[a][b] == 1){
				return false;
			}
			a--;
			b--;
		}
		return true;
	}

	public static void init() {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				board[i][j] = visited[i][j] = 0;
			}
		}
	}

}
