package Princess;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int[] dx = { -1, 0, 1, 0 };
	static int[] dy = { 0, 1, 0, -1 };
	static int[] Qx;
	static int[] Qy;
	static int f = -1, r = -1, n;
	static int[][] mang;
	static boolean[][] visited;
	static int[][] step;

	public static void Push(int x, int y) {
		f++;
		Qx[f] = x;
		Qy[f] = y;
	}

	public static void Pop(int[] tmp) {
		r++;
		tmp[0] = Qx[r];
		tmp[1] = Qy[r];
	}

	public static int BFS(int x, int y, int xE, int yE) {
		Push(x, y);
		visited[x][y] = true;
		while (f != r) {
			int[] tmp = new int[2];
			Pop(tmp);
			int a = tmp[0], b = tmp[1];

			for (int i = 0; i < 4; i++) {
				int aa = a + dx[i];
				int bb = b + dy[i];
				if (aa == xE && bb == yE) {
					return step[a][b] + 1;
				}
				if (aa > 0 && aa <= n && bb > 0 && bb <= n
						&& visited[aa][bb] == false && mang[aa][bb] == 1) {

					visited[aa][bb] = true;
					Push(aa, bb);
					step[aa][bb] = step[a][b] + 1;
				}
			}
		}
		return -1;
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			n = sc.nextInt();
			int x = 0, y = 0;
			mang = new int[n+1][n+1];
			step = new int[n+1][n+1];
			visited = new boolean[n+1][n+1];
			Qx = new int[1000000];
			Qy = new int[1000000];
			for (int i = 1; i <= n; i++) {
				for (int j = 1; j <= n; j++) {
					mang[i][j] = sc.nextInt();
					if (mang[i][j] == 2) {
						x = i;
						y = j;
					}
				}
			}
			int p1 = BFS(1, 1, x, y);
			Qx = new int[1000000];
			Qy = new int[1000000];
			visited = new boolean[n + 1][n + 1];
			f = -1;
			r = -1;
			int p2 = BFS(x, y, n, n);
			
			
			if (p1 == -1 || p2 == -1)
				System.out.println(-1);
			else
				System.out.println(p1 + p2);
		}
	}

}
