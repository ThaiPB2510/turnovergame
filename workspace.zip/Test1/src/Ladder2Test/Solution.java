package Ladder2Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for(int tc = 1; tc<=10; tc++){
			int t = sc.nextInt();
			int[][] a = new int[102][102];
			int[] b = new int[102];
			int k = 0;
			for(int i = 0; i<100; i++){
				for(int j = 0; j<100; j++){
					a[i][j] = sc.nextInt();
					if(i==0){
						a[i][j] = sc.nextInt();
						if(a[i][j] == 1){
							b[k] = 1;
							k++;
						}
					}else{
						a[i][j] = sc.nextInt();
					}
				}
			}
			int min = 9999999;
			int res = 0;
			for(int j = 0; j<k; j++){
				int count = 1;
				int col = b[j];
				int tmp = j;
				int i = 99;
				while(i > 0){
					//B4; Xet ben trai xem co = 1 hay khong;
					if(cot - 1 >= 0 && mang[i][cot-1] == 1){
						soBuoc += (thang[t] - thang[t-1]);
						cot = thang[t - 1];//B4.1: re trai => nhay sang cot phia ben trai voi mang da tim o B1
						t--;
						i--;
						soBuoc++;
					}
					else if (cot + 1 < 100 && mang[i][cot+1] == 1) {//B5: xet ben phai xem co = 1 hay khong?
						soBuoc += (thang[t+1] - thang[t]);
						cot = thang[t + 1];//B5.1: re phai => nhay sang cot phia ben phai voi mang da tim o B1
						t++;
						i--;
						soBuoc++;
					}
					else { //B6: neu B4 va B5 deu sai: di thang len tren
						i--;
						soBuoc++;
					}
				}
				if(soBuoc <= min) {
					min = soBuoc;
					kq = cot;
				}
			}
			
			System.out.println("#"+tc+" "+kq);
		}
	}
}
