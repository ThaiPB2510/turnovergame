package Ladder1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int tmp = sc.nextInt();
			int col_index = 0;
			int[][] arr = new int[100][100];
			for (int i = 0; i < 100; i++) {
				for (int j = 0; j < 100; j++) {
					arr[i][j] = sc.nextInt();
					if(arr[i][j] == 2){
						col_index = j;
					}
				}
			}
			for(int i = 99; i>=0; i--){
				if(col_index - 1 >=0 && arr[i][col_index-1] == 1){
					for(int j = col_index; j>=0; j--){
						if(arr[i][j] == 0){
							col_index = j+1;
							break;
						}
						if(j == 0) col_index = 0;
					}
				}
				else if(col_index + 1 <100 && arr[i][col_index+1] == 1){
					for(int j = col_index; j<100; j++){
						if(arr[i][j]==0){
							col_index = j - 1;
							break;
						}
						if (j == 99)
							col_index = 99;
					}
				}
			}
			System.out.println("#"+tc+" "+col_index);
		}

	}
}
