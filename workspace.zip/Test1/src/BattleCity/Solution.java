package BattleCity;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	static int[] Qx = new int[1000000];
	static int[] Qy = new int[1000000];
	static int[] Qd = new int[1000000];
	static int f = -1, r = -1;
	static int[][] Map = new int[502][502];
	static int[][] check =  new int[502][502];
	static int[] dx = { 0, 1, 0, -1 };
	static int[] dy = { 1, 0, -1, 0 };
	static int ketqua = 1;

	public static void Push(int x, int y, int d) {
		f++;
		Qx[f] = x;
		Qy[f] = y;
		Qd[f] = d;
	}

	public static void Pop(int[] tmp) {
		r++;
		tmp[0] = Qx[r];
		tmp[1] = Qy[r];
		tmp[2] = Qd[r];
	}

	public static void BFS(int x, int y) {
		Push(x, y, 1);
		check[x][y] = 0;
		int min = 99999;
		while (f != r) {
			int[] tmp = new int[3];
			Pop(tmp);
			int a = tmp[0], b = tmp[1], d = tmp[2];
			d++;
				for (int i = 0; i < 4; i++) {
					int aa = a + dx[i];
					int bb = b + dy[i];
					if (3 == Map[aa][bb]) {
						Map[aa][bb] = -1;
						Push(aa, bb, dd2);
					} else if (4 == Map[aa][bb]) {
						Map[aa][bb] = -1;
						Push(aa, bb, dd1);
					} else if (2 == Map[aa][bb]) {
						Map[aa][bb] = -1;
						Push(aa, bb, dd1);
						i = 3;
						f = r;
					}
				}
			}
		
		
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			int n = sc.nextInt();
			int m = sc.nextInt();
			String tmp = sc.nextLine();
			int[][] a = new int[n + 2][m + 2];
			int Xstart = 0;
			int Ystart = 0;
			for (int i = 1; i <= n; i++) {
				String s = sc.nextLine();
				for (int j = 0; j < s.length(); j++) {
					if (s.charAt(j) == 'Y') {
						Map[i][j + 1] = 1;
						Xstart = i;
						Ystart = j + 1;
					}
					if (s.charAt(j) == 'T') {
						Map[i][j + 1] = 2;
					}
					if (s.charAt(j) == 'B') {
						Map[i][j + 1] = 3;
					}
					if (s.charAt(j) == 'E') {
						Map[i][j + 1] = 4;
					}
					if (s.charAt(j) == 'S' || s.charAt(j) == 'R') {
						Map[i][j + 1] = 0;
					}
				}
			}
			BFS(Xstart, Ystart);
			System.out.println("Case #" + tc);
			System.out.println(ketqua);
			
		}
	}
}
