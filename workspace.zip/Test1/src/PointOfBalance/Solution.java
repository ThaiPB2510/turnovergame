package PointOfBalance;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int n;
	static int x[], m[];
	static double res;

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			n = sc.nextInt();
			x= new int[n + 1];
			m = new int[n + 1];
			for (int i = 0; i < n; i++) {
				x[i] = sc.nextInt();
			}
			for (int i = 0; i < n; i++) {
				m[i] = sc.nextInt();
			}
			System.out.print("#"+tc+" ");
			for (int i = 0; i < n - 1; i++) {
				double mid = (double) (x[i] + x[i + 1]) / 2;
				String s = String.format("%.10f", mid);
				mid = Double.parseDouble(s);
				res = 0;

				tinh(mid, x[i], x[i + 1]);
				System.out.print(String.format("%.10f", res) + " ");
			}
			System.out.println();
		}
		}

	private static void tinh(double mid, double start, double end) {
		// TODO Auto-generated method stub
		double F1 = 0, F2 = 0;
		for (int i = 0; i < n; i++) {
			if (x[i] < mid) {
				F1 += (m[i]) / (Math.pow(mid - x[i], 2));
			}
			if (x[i] > mid) {
				F2 += (m[i]) / (Math.pow(mid - x[i], 2));
			}
		}
		if (Math.abs(F1 - F2) < 1e-9) {
			res = mid;
			return;
		}
		if (F1 > F2) {
			start = mid;
			double tmp = (double) (mid + end) / 2;
			String s = String.format("%.10f", tmp);
			mid = Double.parseDouble(s);
			tinh(tmp, start, end);
		} else if (F2 > F1) {
			end = mid;
			double tmp = (double) (mid + start) / 2;
			String s = String.format("%.10f", tmp);
			mid = Double.parseDouble(s);
			tinh(tmp, start, end);
		}

	}
}
