package Plaindrome1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			String temp = sc.nextLine();
			int d = Integer.parseInt(temp);
			char[][] c = new char[9][9];
			for (int i = 0; i < 8; i++) {
				String s = sc.nextLine();
				for (int j = 0; j < s.length(); j++) {
					c[i][j] = s.charAt(j);
				}
			}
			int res = 0;
			for (int i = 0; i < 8; i++) {
				for (int j = 0; j <= 8 - d; j++) {
					String tmp = "";
					for (int k = j; k < j + d; k++) {
						tmp += String.valueOf(c[i][k]);
					}
					if (check(tmp) == true)
						res++;
				}

			}
			for (int j = 0; j < 8; j++) {
				for (int i = 0; i <= 8 - d; i++) {
					String tmp = "";
					for (int k = i; k < i + d; k++) {
						tmp += String.valueOf(c[k][j]);
					}
					if (check(tmp) == true)
						res++;
				}

			}
			System.out.println("#"+tc+" "+res);
		}
	}

	private static boolean check(String tmp) {
		// TODO Auto-generated method stub
		for(int i=0; i<=tmp.length()/2; i++){
			if(tmp.charAt(i) != tmp.charAt(tmp.length()-1-i)) return false;
		}
		return true;
	}
}
