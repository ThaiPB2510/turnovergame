package Vision;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int n = sc.nextInt();
			int[] a = new int[n+1];
			for (int i = 1; i <= n; i++) {
				a[i] = sc.nextInt();
			}
			int res = 0;
			for (int i = 1; i <= n; i++) {
				if (a[i] > a[i - 1] && a[i] > a[i - 2] && a[i] > a[i + 1]
						&& a[i] > a[i + 2]) {
					res += a[i] - Max(a[i - 1], a[i - 2], a[i + 1], a[i + 2]);
				}
			}
			System.out.println("#"+tc+" "+res);
		}
	}

	private static int Max(int i, int j, int k, int l) {
		int max = i;

		if (j > max)
			max = j;
		if (k > max)
			max = k;
		if (l > max)
			max = l;
		return max;
	}

}
