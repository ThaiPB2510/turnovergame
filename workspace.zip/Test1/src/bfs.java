import java.util.*;

public class bfs {
	static int n, m;
	static ArrayList<Integer> dske[] = new ArrayList[1001];
	static boolean chuaxet[] = new boolean[1001];
	static int truoc[] = new int[1001];

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		while (test-- > 0) {
			n = sc.nextInt();
			m = sc.nextInt();
			for (int i = 1; i <= n; i++) {
				dske[i] = new ArrayList<>();
				chuaxet[i] = true;
				truoc[i] = 0;
			}
			for (int i = 1; i <= m; i++) {
				int u = sc.nextInt(), v = sc.nextInt();
				dske[u].add(v);
				dske[v].add(u);
			}
			for (int i = 1; i <= n; i++) {
				System.out.print(i + ": " );
				for (int j = 0; j < dske[i].size(); j++) {
					System.out.print( dske[i].get(j)+" ");
				}
				System.out.println();
			}
		}
	}
}
