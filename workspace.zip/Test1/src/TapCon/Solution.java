package TapCon;

import java.util.Scanner;

public class Solution {
	static int a[] = new int[6];
	static int res[] = new int[3];
	static boolean b[] = new boolean[6];
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num[] = new int[4];
		for(int i = 0; i<4; i++){
			num[i] = sc.nextInt();
		}
		quayLui(0,0);
	}

	private static void quayLui(int i, int sum) {
		if(i==6){
			return;
		}
		if(sum == 0){
			show();
		}
		b[i] = false;
		quayLui(i+1,sum+a[i]);
		b[i] = false;
		quayLui(i+1,sum);
	}

	private static void show() {
		// TODO Auto-generated method stub
		for(int j = 0; j<num.length; j++){
			System.out.print(res[j]);
		}
		System.out.println();
	}

	
}

