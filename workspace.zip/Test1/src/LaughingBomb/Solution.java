package LaughingBomb;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int[] dx = { -1, 0, 1, 0 };
	static int[] dy = { 0, 1, 0, -1 };

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			int n = sc.nextInt();
			int m = sc.nextInt();
			int a[][] = new int[m + 2][n + 2];
			boolean[][] flags = new boolean[m + 2][n + 2];
			for (int i = 1; i <= m; i++) {
				for (int j = 1; j <= n; j++) {
					a[i][j] = sc.nextInt();
				}
			}
			int x = sc.nextInt();
			int y = sc.nextInt();

			for (int i = 0; i < 4; i++) {
				int r = y + dx[i];
				int c = x + dy[i];
				if (r > 0 && r <= m && c > 0 && c <= n) {
					if (a[r][c] > 0) {
						a[r][c] = 2;
					}
				}
			}
			flags[y][x] = true;
			
			int count = 2;
			while (true) {
				boolean check = false;
				for (int i = 1; i <= m; i++) {
					for (int j = 1; j <= n; j++) {
						if (a[i][j] == count) {
							for (int k = 0; k < 4; k++) {
								int r = i + dx[k];
								int c = j + dy[k];
								if (r > 0 && r <= m && c > 0 && c <= n) {
									if (a[r][c] != 0 && flags[r][c] == false) {
										a[r][c] = count + 1;
										flags[r][c] = true;
										check = true;
									}
								}
							}
						}
					}
				}
				if (check == true)
					count++;
				else
					break;
			}
			System.out.println(count);
		}
	}
}
