package SkyMap;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int[] Qx = new int[1000000];
	static int[] Qy = new int[1000000];
	static int[] Qd = new int[1000000];
	static int f = -1, r = -1;
	static int[][] Map = new int[102][102];
	static int[] dx = { 0, 1, 0, -1 };
	static int[] dy = { 1, 0, -1, 0 };
	static int ketqua = 1;

	public static void Push(int x, int y, int d) {
		f++;
		Qx[f] = x;
		Qy[f] = y;
		Qd[f] = d;
	}


	public static void Pop(int[] tmp) {
		r++;
		tmp[0] = Qx[r];
		tmp[1] = Qy[r];
		tmp[2] = Qd[r];
	}

	public static void BFS(int x, int y) {
		Push(x, y, 1);
		Map[x][y] = 0;
		while (f != r) {
			int[] tmp = new int[3];
			Pop(tmp);
			int a = tmp[0], b = tmp[1], d = tmp[2];
			d++;

			for (int i = 0; i < 4; i++) {
				int aa = a + dx[i];
				int bb = b + dy[i];
				if (1 == Map[aa][bb]) {
					Map[aa][bb] = 0;
					Push(aa, bb, d);
					ketqua++;
				}
			}
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int sbt = sc.nextInt();
		for (int tc = 1; tc <= sbt; tc++) {
			int N = sc.nextInt();

			int[][] mang = new int[N + 2][N + 2];
			for (int i = 1; i <= N; i++) {
				for (int j = 1; j <= N; j++) {
					Map[i][j] = sc.nextInt();
				}
			}
			int ketquaReal = 0;
			int dem = 0;
			while (true) {
				boolean check = false;
				for (int i = 1; i <= N; i++) {
					for (int j = 1; j <= N; j++) {
						if (Map[i][j] == 1) {
							BFS(i, j);
							ketquaReal++;
							check = true;
							j = N;
							i = N;
						}
					}
				}
				if (check == true && ketqua > dem)
					dem = ketqua;

				ketqua = 1;
				if (check == false)
					break;
			}
			System.out.println(ketquaReal + " " + dem);

		}

	}
}