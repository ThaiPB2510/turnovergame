package MatrixProduct;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static long M[][] = new long[101][101];
	static int n, m, mod = 100000007;
	static long R[][] = new long[101][101];
	static long T[][] = new long[101][101];
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for(int tc = 1; tc <= test; tc++){
			n = sc.nextInt();
			m = sc.nextInt();
			int temp;
			for(int i = 0; i<n; i++){
				for(int j = 0; j<n; j++){
					temp = sc.nextInt();
					M[i][j] = temp%mod;
					R[i][j] = temp%mod;
					T[i][j] = 0;
				}
			}
			LuyThua(m);
			System.out.println("Case #"+tc);
			 for (int i=0;i<n;i++){
			        for (int j=0;j<n;j++){
			          System.out.print(R[i][j] + " ");
			        }
			        System.out.println();
			    }
		}
	}
	public static void Nhan(boolean init){
	    for (int i=0;i<n;i++){
	        for (int j=0;j<n;j++){
	            for (int k=0;k<n;k++){
	    			if (init){
						// mu chia 2 le
	                    T[i][j] = (T[i][j]+ (R[i][k]*M[k][j])%mod)%mod;
	                } else {
						// mu chia 2 chan
	                    T[i][j] = (T[i][j]+ (R[i][k]*R[k][j])%mod)%mod;
	                }
	            }
	        }
	    }
	    for (int i=0;i<n;i++){
	        for (int j=0;j<n;j++){
	            R[i][j] = T[i][j];
	            T[i][j] = 0;
	        }
	    }
	}

	public static void LuyThua(int m){
	    if (m<=1) return;
	    if (m%2 == 0){
	        LuyThua(m/2);
	        Nhan(false);
	    } else {
	        LuyThua(m/2);
	        Nhan(false);
	        Nhan(true);
	    }
	}

}
