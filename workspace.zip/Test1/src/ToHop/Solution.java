package ToHop;

import java.util.Scanner;

public class Solution {
	static int a[] = new int[6];
	static int res[] = new int[3];
	static boolean b[] = new boolean[6];
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		for(int i = 0; i<6; i++){
			a[i] = num%10;
			num = num/10;
		}
		quayLui(0,0);
	}

	private static void quayLui(int i, int start) {
		if(i==3){
			show();
		}
		else {
			for(int j = start; j<6; j++){
				if(!b[j]){
					res[i] = a[j];
					b[j] = true;
					quayLui(i+1,j);
					b[j] = false; 
				}
			}
		}
	}

	private static void show() {
		// TODO Auto-generated method stub
		for(int j = 0; j<res.length; j++){
			System.out.print(res[j]);
		}
		System.out.println();
	}

	
}
