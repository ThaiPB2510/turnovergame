package Ladder2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int sbt = sc.nextInt();
			int[][] a = new int[101][101];
			for (int i = 0; i < 100; i++) {
				for (int j = 0; j < 100; j++) {
					a[i][j] = sc.nextInt();
				}
			}
			int col_index = 0;
			int res = 0;
			int kiemtra = 999999999;
			int tongCucBo = 0;
			for (int z = 0; z < 100; z++) {
				if (a[99][z] == 1) {
					tongCucBo = 0;
					col_index = z;
					for (int i = 99; i >= 0; i--) {
						if (col_index - 1 >= 0 && a[i][col_index - 1] == 1) {
							//tongCucBo += 99 - i;
							int tmp = col_index;
							for (int j = col_index; j >= 0; j--) {
								boolean check= true;
								if (a[i][j] == 0) {
									tongCucBo += col_index - j- 2 ;
									col_index = j + 1;
									check=false;
									j = -1;
								}
								if (j == 0 && check== true) {
									tongCucBo += tmp ;
									col_index = 0;
								}

							}

						} else if (col_index + 1 < 100 && a[i][col_index + 1] == 1) {
							//tongCucBo += 99 - i;
							int tmp = col_index;
							for (int j = col_index; j < 100; j++) {
								boolean check= true;
								if (a[i][j] == 0) {
									tongCucBo += j - col_index -2;
									col_index = j - 1;
									check=false;
									j = 100;
								}
								if (j == 99 && check== true) {
									tongCucBo += 100 - tmp;
									col_index = 99;
								}

							}

						}

					}
					for (int k = 0; k < 100; k++) {
						if (col_index - 1 >= 0 && a[k][col_index - 1] == 1) {
							tongCucBo += k+1;
							k = 100;
						} else if (col_index + 1 < 100 && a[k][col_index + 1] == 1) {
							tongCucBo += k+1;
							k = 100;
						}
					}
				}
				if(tongCucBo <  kiemtra ){
					kiemtra=tongCucBo;
					res = col_index;
				} else if(tongCucBo ==  kiemtra && col_index > res){
					kiemtra=tongCucBo;
					res = col_index;
				} 
			}

			System.out.println("#" + tc + " " + res);
		}

	}

}