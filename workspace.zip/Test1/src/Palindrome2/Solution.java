package Palindrome2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int index = 0;
			index = sc.nextInt();
			String m = sc.nextLine();
			char[][] a = new char[101][101];
			for (int i = 0; i < 100; i++) {
				a[i] = sc.nextLine().toCharArray();
			}
			int res = 0;
			int length = 99;
			while(length-->0) {
				int count = 0;
				for (int i = 0; i < 100; i++) {
					for (int j = 0; j <= 100 - length; j++) {
						String tmp = "";
						for (int k = j; k < j + length; k++) {
							tmp += String.valueOf(a[i][k]);
						}
						if (check(tmp) == true)
							count++;
					}

				}
				for (int j = 0; j < 100; j++) {
					for (int i = 0; i <= 100 - length; i++) {
						String tmp = "";
						for (int k = i; k < i + length; k++) {
							tmp += String.valueOf(a[k][j]);
						}
						if (check(tmp) == true)
							count++;
					}
				}
				if(count > 0){
					res = length;
					break;
				}
			}
			System.out.println("#"+tc+" "+res);
		}

	}

	private static boolean check(String s) {
		for (int i = 0; i <= s.length() / 2; i++) {
			if (s.charAt(i) != s.charAt(s.length() - i - 1))
				return false;
		}
		return true;
	}
}
