package LadderGame;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int N = sc.nextInt();
			int B = sc.nextInt();
			int M = sc.nextInt();
			int[][] a = new int[102][102];
			for (int i = 1; i <= M; i++) {
				int x1 = sc.nextInt();
				int y1 = sc.nextInt();
				int x2 = sc.nextInt();
				int y2 = sc.nextInt();
				a[x1][y1] = y2;
				a[x2][y2] = y1;
			}
			a[N][B] = -1;
			int x = N;
			int y = B;
			int res;
			for(;;){
				if(a[x-1][y]>0){
					x--;
					y = a[x][y];
				}
				else {
					x--;
				}
				if(x==1){
					res = y;
					break;
				}
			}
			System.out.println("#"+tc+" "+res);
		}
	}
}
