package Crypt1;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int[] a = new int[1000000];
	static int[] b = new int[1000000];
	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for(int tc = 1; tc <=10; tc++){
			int n = sc.nextInt();
			int command;
			for(int i = 0; i <n; i++){
				a[i] = sc.nextInt();
			}
			command = sc.nextInt();
			for(int cl = 0; cl < command; cl++){
				String c;
				c = sc.next();
				if(c.equals("I")){
					int x = sc.nextInt();
					int y = sc.nextInt();
					int k = 0;
					for(int i = 0; i < x; i++){
						b[k] = a[i];
						k++;
					}
					for(int i = 0; i < y; i++){
						b[k] = sc.nextInt();
						k++;
					}
					for(int i = x; i < n; i++){
						b[k] = a[i];
						k++;
					}
					for(int i = 0; i < k; i++){
						a[i] = b[i];
					}
					n = k;
				}
				if(c.equals("D")){
					int vi_tri_xoa = sc.nextInt();
					int so_luong_xoa = sc.nextInt();
					for(int i = vi_tri_xoa; i < n-1; i++){
						a[i] = a[i+so_luong_xoa];
					}

				}
				if(c.equals("A")){
					int y = sc.nextInt();
					int[] s = new int[y+1];
					for(int i = 0 ; i < y; i++){
						s[i] = sc.nextInt();
					}
					int k = 0;
					for(int i = 0; i < n; i++){
						b[k] = a[i];
						k++;
					}
					for(int i = 0; i < y; i++){
						b[k] = s[i];
						k++;
					}
					for(int i = 0; i < k; i++){
						a[i] = b[i];
					}
					n = k;
				}
				
			}
			int m = 0;
			if(n > 10){
				m = 10;
			}else {
				m = n;
			}
			System.out.print("#"+tc+" ");
			for(int i = 0; i < m; i++){
				System.out.print(a[i]+" ");
			}
			System.out.println();
		}
	}
}
