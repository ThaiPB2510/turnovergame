package Magnetic;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int sbt = sc.nextInt();
			int[][] a = new int[101][101];
			boolean[] flag = new boolean[101];
			int res = 0;
			for (int i = 0; i < 100; i++) {
				for (int j = 0; j < 100; j++) {
					a[i][j] = sc.nextInt();
					if(a[i][j] == 1){
						flag[j] = true;
					}
					else if(a[i][j] == 2 && flag[j] == true){
						res++;
						flag[j] = false;
					}
				}
			}
			/*int res  = 0;
			for(int i = 0; i<100; i++){
				for(int j = 0; j<100; j++){
					if(a[j][i] == 1){
						for(int z = j+1;z<100; z++){
							if(a[z][i] == 2){
								res++;
								j=z;
								break;
							}
						}
					}
				}
			}*/
			System.out.println("#"+tc+" "+res);
		}
	}

}
