package AssignMeeting;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int test, n, stt;

	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			n = sc.nextInt();
			int count = 1;
			int[] start = new int[n + 1];
			int[] end = new int[n + 1];
			for (int i = 0; i < n; i++) {
				stt = sc.nextInt();
				start[i] = sc.nextInt();
				end[i] = sc.nextInt();
			}
			for (int i = 0; i < n - 1; i++) {
				for (int j = i + 1; j < n; j++) {
					if (end[j] < end[i]) {
						int tmp = end[j];
						end[j] = end[i];
						end[i] = tmp;
						int tmp1 = start[j];
						start[j] = start[i];
						start[i] = tmp1;
					}
				}
			}
			int pos = end[0];
			for (int i = 1; i < n; i++) {
				if (start[i] >= pos) {
					count++;
					pos = end[i];
				}
			}
			System.out.println("Case #" + tc);
			System.out.println(count);
		}
	}
}
