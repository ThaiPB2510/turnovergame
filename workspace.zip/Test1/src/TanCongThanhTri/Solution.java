package TanCongThanhTri;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int n, sum, s;
	static int D[][] = new int[100][100];
	static int[] VS = new int[100];
	static int[] Qx = new int[1000000];
	static int[] Qy = new int[1000000];
	static int f = -1, r = -1;

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		int answer;
		for (int tc = 1; tc <= test; tc++) {
			n = sc.nextInt();
			init();
			answer = 0;
			int index, stone, connect, soluong;
			for (int i = 0; i < n; i++) {
				index = sc.nextInt();
				stone = sc.nextInt();
				soluong = sc.nextInt();
				for (int j = 0; j < soluong; j++) {
					connect = sc.nextInt();
					D[index][connect] += stone;
					D[connect][index] += stone;
					sum += stone;
				}
			}
			for (int i = 0; i < n; i++) {
				if (VS[i] == 0) {
					BFS(i);
				}
			}
			answer = sum - s;
			System.out.println("Case #" + tc);
			System.out.println(answer);
		}
	}

	public static void init() {
		for (int i = 0; i < 100; i++) {
			for (int j = 0; j < 100; j++) {
				D[i][j] = 0;
			}
			VS[i] = 0;
		}
		sum = 0;
		s = 0;
	}

	public static void Push(int x, int y) {
		f++;
		Qx[f] = x;
		Qy[f] = y;
	}

	public static void Pop(int[] tmp) {
		r++;
		tmp[0] = Qx[r];
		tmp[1] = Qy[r];
	}

	private static void BFS(int v) {
		// TODO Auto-generated method stub
		VS[v] = 1;

		for (int i = 0; i < n; i++) {
			if (D[v][i] > 0) {
				Push(v, i);
			}
		}
		while (f != r) {
			int vt = 0, max = 0, start, end;
			for (int i = 0; i < f; i++) {
				if (D[Qx[i]][Qy[i]] > max) {
					max = D[Qx[i]][Qy[i]];
					vt = i;
				}
			}
			start = Qx[vt];
			end = Qy[vt];
			s += max;
			int[] tmp = new int[2];
			
			Pop(tmp);
			if (VS[start] == 1 && VS[end] == 1) {
				s -= max;
				continue;
			}
			VS[end] = 1;
			for(int i = 0; i<n; i++){
				if(D[end][i] > 0 && VS[i]==0){
					Push(end,i);
				}
			}
		}

	}
}
