package TanCongThanhTri;

import java.io.FileInputStream;
import java.util.Scanner;

public class Demo {
	static int V;
	static int Result;
	static int matrix[][];
	static int value[];
	static boolean visit[];
	static int key[];

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int tc = 1; tc <= T; tc++) {
			V = sc.nextInt();
			Result = 0;
			matrix = new int[V][V];
			value = new int[V];
			visit = new boolean[V];
			key = new int[V];
			int u = 0, v = 0, e = 0;
			for (int i = 0; i < V; i++) {
				u = sc.nextInt();
				value[u] = sc.nextInt();
				e = sc.nextInt();
				for (int j = 0; j < e; j++) {
					v = sc.nextInt();
					matrix[u][v] = 1;
				}
			}
			for (int i = 0; i < V; i++) {
				for (int j = 0; j < V; j++) {
					if (matrix[i][j] == 1) {
						matrix[i][j] = value[i] + value[j];
					}
				}
			}
			for (int i = 0; i < V - 1; i++) {
				for (int j = i + 1; j < V; j++) {
					Result += matrix[i][j];
				}
			}
			Prim(0);
			int k = 0;
			for (int i = 0; i < V; i++) {
				k += key[i];
			}
			Result -= k;
			System.out.println("Case #"+tc);
			System.out.println(Result);
		}
	}

	private static void Prim(int start) {
		for (int i = 0; i < V; i++) {
			key[i] = 0;
			visit[i] = true;
		}
		key[start] = 0;
		for (int i = 0; i < V - 1; i++) {
			int u = timMinKey();
			visit[u] = false;
			for (int j = 0; j < V; j++) {
				if (visit[j] && j != u && matrix[u][j] >= key[j]) {
					key[j] = matrix[u][j];
				}
			}
		}
	}

	private static int timMinKey() {
		int min = 0, u = 0;
		for (int i = 0; i < V; i++) {
			if (visit[i] && key[i] >= min) {
				min = key[i];
				u = i;
			}
		}
		return u;
	}
}