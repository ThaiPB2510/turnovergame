package sum1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		for (int tc = 1; tc <= 10; tc++) {
			int[][] a = new int[102][102];
			int max = 0;
			int sbt = sc.nextInt();
			for (int i = 1; i <= 100; i++) {
				for (int j = 1; j <= 100; j++) {
					a[i][j] = sc.nextInt();
				}
			}

			for (int i = 1; i <= 100; i++) {
				int sumHori = 0;
				for (int j = 1; j <= 100; j++) {
					sumHori += a[i][j];
				}
				if (sumHori > max)
					max = sumHori;
			}
			for (int i = 1; i <= 100; i++) {
				int sumVerti = 0;
				for (int j = 1; j <= 100; j++) {
					sumVerti += a[j][i];
				}
				if (sumVerti > max)
					max = sumVerti;
			}
			int sumCross1 = 0;
			for (int i = 1; i <= 100; i++) {
				sumCross1 += a[i][i];
				if (sumCross1 > max)
					max = sumCross1;
			}
			int sumCross2 = 0;
			for (int i = 1; i <= 100; i++) {
				for (int j = 1; j <= 100; j++) {
					if (i == 100 - j) {
						sumCross2 += a[i][j];
					}
				}
				if (sumCross2 > max)
					max = sumCross2;
			}

			System.out.println("#" + tc + " " + max);
		}
	}
}
