import java.util.Scanner;
import java.util.TreeSet;


public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		TreeSet<String> ts = new TreeSet<String>();
		while(sc.hasNextLine()){
			ts.add(sc.nextLine().toLowerCase());
		}
		for(String s:ts){
			System.out.println(s);
		}
	}

}
