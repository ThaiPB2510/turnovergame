package MiniumBigSum;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	static int test, k, n, sum = 0;
	static int a[], s[];

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			k = sc.nextInt();
			n = sc.nextInt();
			a = new int[n + 1];
			int min = 0;
			int max = 0;
			for (int i = 0; i < n; i++) {
				a[i] = sc.nextInt();
			}
		
			
			System.out.println("#"+tc+" "+maxSum(a, n, k));
		}
	}

	public static int maxSum(int arr[], int n, int k)
    {
        if (n < k)
        {
           return -1;
        }
      

        int res = 0;
        for (int i=0; i<k; i++)
           res += arr[i];
      

        int curr_sum = res;
        for (int i=k; i<n; i++)
        {
           curr_sum += arr[i] - arr[i-k];
           res = Math.min(res, curr_sum);
        }
      
        return res+1;
    }
     
    
}
