package MiniumBigSum;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution1 {
	static int test, k, n, max = 0;
	static int a[];

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		test = sc.nextInt();
		for (int tc = 1; tc <= test; tc++) {
			k = sc.nextInt();
			n = sc.nextInt();
			a = new int[n + 1];
			for (int i = 0; i < n; i++) {
				a[i] = sc.nextInt();
			}
			System.out.print("#" + tc + " ");
			solve(a);
		}
	}

	public static void solve(int[] a) {
		int max = 0;
		for (int i = 0; i < n; i++) {
			if (a[i] > max)
				max = a[i];
		}
		while (true) {
			int sum = 0;
			int b = 1;
			for (int i = 0; i < n; i++) {
				sum += a[i];
				if (sum > max) {
					b++;
					sum = a[i];
				}
			}
			if (b <= k)
				break;
			max++;
		}
		System.out.print(max);
		System.out.println();
	}
}
