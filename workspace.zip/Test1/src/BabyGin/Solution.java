package BabyGin;

import java.util.Scanner;

public class Solution {
	static int a[] = new int[6];
	static int res[] = new int[6];
	static boolean b[] = new boolean[6];

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		for (int i = 0; i < 6; i++) {
			a[i] = n%10;
			n = n/10;
		}
		quayLui(0);
	}

	private static void quayLui(int i) {
		if(i==6){
			show();
		}
		else {
			for(int j = 0; j<6; j++){
				if(!b[j]){
					res[i] = a[j];
					b[j] = true;
					quayLui(i+1);
					b[j] = false; 
				}
			}
		}
	}

	private static void show() {
		// TODO Auto-generated method stub
		for(int i = 0; i<res.length; i++){
			System.out.print(res[i]);
		}
		System.out.println();
	}

}
