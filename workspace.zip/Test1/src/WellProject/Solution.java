package WellProject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution {
	
	static int[][] a = new int[101][101];
	static int[] d = new int[101];
	static boolean visited[] = new boolean[101];
	static int min;
	static int n, total;
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		for(int tc = 1; tc <= test; tc++){
			n = sc.nextInt();
			for(int i = 0; i<n; i++){
				visited[i] = false;
				for(int j = 0; j<n; j++){
					a[i][j] = sc.nextInt();
				}
			}
			Prim();
			System.out.println("Case #"+tc);
			System.out.println(total);
		}
	}

	private static void Prim() {
		// TODO Auto-generated method stub
		visited[0] = true;
		total = 0;
		int count = 1;
		for(int i = 0; i<n; i++){
			d[i] = a[0][i];
		}
		
		while(count < n){
			min = 1000000;
			int index = 0;
			for(int i = 0; i<n; i++){
				if(visited[i] == false && d[i] < min){
					min = d[i];
					index = i;
				}
			}
			visited[index] = true;
			total += min;
			count++;
			
			for(int i = 0; i<n; i++){
				if(visited[i] == false && a[i][index] < d[i]){
					d[i] = a[i][index];
				}
			}
		}
	}

}
