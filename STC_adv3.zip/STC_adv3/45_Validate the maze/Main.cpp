#include <conio.h>
#include <iostream>
#define MAX 21

using namespace std;
int T, testcase, N,M, startX, startY, endX, endY;
int Answer;
char data[MAX][MAX];
int doors[MAX][MAX];
int visited[MAX][MAX];
int dx[4] = {-1,0,0,1};
int dy[4] = {0,-1,1,0};
struct point{
	int x;
	int y;
};

point Queue[1000000];

int front, rear;

void resetQueue(){
	front=rear=0;
}

bool isEmpty(){
	return front>=rear;
}

void push(int x, int y){
	Queue[rear].x = x;
	Queue[rear].y = y;
	rear++;
}

point pop(){
	point a = Queue[front];
	front++;
	return a;
}

bool check_door(){
	int door_num=0;
	int hang[2] = {0, N-1};
	for (int i = 0; i < M; i++)
	{
		for (int hang_idx = 0; hang_idx < 2; hang_idx++)
		{
			if (data[hang[hang_idx]][i]=='.' && doors[hang[hang_idx]][i]==0)
			{
				door_num++;
				doors[hang[hang_idx]][i]=1;
				if (door_num==1)
				{
					startX=hang[hang_idx];
					startY =i;
				}
				if (door_num==2)
				{
					endX=hang[hang_idx];
					endY =i;
				}
			}
		}
		
	}

	int cot[2] = {0, M-1};
	for (int i = 0; i < N; i++)
	{
		for (int cot_idx = 0; cot_idx < 2; cot_idx++)
		{
			if (data[i][cot[cot_idx]]=='.' && doors[i][cot[cot_idx]]==0)
			{
				doors[i][cot[cot_idx]]=1;
				door_num++;
				if (door_num==1)
				{
					startX=i;
					startY =cot[cot_idx];
				}
				if (door_num==2)
				{
					endX=i;
					endY =cot[cot_idx];
				}
			}
		}
		
	}
	return door_num==2;
}

void BFS(){
	resetQueue();
	visited[startX][startY]=1;
	push(startX,startY);
	while (!isEmpty())
	{
		point temp = pop();
		int cur_x = temp.x;
		int cur_y = temp.y;
		int nx, ny;
		for (int i = 0; i < 4; i++)
		{
			nx = cur_x+dx[i];
			ny = cur_y+dy[i];

			if (nx>-1 && nx<N && ny>-1 && ny<M)
			{
				if (data[nx][ny]=='.' && visited[nx][ny]==0)
				{
					if (nx==endX && ny==endY)
					{
						Answer=1;
						return;
					}
					else{
						visited[nx][ny]=1;
						push(nx, ny);
					}
				}
			}
		}
	}
}

int main(){

	freopen("Text.txt","r",stdin);

	cin>>T;
	for (testcase = 1; testcase<=T; testcase++)
	{
		Answer = 0;
		startX =-1;
		startY =-1;
		endX =-1;
		endY =-1;
		cin>>N>>M;
		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < M; j++)
			{
				cin>>data[i][j];
				doors[i][j]=0;
				visited[i][j]=0;
			}
		}

		
		if (check_door())
		{
			BFS();
			if (Answer==1)
			{
				cout<<"valid"<<endl;
			}
			else{
				cout<<"invalid"<<endl;
			}
		}
		else{
			cout<<"invalid"<<endl;
		}
		
	}

	getch();
	return 0;
}