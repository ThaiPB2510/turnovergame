#include <conio.h>
#include <iostream>
#define MAX 21

using namespace std;
int T, testcase, N;
int Answer;
int data[MAX][MAX];
int visited[MAX][MAX];
int dx[4] = {-1,0,0,1};
int dy[4] = {0,-1,1,0};

struct point{
	int x;
	int y;
};

point Queue[1000000];

int front, rear;

void resetQueue(){
	front=rear=0;
}

bool isEmpty(){
	return front>=rear;
}

void push(int x, int y){
	Queue[rear].x = x;
	Queue[rear].y = y;
	rear++;
}

point pop(){
	point a = Queue[front];
	front++;
	return a;
}

void BFS(){
	resetQueue();
	visited[0][0]=1;
	push(0,0);
	while (!isEmpty() && Answer==0)
	{
		point temp = pop();
		int cur_x = temp.x;
		int cur_y = temp.y;
		int step = data[cur_x][cur_y];
		int nx, ny;
		for (int i = 0; i < 4; i++)
		{
			nx = cur_x+step*dx[i];
			ny = cur_y+step*dy[i];

			if (nx>-1 && nx<N && ny>-1 && ny<N)
			{
				if (visited[nx][ny]==0)
				{
					if (nx==N-1 && ny==N-1)
					{
						Answer=1;
						return;
					}
					else{
						visited[nx][ny]=1;
						push(nx, ny);
					}
				}
			}
		}
	}
}

int main(){

	freopen("Text.txt","r",stdin);

	cin>>T;
	for (testcase = 1; testcase<=T; testcase++)
	{
		Answer = 0;
		cin>>N;
		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < N; j++)
			{
				cin>>data[i][j];
				visited[i][j]=0;
			}
		}

		BFS();
		if (Answer==0)
		{
			cout<<"NO"<<endl;
		}
		else{
			cout<<"YES"<<endl;
		}
		
	}

	getch();
	return 0;
}