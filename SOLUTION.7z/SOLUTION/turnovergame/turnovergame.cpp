﻿// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include<iostream>

using namespace std;

int test_case;
int T;
int Answer;
char Map[6][6];
int visit[6][6];
int dX[4] = {0,0,1,-1};
int dY[4] = {1,-1,0,0}; 

bool change(int x, int y)
{
	for(int i = 0; i <= 3; i++)
	{
		if(Map[x][y] == 'w')
		{
			Map[x][y] == 'b';
			int xx = x + dX[i];
			int yy = y + dY[i];
			if(xx >= 1 && xx <= 4 && yy >=1 && yy <= 4)
			{
				if(Map[xx][yy] == 'w')
					Map[xx][yy] = 'b';
				if(Map[xx][yy] == 'b')
					Map[xx][yy] = 'w';
			}
		}
		if(Map[x][y] == 'b')
		{
			Map[x][y] == 'w';
			int xx = x + dX[i];
			int yy = y + dY[i];
			if(xx >= 0 && xx < 4 && yy >=0 && yy < 4)
			{
				if(Map[xx][yy] == 'w')
					Map[xx][yy] = 'b';
				if(Map[xx][yy] == 'b')
					Map[xx][yy] = 'w';
			}
		}
	}
}

bool check()
{
	int a = Map[0][0];
	for(int i = 1; i <= 4; i++)
		for(int j = 1; j <= 4; j++)
			if(Map[i][j] != a)
				return false;
	return true;
}

void dequy(int x, int y, int k)
{
	visit[x][y] = k;
	if((x == 4) && (y == 4))
	{
		////////////////todo

		return;
	}
	else
	{
		if (y == 4)
		{
			dequy(x + 1, 1, 0);
			dequy(x + 1, 1, 1);
		}
		else
		{
			dequy(x ,y + 1, 0);
			dequy(x ,y + 1, 1);
		}
	}
}

int main(int argc, char** argv)
{
	
	
	ios::sync_with_stdio(false);
	
	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/

	//freopen("input.txt", "r", stdin);
	cin >> T;

	/*
	   Read each test case from standard input.
	*/
	for(test_case = 1; test_case <= T; ++test_case)
	{
		Answer = 0;
		for(int i = 0; i < 4; i++)
			for(int j = 0; j < 4; j++)
				cin >> Map[i][j];
		/////////////////////////////////////////////////////////////////////////////////////////////
		/*
			Please, implement your algorithm from this section.
		*/
		/////////////////////////////////////////////////////////////////////////////////////////////


		// Print the answer to standard output(screen).
		cout << "#" << test_case << " " << Answer << endl;
	}
	return 0;//Your program should return 0 on normal termination.
}