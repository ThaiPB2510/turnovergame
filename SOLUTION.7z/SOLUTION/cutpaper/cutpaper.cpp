// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include<iostream>
#include<conio.h>

using namespace std;
int test_case;
	int T, N;
	int Answer;
	int Map[200][200];
	int white, blue;
	int check(int x, int y, int n)
	{
		int temp = Map[x][y];
		for(int i = x; i < x + n; i++)
			for(int j = y; j < y + n; j++)
				if(Map[i][j] != temp)
					return -1;
		return temp;
	}
	void cut(int x, int y, int n)
	{
		if(check(x,y,n) == 1)
			blue++;
		else if(check(x,y,n) == 0)
			white++;
		else
		{
			n = n/2;
			cut(x,y,n);
			cut(x,y+n,n);
			cut(x+n,y,n);
			cut(x+n,y+n,n);
		}
	}

int main(int argc, char** argv)
{
	
	
	ios::sync_with_stdio(false);
	
	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/
	

	freopen("input.txt", "r", stdin);
	cin >> T;
	
	/*
	   Read each test case from standard input.
	*/
	for(test_case = 1; test_case <= T; ++test_case)
	{
		white = 0;
		blue = 0;		
		cin >> N;
		for(int i = 0; i < N; i++)
			for(int j = 0; j < N; j++)
				cin >> Map[i][j];
		cut(0,0,N);

		/////////////////////////////////////////////////////////////////////////////////////////////
		/*
			Please, implement your algorithm from this section.
		*/
		/////////////////////////////////////////////////////////////////////////////////////////////


		// Print the answer to standard output(screen).
		cout << "Case" <<" #"<< test_case <<endl;
		cout<<white<<" "<<blue<<endl;
		
	}
	getch();
	return 0;//Your program should return 0 on normal termination.
}