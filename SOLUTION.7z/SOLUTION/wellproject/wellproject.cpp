// KRUSKAL
#include <iostream>

using namespace std;
const int MAXN = 105;

int T, N, result, inputArr[MAXN][MAXN];
int maTranCanh[MAXN * MAXN][3], indMaTranCanh, parent[MAXN], rankk[MAXN];


void formatData() {
	result = 0;
	indMaTranCanh = 0;
	for (int i = 0; i < N; i++) {//make_set
		parent[i] = i;
		rankk[i] = 0;
	}
}

int findSet(int x) {
	if (x != parent[x]) {
		parent[x] = findSet(parent[x]);
	}
	return parent[x];
}

void jointSet(int x, int y) {
	int px = findSet(x);
	int py = findSet(y);

	if (rankk[px] > rankk[py]) {
		parent[py] = px;
	}
	else {
		parent[px] = py;
		if (rankk[px] == rankk[py]) {
			rankk[py]++;
		}
	}
}

void quickSort(int left, int right) {
	int mid = maTranCanh[(left + right) / 2][2];
	int i = left, j = right;
	while (i < right || left < j) {
		while (maTranCanh[i][2] < mid) i++;
		while (maTranCanh[j][2] > mid) j--;
		if (i <= j) {
			int temp = maTranCanh[i][2];
			maTranCanh[i][2] = maTranCanh[j][2];
			maTranCanh[j][2] = temp;

			temp = maTranCanh[i][1];
			maTranCanh[i][1] = maTranCanh[j][1];
			maTranCanh[j][1] = temp;

			temp = maTranCanh[i][0];
			maTranCanh[i][0] = maTranCanh[j][0];
			maTranCanh[j][0] = temp;

			i++; j--;
		}
		else {
			if (i < right) quickSort(i, right);
			if (left < j) quickSort(left, j);
			return;
		}
	}
}

int main() {
	ios::sync_with_stdio(false);
	//freopen("input.txt", "r", stdin);
	cin >> T;
	for (int tc = 1; tc <= T; tc++) {
		cin >> N;
		formatData();
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				cin >> inputArr[i][j];
				if (i < j) {
					maTranCanh[indMaTranCanh][0] = i;
					maTranCanh[indMaTranCanh][1] = j;
					maTranCanh[indMaTranCanh++][2] = inputArr[i][j];
				}
			}
		}
		
		quickSort(0, indMaTranCanh - 1);

		for (int i = 0; i < indMaTranCanh; i++) {
			if (findSet(maTranCanh[i][0]) != findSet(maTranCanh[i][1])) {
				jointSet(maTranCanh[i][0], maTranCanh[i][1]);
				result += maTranCanh[i][2];
			}
		}

		cout << "Case #" << tc << endl;
		cout << result << endl;
	}
	return 0;
}
// PRIM
// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 
//#define _CRT_SECURE_NO_WARNINGS
#define SIZE 109

#include<iostream>

using namespace std;

int visit[SIZE];
int A[SIZE][SIZE];
int countdown;
int Answer;
int i, j;
int mini;
int jmini;

int main(int argc, char** argv) {
	int test_case;
	int T, N;
	
	ios::sync_with_stdio(false);

	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/

	//freopen("input.txt", "r", stdin);
	cin >> T;

	for (test_case = 1; test_case <= T; ++test_case) {
		Answer = 0;

		cin >> N; 
		for (i = 1; i <= N; i++){
			for (j = 1; j <= N; j++){
				cin >> A[i][j];		
			}
			visit[i] = 0;
		}

		// PRIM
		// Add 1st vertex to MST
		visit[1] = 1; 
		countdown = 1;		
		//Add one by one vertex to MST
		while (countdown < N) {
			//Find the minimum weight vertex
			mini = 1000000;
			for (i = 1; i <= N; i++) {
				if (visit[i] == 1) {
					for (j = 1; j <= N; j++){
						if (j != i && visit[j] == 0) {
							if (A[i][j] < mini) {
								mini = A[i][j];
								jmini = j;
							}						
						}				
					}				
				}			
			}
			//Add found vertex
			visit[jmini] = 1;
			Answer += mini;
			countdown++;
		}


		// Print the answer to standard output(screen).
		cout << "Case #" << test_case << endl; 
        cout << Answer << endl;
	}
	return 0;//Your program should return 0 on normal termination.
}