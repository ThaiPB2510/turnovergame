#include <stdio.h>

int a[3005][3005];
int xS,yS,N,M,xStart,yStart;
int Answer1, Answer2;
int dX[4] = {-1,0,1,0};
int dY[4] = {0,1,0,-1};
int xQueue[9000009],yQueue[9000009];
long front,  rear;
void resetQueue()
{
	front = 0; rear = 0;
}
void push(int x, int y)
{
	xQueue[rear] = x; yQueue[rear] = y;
	rear++;
}

long pop()
{
	long a = xQueue[front]*10000 + yQueue[front];
	front++;
	return a;
}

int isEmpty()
{
	if(front >= rear) return 1;
	else return 0;
}

void BFS(int xStart, int yStart)
{
	int k;
	int count = 0;
	resetQueue();
	push(xStart, yStart);
	while(!isEmpty())
	{
		long temp = pop();
		int y = temp%10000;
		int x = temp/10000;
		int nx,ny;
		for(k = 0; k < 4; k++)
		{
			nx = x + dX[k]; ny = y + dY[k];
			if(nx > 0 && nx <= N && ny > 0 && ny <= M)
				if(a[nx][ny] == -2) 
				{
					a[nx][ny] = a[x][y] + 1;
					push(nx,ny);
				}
				else if(a[nx][ny] == -1) 
				{
					count++;
					if(count == 4)
					{
						a[nx][ny] = a[x][y];
						//push(nx,ny);
					}
				}
		}

	}
	return ;
}

int findMax()
{
	int i,j;
	int temp = 0;
	for(i = 1; i <= N; i++)
		for(j = 1; j <= M; j++)
		{
			if(a[i][j] == -2)
				return -1;
			if(a[i][j] >= temp)
				temp = a[i][j];
		}
	return temp;
}

int main(void)
{
	int tc, T;
	int i,j;

	//freopen("input.txt", "r", stdin);

	//setbuf(stdout, NULL);
	scanf("%d", &T);

	for(tc = 0; tc < T; tc++)
	{
		scanf("%d",&N);
		scanf("%d",&M);
		scanf("%d%d",&xStart, &yStart);
		for(i = 1; i <= N; i++)
		{
			for(j = 1; j <= M; j++)
			{
				scanf("%d", &a[i][j]);
				if(a[i][j] == 1)
					a[i][j] = -2;
				else if(a[i][j] == 2)
				{
					xS = i; yS = j;
					a[i][j] = -1;
				}
			}
		}
		
		a[xStart][yStart] = 1;
		BFS(xStart,yStart);
		Answer1 = a[xS][yS];
		if(Answer1 == -1)
			Answer2 = -1;
		else Answer2 = findMax();
		printf("Case #%d\n", tc+1);
		printf("%d %d\n",Answer1,Answer2);
	}

	return 0;//Your program should return 0 on normal termination.
}
