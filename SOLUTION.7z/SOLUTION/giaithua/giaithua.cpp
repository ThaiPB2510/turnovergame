#include<iostream>
#include<conio.h>
using namespace std;
int N;
int Giaithua(int N)
	{
		if(N < 2) 
			return 1;
		else
			return N*Giaithua(N-1);
	}
int main()
{
	cout <<"Nhap gia tri tu ban phim"<<endl;
	cin >> N;
	cout << Giaithua(N) << endl;
	getch();
	return 0;
}