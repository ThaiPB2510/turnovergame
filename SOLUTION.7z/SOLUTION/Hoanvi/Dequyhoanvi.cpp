#include<iostream>
#include<conio.h>
using namespace std;
int N;
int visit[11];
int b[11];
int m[11] = {0,1,2,3,4,5,6,7,8,9,10};

void Sinhhoanvi(int b[], int k, int sum)
	{
		int i;
		if(sum > 10)
			return;
		if(sum == 10)
		{
			for(int j = 1; j < k; j++)
				cout << b[j] << " ";
			cout << endl;
		}
		else
			for(i = 1; i <= 10; i++)
			{
				if(visit[m[i]] == 0)
				{
					b[k] = m[i];
					visit[m[i]] = 1;
					Sinhhoanvi(b,k+1,sum + b[k]);
					visit[m[i]] = 0;
				}
			}
	}
int main()
{
	for(int i = 1; i <= 10; i++)
		visit[i] = 0;	

	Sinhhoanvi(b,1,0);
	getch();
	return 0;
}