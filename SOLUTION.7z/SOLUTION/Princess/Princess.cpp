// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include <stdio.h>
#include <iostream>
#include<conio.h>

using namespace std;
int Map[201][201];
int xQueue[40005];
int yQueue[40005];
int front, rear;
int dX[4] = {-1, 0, 0, 1};
int dY[4] = {0, 1, -1, 0};
int N;
int visit[201][201] = {0};
void ResetQueue()
{
	rear = 0;
	front = 0;
}
int isEmpty()
{
	if(front == rear)
		return 1;
	else 
		return 0;
}
void push(int x, int y)
{
	xQueue[rear] = x;
	yQueue[rear++] = y;
}
int popX()
{
	return xQueue[front];
}
int popY()
{
	return yQueue[front++];
}
void BFS(int xstart, int ystart)
{
	int x, y, k, xx, yy;
	push(xstart, ystart);
	while(isEmpty() != 1)
	{
		x = popX();
		y = popY();
		for(int k = 0; k < 4; k++)
		{
			xx = x + dX[k];
			yy = y + dY[k];
			if(xx >= 0 && xx < N && yy >= 0 && yy < N)
			{
				if(Map[xx][yy] == 1 && visit[xx][yy] == 0)
				{
					visit[xx][yy] = visit[x][y] + 1;
					push(xx,yy);
				}
			}
		}
	}
}
int main(int argc, char** argv)
{
	int tc, T;	
	// The freopen function below opens input.txt file in read only mode, and afterward,
	// the program will read from input.txt file instead of standard(keyboard) input.
	// To test your program, you may save input data in input.txt file,
	// and use freopen function to read from the file when using cin function.
	// You may remove the comment symbols(//) in the below statement and use it.
	// Use #include<cstdio> or #include<stdio.h> to use the function in your program.
	// But before submission, you must remove the freopen function or rewrite comment symbols(//).

	freopen("input.txt", "r", stdin);

	cin >> T;
	for(tc = 0; tc < T; tc++)
	{
		cin >> N;
		for(int i = 0; i < N; i++)
			for(int j = 0; j < N; j++)
				cin >> Map[i][j];
		int m = 0, n = 0;
		int Answer = 0;
		for(int i = 0; i < N; i++)
		{
			for(int j = 0; j < N; j++)
			{
				if(Map[i][j] == 2)
				{
					m = i; 
					n = j;
				}
			}
		}
		BFS(m,n);
		if(visit[0][0] > 0 && visit[N-1][N-1] > 0)
			Answer = visit[0][0] + visit[N-1][N-1];
		else
			Answer = -1;
		cout << Answer << endl;
		ResetQueue();
		for(int i = 0; i < 201; i++)
			for(int j = 0; j < 201; j++)
				visit[i][j] = 0; 


		/**********************************
		*  Implement your algorithm here. *
		***********************************/

		// Print the answer to standard output(screen).
		
	}
	getch();
	return 0;//Your program should return 0 on normal termination.
}
