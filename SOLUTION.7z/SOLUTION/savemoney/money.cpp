#include<iostream>
using namespace std;
int T, exChange, leng, maxValue;
char numberArr[9];
int visit[11][1000009];

void doChange(int ex, char* numArr) {
	int value = 0;
	for (int l = 0; l < leng; l++) {
		value = value * 10 + numArr[l] - 48;
	}

	if (ex == 0) {
		if (value > maxValue) {
			maxValue = value;
		}
		//cout << "Max Value: " << maxValue << endl;
	}
	else {
		char c, numTemp[9];
		for (int i = 0; i < leng - 1; i++) {
			for (int j = i + 1; j < leng; j++) {
				if (i != j) {
					for (int n = 0; n < leng; n++) {
						numTemp[n] = numArr[n];
					}

					c = numTemp[i];
					numTemp[i] = numTemp[j];
					numTemp[j] = c;

					/*for (int k = 0; k < leng; k++) {
						cout << numTemp[k];
					}
					cout << " " << ex << endl;*/

					value = 0;
					for (int l = 0; l < leng; l++) {
						value = value * 10 + numTemp[l] - 48;
					}
					if (visit[ex][value] == 0) {
						visit[ex][value] = 1;
						doChange(ex - 1, numTemp);
					}
					

				}
			}
		}
	}
}

int main() {
	ios::sync_with_stdio(false);
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	cin >> T;
	for (int tc = 1; tc <= T; tc++) {
		cin >> numberArr;
		cin >> exChange;

		leng = 0;
		while (numberArr[leng] != '\0') {
			leng++;
		}
		maxValue = -1;

		int maxReset = 1;
		for (int i = 0; i < leng; i++) {
			maxReset = maxReset * 10;
		}

		for (int i = 0; i < exChange; i++) {
			for (int j = 0; j < maxReset; j++) {
				visit[i][j] = 0;
			}
		}
		/*char c, numTemp[9];
		for (int i = 0; i < leng - 1; i++) {
			for (int j = i+1; j < leng; j++) {
				if (i != j) {
					for (int n = 0; n < leng; n++) {
						numTemp[n] = numberArr[n];
					}

					c = numTemp[i];
					numTemp[i] = numTemp[j];
					numTemp[j] = c;

					for (int k = 0; k < leng; k++) {
						cout << numTemp[k];
					}
					cout << endl;
				}
			}
		}*/
		doChange(exChange, numberArr);

		cout << "Case #" << tc << endl << maxValue << endl;
	}
	return 0;
}