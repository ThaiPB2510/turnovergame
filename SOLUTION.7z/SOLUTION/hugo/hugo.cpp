﻿// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include<iostream>

using namespace std;
int N, M;

int main(int argc, char** argv)
{
	int test_case;
	int T;
	int Answer;
	int xstart, ystart;
	int F, W, O;
	int a, b;
	int mapTC[16][16];
	int mapKC[16][16];
	
	ios::sync_with_stdio(false);
	
	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/

	freopen("input.txt", "r", stdin);
	cin >> T;

	/*
	   Read each test case from standard input.
	*/
	for(test_case = 1; test_case <= T; ++test_case)
	{
		cin >> N >> M >> xstart >> ystart;
		for(int i = 1; i <= N; i++)
			for(int j = 1; j <= M; j++)
				mapTC[i][j] = 0;
		mapTC[xstart][ystart] = 1;
		cin >> F;
		for(int i = 1; i <= F; i++)
		{
			cin >> a >> b;
			mapTC[a][b] = -1;
		}
		cin >> W;
		for(int i = 1; i <= W; i++)
		{
			cin >> a >> b;
			mapTC[a][b] = 2;
		}
		cin >> O;
		for(int i = 1; i <= O; i++)
		{
			cin >> a >> b;
			mapTC[a][b] = 3;
		}
		for(int i = 1; i <= N; i++)
			for(int j = 1; j <= M; j++)
				cin >> mapKC[i][j];





		/////////////////////////////////////////////////////////////////////////////////////////////
		/*
			Please, implement your algorithm from this section.
		*/
		/////////////////////////////////////////////////////////////////////////////////////////////


		// Print the answer to standard output(screen).
		cout << "#" << test_case << " " << Answer << endl;
	}
	return 0;//Your program should return 0 on normal termination.
}


#include<iostream>
using namespace std;
const int MAXNM = 20;

int T, N, M, SR, SC;
int numStartFire, numLake, numExit;
int mapWater[MAXNM][MAXNM], mapExit[MAXNM][MAXNM], matrixFire[MAXNM][MAXNM], visitHugo[MAXNM][MAXNM], diamond[MAXNM][MAXNM];
int queueX[MAXNM*MAXNM], queueY[MAXNM*MAXNM], front, rear;
int dx[4] = { 0,0,1,-1 };
int dy[4] = { 1,-1,0,0 };
int anwser;
int hasResult;

void BFSFire() {
	while (front != rear) {
		int xCur = queueX[front];
		int yCur = queueY[front++];
		for (int m = 0; m < 4; m++) {
			int xNext = xCur + dx[m];
			int yNext = yCur + dy[m];
			if (1 <= xNext && xNext <= N && 1 <= yNext && yNext <= M) {
				if (matrixFire[xNext][yNext] == 0) {
					if (mapWater[xNext][yNext] != 1) {
						queueX[rear] = xNext;
						queueY[rear++] = yNext;
						matrixFire[xNext][yNext] = matrixFire[xCur][yCur] + 1;
					}
				}
			}
		}
	}
}

void hugoGo(int curX, int curY, int curDiamon) {
	if (mapExit[curX][curY] == 1) {//gặp cổng ra
		anwser = curDiamon > anwser ? curDiamon : anwser;
		hasResult = 1;
	}

	for (int m = 0; m < 4; m++) {
		int xNext = curX + dx[m];
		int yNext = curY + dy[m];
		if (1 <= xNext && xNext <= N && 1 <= yNext && yNext <= M) {
			if (visitHugo[xNext][yNext] == 0) {

				if (mapWater[xNext][yNext] == 1) {//gặp nước
					visitHugo[xNext][yNext] = visitHugo[curX][curY] + 2;
					hugoGo(xNext, yNext, curDiamon + diamond[xNext][yNext]);
					visitHugo[xNext][yNext] = 0;
				}
				else {//gặp ô đất trống
					if ((visitHugo[curX][curY] < matrixFire[xNext][yNext] - 1) || (matrixFire[xNext][yNext] == 0)) {//Lửachưa lan tới hoặc ko lan được tới
						visitHugo[xNext][yNext] = visitHugo[curX][curY] + 1;
						hugoGo(xNext, yNext, curDiamon + diamond[xNext][yNext]);
						visitHugo[xNext][yNext] = 0;
					}
				}

			}
		}
	}
}


int main() {
	ios::sync_with_stdio(false);
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	cin >> T;
	for (int tc = 1; tc <= T; tc++) {
		cin >> N >> M;


		//format data
		front = rear = 0;
		for (int i = 1; i <= N; i++) {
			for (int j = 1; j <= M; j++) {
				mapWater[i][j] = mapExit[i][j] = matrixFire[i][j] = visitHugo[i][j] = diamond[i][j] = 0;
			}
		}
		anwser = 0;
		hasResult = 0;

		//read input
		cin >> SR >> SC;
		visitHugo[SR][SC] = 1;

		int x, y;
		cin >> numStartFire;
		for (int i = 1; i <= numStartFire; i++) {
			cin >> x >> y;
			queueX[rear] = x;
			queueY[rear++] = y;
			matrixFire[x][y] = 1;//vị trí cháy bắt đầu
		}

		cin >> numLake;
		for (int i = 1; i <= numLake; i++) {
			cin >> x >> y;
			mapWater[x][y] = 1; //vị trí hồ nước
		}

		cin >> numExit;
		for (int i = 1; i <= numExit; i++) {
			cin >> x >> y;
			mapExit[x][y] = 1; // vị trí lối ra
		}


		for (int i = 1; i <= N; i++) {
			for (int j = 1; j <= M; j++) {
				cin >> diamond[i][j];
			}
		}

		BFSFire();

		hugoGo(SR, SC, diamond[SR][SC]);

		cout << "Case #" << tc << endl;
		if (hasResult) {
			cout << anwser;
		}
		else {
			cout << -1;
		}
		cout << endl;
	}
	return 0;
}


//anh cong

#include <stdio.h>
int N,M,xHugo,yHugo;
long MAX;
int C,H,L,KC;
long Lua[60][60];
int Lua2[60][2];
int LT[60][60];
int Ho[60][60];
long KimCuong[60][60];
int visit[60][60];
int check[60][60];

//Khai bao Queue
int dX[4] = {-1,1,0,0};
int dY[4] = {0,0,1,-1};

void Loang(int x,int y)
{
	int i,j,k;
	for(k = 0; k < 4; k++)
	{
			i = x + dX[k]; j = y + dY[k];
			if(i > 0 && i <= N && j > 0 && j <= M)
				if(Lua[i][j] > Lua[x][y]+1 && Ho[i][j] == 0 && check[i][j] == 0)
				{
					Lua[i][j] = Lua[x][y]+1;
					check[i][j] == 1;
					Loang(i,j);
					check[i][j] == 0;
				}
	}
}

void Try(int x,int y,int t,long sum)
{
		int i,j,k;
		// Neu ma chua chet o o hien tai, o hien tai laf loi thoat thif cap nhat ket qua
		if(LT[x][y])
		{
			if(sum > MAX) MAX = sum;
			//return;   // khong return vi Hugo co the di qua nhieu hon 1 loi ra
		}
		visit[x][y] = 1;
		//Nhay den 4 o xung quang
		for(k = 0; k < 4; k++)
		{
			i = x + dX[k]; j = y + dY[k];
			if(i > 0 && i <= N && j > 0 && j <= M)
				if(visit[i][j] == 0 && Lua[i][j] > t+1)
				{		
					if(Ho[i][j]==1)
						Try(i,j,t+2, sum + KimCuong[i][j]);
					else
						Try(i,j,t+1, sum + KimCuong[i][j]);
					visit[i][j] = 0;
				}
		}
		visit[x][y] = 0;
		return;
}

int main(void)
{
	int test_case;
	int T;
	int Answer;
	int i,j,u,v;

	// freopen("input.txt", "r", stdin);

	setbuf(stdout, NULL);
	scanf("%d", &T);

	for (test_case = 1; test_case <= T; ++test_case)
	{
		scanf("%d%d%d%d",&N, &M, &xHugo, &yHugo);
		scanf("%d", &C);
		for(i = 1; i <= N; i++)
			for(j = 1; j <= M; j++)
			{
				Lua[i][j] = 10000000;
				Ho[i][j] = 0;
				LT[i][j] = 0;
				check[i][j] = 0;
				visit[i][j] = 0;
			}
		for(i = 1; i <= C; i++)
		{
			scanf("%d%d", &u,&v);
			Lua[u][v] = 1;
			Lua2[i][0] = u; Lua2[i][1] = v;
		}
		scanf("%d", &H);
		for(i = 1; i <= H; i++)
		{
			scanf("%d%d", &u,&v);
			Ho[u][v] = 1;
		}
		scanf("%d", &L);
		for(i = 1; i <= L; i++)
		{
			scanf("%d%d", &u,&v);
			LT[u][v] = 1;
		}
		for(i = 1; i <= N; i++)
			for(j = 1; j <= M; j++)
				scanf("%d", &KimCuong[i][j]);

		//Loang ma tran lua
		for(i = 1; i <= C; i++)
			//BFS(Lua2[i], Lua2[i+C]);
				Loang(Lua2[i][0], Lua2[i][1]);
		MAX = -1;
		Try(xHugo,yHugo,1, KimCuong[xHugo][yHugo]);

		printf("Case #%d\n", test_case);
		printf("%d\n", MAX);
	}
	return 0; //Your program should return 0 on normal termination.
}
