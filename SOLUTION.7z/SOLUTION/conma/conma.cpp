#include <stdio.h>
#include<iostream>
#include<conio.h>

using namespace std;

int a[1001][1001];
int N,M;
int xStart,yStart,xEnd,yEnd;
int dX[8] = {-1,-2,-2,-1,1,2,2,1};
int dY[8] = {-2,-1,1,2,2,1,-1,-2};
int xQueue[1000000],yQueue[1000000];
long front,  rear;

void ResetQueue()
{
	rear = 0; front = 0;
}

int isEmpty()
{
	if(front == rear)
		return 1;
	else return 0;
}

void push(int x, int y)
{
	xQueue[rear] = x;
	yQueue[rear] = y;
	rear++;
}

int popX()
{
	return xQueue[front];
}

int popY()
{
	return yQueue[front++];
}

void BFS(int xStart, int yStart)
{
	int x,y,k,xx,yy;
	push(xStart,yStart);
	while(isEmpty() != 1)
	{
		x = popX();
		y = popY();
		for(k = 0; k < 8; k++)
		{
			xx = x + dX[k];
			yy = y + dY[k];
			if(xx > 0 && xx <= N && yy > 0 && yy < N)
			{
				a[xx][yy] = a[x][y] + 1;
				if(xx == xEnd && yy == yEnd)
					return;
				push(xx,yy);
			}
		}
	}
}

int main(void)
{
	int test_case;
	int T;
	int i,j,k;

	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	setbuf(stdout, NULL);
	scanf("%d", &T);
	for (test_case = 1; test_case <= T; ++test_case)
	{

		scanf("%d%d", &N, &M);
		scanf("%d%d%d%d", &xStart, &yStart, &xEnd, &yEnd);

		for(i = 1; i <= N; i++)
			for(j = 1; j <= M; j++)
				a[i][j] = -1;

		a[xStart][yStart] = 0;
		ResetQueue();
		BFS(xStart, yStart);
		printf("Case #%d\n", test_case);
		printf("%d\n",a[xEnd][yEnd]);
	}
	getch();
	return 0; //Your program should return 0 on normal termination.
}