// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include<iostream>
#include<conio.h>

using namespace std;

int test_case;
int T;
int M;
int Arr[30][30];
int visit[30];
int Answer;

bool check(int dinh, int i)
{
	for(int j = 0; j < M; j++)
		if(Arr[dinh][j] == 1 && i == visit[j])
			return false;
	return true;
}

void dequy(int dinh)
{
	if(dinh == M)
	{
		Answer++;
	}
	else
	{
		for(int i = 1; i <= 4; i++)
		{
			if(check(dinh,i))
			{
				visit[dinh] = i;
				dequy(dinh+1);
				visit[dinh] = 0;
			}
		}
	}
}

int main(int argc, char** argv)
{
	
	
	
	ios::sync_with_stdio(false);
	
	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/

	freopen("input.txt", "r", stdin);
	cin >> T;

	/*
	   Read each test case from standard input.
	*/
	for(test_case = 1; test_case <= T; ++test_case)
	{
		cin >> M;
		for(int i = 0; i < M; i++)
			for(int j = 0; j < M; j++)
			{
				cin >> Arr[i][j];
				visit[j] = 0
			}
		Answer = 0;
		dequy(0);
		/////////////////////////////////////////////////////////////////////////////////////////////
		/*
			Please, implement your algorithm from this section.
		*/
		/////////////////////////////////////////////////////////////////////////////////////////////


		// Print the answer to standard output(screen).
		cout << "#" << test_case << " " << Answer << endl;
	}
	getch();
	return 0;//Your program should return 0 on normal termination.
}