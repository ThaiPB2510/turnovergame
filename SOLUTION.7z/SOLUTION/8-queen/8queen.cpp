	// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include<iostream>
#include<conio.h>

using namespace std;

int test_case;
int T;
int Answer;
int N;
int L;
int Map[8][8];
int Queen[8];
int minsum;
bool check(int x, int y)
{
	int temp = 0;
	for(int i = 0; i < x; i++)
	{
		temp = Queen[i];
		if(temp == y)
			return false;
		if(x - i - y + temp == 0 || x - i + y - temp == 0)
			return false;
	}
	return true;
}

void dequy(int row, int sum)
	{
		if(row == 8){
			{
				if(sum > minsum)
					minsum = sum;
			}
			return;
		}
		for(int i = 0; i < 8; i++)
		{
			if(check(row, i))
			{
				Queen[row] = i;
				dequy(row + 1, sum + Map[row][i]);
			}
		}
	}

int main(int argc, char** argv)
{
	ios::sync_with_stdio(false);
	
	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/

	freopen("input.txt", "r", stdin);
	cin >> T;

	/*
	   Read each test case from standard input.
	*/
	for(test_case = 1; test_case <= T; ++test_case)
	{
		cin >> N;
		cout << "Case #" << test_case << endl;
		for(L = 0; L < N; L++)
		{
			Answer = 0;
			for(int i = 0; i < 8; i++)
				for(int j = 0; j < 8; j++)
					cin >> Map[i][j];
			minsum = 0;
			dequy(0,0);
			cout << minsum << endl;	
		}
	}
	getch();
	return 0;//Your program should return 0 on normal termination.
}