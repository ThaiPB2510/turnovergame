// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include <stdio.h>

int N;
int pos[15], m[15];
double result;

double abs(double a, double b) {
	if (a > b) {
		return a - b;
	}
	else {
		return b - a;
	}
}

int isEqual(int st, int en, double p) {
	double a = m[st] / ((p - pos[st]) * (p - pos[st]));
	double b = m[en] / ((p - pos[en]) * (p - pos[en]));

	//if (a == b) {
	if (abs(a, b) <= 0.000000001) {
		return 0;
	}
	else if (a < b) {
		return -1;
	}
	else {
		return 1;
	}
}

double searchPos(int st, int en, double left, double right) {
	double center = (left + right) / 2;

	int check = isEqual(st, en, center);
	if (check == 0) {
		return center;
	}
	else if (check == 1) {
		return searchPos(st, en, center, right);
	}
	else {
		return searchPos(st, en, left, center);
	}
}

int main() {
	ios::sync_with_stdio(false);
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	for (int tc = 1; tc <= 10; tc++) {
		//cin >> N;
		scanf("%d", &N);
		for (int i = 1; i <= N; i++) {
			//cin >> pos[i];
			scanf("%d", &pos[i]);
		}
		for (int i = 1; i <= N; i++) {
			//cin >> m[i];
			scanf("%d", &m[i]);
		}

		//int a = isEqual(1, 2, 1.4142135624);
		
		//cout << "#" << tc << " ";
		printf("#%d ", tc);
		for (int i = 1; i < N; i++) {
			result = searchPos(i, i+1, pos[i], pos[i+1]);
			printf("%0.10lf ", result);
		}
		//cout << endl;
		printf("\n");
	}
	return 0;
}