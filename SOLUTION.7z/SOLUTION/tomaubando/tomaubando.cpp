#include <stdio.h>
int graph[1001][1001];
int N,E;
int color[1001];
int visit[1001];
int count;
int Answer;
//0 Do 1 Xanh
int check(int k, int mau){
	int i,j;
	for (i = 1; i <= graph[k][0]; i++){
		if (color[graph[k][i]] == mau)
					return 0;
	}
	return 1;
}

void Try(int dinh, int mau)
{
	int i, next;
	visit[dinh] = 1;
	for(i = 1; i <= graph[dinh][0]; i++)
	{
		next = graph[dinh][i];
		if(!visit[next] && check(next,1-mau))
		{
			color[next] = 1 - mau;
			count++;
			Try(next, 1-mau);
		}
	}
}

int main (){
	//freopen ("input.txt", "r", stdin);
	int T,test_case;
	int i,j,u,v;
	scanf("%d", &T);
	for (test_case = 0; test_case < T; test_case++){
		scanf("%d%d", &N,&E);
		for(i = 1; i <= N; i++)
		{
			visit[i] = 0;
			color[i] = -1;
			for(j = 0; j <= N; j++)
				graph[i][j] = 0;
		}
		for (i = 1; i <= E; i++){
			scanf("%d%d", &u,&v);
			graph[u][++graph[u][0]] = v;
			graph[v][++graph[v][0]] = u;
		}
		count = 1;
		color[1] = 0;
		Try(1,0);
		printf("#%d ", test_case+1);
		if(count == N)
			for(i = 1; i <= N; i++)
				printf("%d", color[i]);
		else printf("%d", -1);
		printf("\n");
		
	}
	return 0;
}
