// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include <stdio.h>
#include <iostream>

using namespace std;
int visit[100];
int maTranKe[100][100];
int maTranCanh[100][100]; // luu gia tri cua moi thanh tri
bool hasCycle = false;
int parent[100];
int minEdge, startMinedge, endMinedge;
void findMinEdge(int currentV, int stopV)
{
	if(currentV == stopV)
		return;
	else
	{
		if(maTranCanh[currentV][parent[currentV]] < minEdge)
		{
			minEdge = maTranCanh[currentV][parent[currentV]];
			startMinedge = currentV;
			endMinedge = parent[currentV];
		}
		findMinEdge(parent[currentV], stopV);
	}
}
void DFS_Recursive(int currentV)
{
	
	visit[currentV] = 1;
	for(int nextV = 0; nextV < 100; nextV++)
	{
		if((visit[nextV] == 0) && (maTranKe[currentV][nextV] == 1))
		{
			parent[nextV] = currentV;
			DFS_Recursive(nextV);
		}
		else if( nextV != parent[currentV])
		{
			minEdge = maTranCanh[currentV][nextV];
			startMinedge = currentV;
			endMinedge = nextV;
			hasCycle = true;
			findMinEdge(currentV, nextV);
		}
	}
}


int main(int argc, char** argv)
{
	int tc, T;
	int M;
	int a[100],b[100],c[100];
	int Map[100][100];
	
	// The freopen function below opens input.txt file in read only mode, and afterward,
	// the program will read from input.txt file instead of standard(keyboard) input.
	// To test your program, you may save input data in input.txt file,
	// and use freopen function to read from the file when using cin function.
	// You may remove the comment symbols(//) in the below statement and use it.
	// Use #include<cstdio> or #include<stdio.h> to use the function in your program.
	// But before submission, you must remove the freopen function or rewrite comment symbols(//).

	// freopen("input.txt", "r", stdin);

	cin >> T;
	for(tc = 0; tc < T; tc++)
	{
		
		cin >> M;
		for(int i = 0; i < M; i++)
		{
			cin >> a[i];
			cin >> b[i]; 
			cin >> c[i];
			for(int j = 0; j < c[i]; j++)
				cin >> Map[i][j];
		}

		/**********************************
		*  Implement your algorithm here. *
		***********************************/

		// Print the answer to standard output(screen).
		
	}

	return 0;//Your program should return 0 on normal termination.
}
