#include <iostream>
using namespace std;

const int MAXN = 209;
const unsigned int MAX_VAL = ~0;
int MAX_VALUE, T, N, data[MAXN][3], d[MAXN][MAXN], selected[MAXN], distan[MAXN], cnt;
void formatData() {
	for (int i=1; i<=N; i++) {
		selected[i] = distan[i] = 0;
		for (int j=1; j<=N; j++) {
			d[i][j] = 0;
		}
	}
}
bool nhay_gan(int x, int y, int xNext, int yNext, int r1, int r2) {
	if ((x - xNext) * (x - xNext) + (y - yNext) * (y - yNext) <= (r1 + r2 + 40) * (r1 + r2 + 40)) {
		return true;
	} else {
		return false;
	}
}

bool nhay_xa(int x, int y, int xNext, int yNext, int r1, int r2) {
	if ((x - xNext) * (x - xNext) + (y - yNext) * (y - yNext) <= (r1 + r2 + 90)	* (r1 + r2 + 90)) {
		return true;
	} else {
		return false;
	}
}
int main() {
	ios::sync_with_stdio(false);
	//freopen("input.txt", "r", stdin);
	MAX_VALUE = MAX_VAL >> 1;
	cin>>T;
	for (int tc=1; tc<=T; tc++) {
		cin>>N;
		formatData();
		for (int i=1; i<=N; i++) {
			cin>>data[i][0]>>data[i][1]>>data[i][2];
		}

		for (int i=1; i<=N; i++) {
			for (int j=i+1; j<=N; j++) {
				if (nhay_gan(data[i][0], data[i][1], data[j][0], data[j][1], data[i][2], data[j][2])) {
					d[i][j] = d[j][i] = 1;
				} else if (nhay_xa(data[i][0], data[i][1], data[j][0], data[j][1], data[i][2], data[j][2])) {
					d[i][j] = d[j][i] = 1000;
				} else {
					d[i][j] = d[j][i] = MAX_VALUE;
				}
			}
		}
		selected[1] = 1;
		cnt = 1;
		for (int i=1; i<=N; i++) {
			distan[i] = d[1][i];
		}
		while (cnt != N) {
			int w=0, dmin = MAX_VALUE;
			for (int i=1; i<=N; i++) {
				if (distan[i] <= dmin && selected[i] == 0) {
					dmin = distan[i];
					w = i;
				}
			}
			
			selected[w] = 1;
			cnt++;
			for (int j=1; j<=N; j++) {
				int d1 = d[w][j] == MAX_VALUE || d[w][j] + distan[w] < 0 ? MAX_VALUE : d[w][j] + distan[w];
				distan[j] = min(distan[j], d1);
			}
		}
		//cout<<"Case #"<<tc<<endl;
		if (distan[N] == MAX_VALUE) {
			cout<<"-1"<<endl;
		} else {
			cout<<distan[N]/1000<<" "<<distan[N]%1000<<endl;
		}
	}
}
// DiJkstra

    #include <stdio.h>
    
    int N;
    int X[201], Y[201], R[201];
    int visit[201];
    int parent[201];
    long long d[201];
    int xa, gan;
    
    int distance(int i, int j)
    {
        int ret = 0;
        long long dis = (X[i]-X[j])*(X[i]-X[j]) + (Y[i]-Y[j])*(Y[i]-Y[j]);
        long long a = (R[i] + R[j] + 40)*(R[i] + R[j] + 40);
        long long b = (R[i] + R[j] + 90)*(R[i] + R[j] + 90);
        if(dis <= a)
            ret = 1;
        else if(dis <= b)
            ret = 1000;
        else 
            ret = 1000000;
        return ret;
    }
    
    int main(void)
    {
        int tc, T;
        int i,j;
        
        //freopen("input.txt", "r", stdin);
    
        setbuf(stdout, NULL);
        scanf("%d", &T);
    
        for(tc = 0; tc < T; tc++)
        {
            scanf("%d", &N);
            for(i = 1; i <= N; i++)
            {
                scanf("%d%d%d", &X[i], &Y[i], &R[i]);
                visit[i] = 0;
                d[i] = 1000000001;
                parent[i] = -1;
            }
            d[1] = 0;
            while(!visit[N])
            {
                int m;
                long long temp = 1000000000;
                //1: Find vertex which minimum value
                for(i = 1; i <= N; i++)
                    if(visit[i] != 1 && d[i] <= temp)
                    {
                        temp = d[i];
                        m = i;
                    }
                //2: Update value
                visit[m] = 1;
                for(i = 1; i <= N; i++)
                {
                    if(visit[i] != 1)
                    {
                        temp = d[m] + distance(m,i);
                        if(temp < d[i])
                            d[i] = temp;
                    }
                }
            }	
            //Get result
            if(d[N] >= 1000000) 
                printf("%d\n", -1);
            else 
            {
                gan = d[N]%1000; xa = d[N]/1000;
                printf("%d %d\n",xa, gan);
            }
    
        }
    
        return 0;//Your program should return 0 on normal termination.
    }
