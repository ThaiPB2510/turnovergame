// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include<iostream>
#include<conio.h>

using namespace std;
int N;
int visit[100];
int d[100][100];
int Answer;

void DFS_Recursive(int x)
{
	if(x == 99)
	{
		Answer = 1;
		return;
	} 
	else 
	{
		visit[x] = 1;
		for(int i = 0; i < 100; i++)
		{
			if((visit[i] == 0) && (d[x][i] > 0) && Answer == 0)
			DFS_Recursive(i);
		}
	}
}

int main(int argc, char** argv)
{
	int test_case;
	int T;
	
	int a,b;
	ios::sync_with_stdio(false);
	
	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/

	freopen("input.txt", "r", stdin);


	/*
	   Read each test case from standard input.
	*/
	for(test_case = 1; test_case <= 10; ++test_case)
	{
		cin >> T;
		cin >> N;

		for(int i = 0; i < 100; i++)
			for(int j = 0; j < 100; j++)
				d[i][j] = 0;

		for(int i = 0; i < N; i++)
		{
			cin>>a;
			cin>>b;
			d[a][b] = 1;
		}
		
		for(int i = 0; i < 100; i++)
			visit[i] = 0;
		Answer = 0;
		
		
		DFS_Recursive(0);
	

		/////////////////////////////////////////////////////////////////////////////////////////////
		/*
			Please, implement your algorithm from this section.
		*/
		/////////////////////////////////////////////////////////////////////////////////////////////


		// Print the answer to standard output(screen).
		cout << "#" << test_case << " " << Answer << endl;
	}
	getch();
	return 0;//Your program should return 0 on normal termination.
}