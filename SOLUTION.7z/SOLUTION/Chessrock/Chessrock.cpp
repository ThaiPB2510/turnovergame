// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include<iostream>
#include<conio.h>

using namespace std;

int test_case;
int T;
int Answer;
int M;
char Arr[4][4];
int visit[4][4];
int sum;

bool check(int x, int y)
{
	int a = 1, b = 1, c= 1, d= 1;
	for(int k = 1; x - k >= 0; k++)
	{
		if(visit[x-k][y] == -1)
		{
			a = 1;
			break;
		}
		if(visit[x-k][y] == 1)
		{
			a = 0;
			break;
		}
	}
	for(int k = 1; x + k < M; k++)
	{
		if(visit[x+k][y] == -1)
		{
			b = 1;
			break;
		}
		if(visit[x+k][y] == 1)
		{
			b = 0;
			break;
		}		
	}
	for(int k = 1; y - k >= 0; k++)
	{
		if(visit[x][y - k] == -1)
		{
			c = 1;
			break;
		}
		if(visit[x][y - k] == 1)
		{
			c = 0;
			break;
		}
	}
	for(int k = 1; y + k < M; k++)
	{
		if(visit[x][y + k] == -1)
		{
			d = 1;
			break;
		}
		if(visit[x][y + k] == 1)
		{
			d = 0;
			break;
		}
	}
	if(a == 1 && b ==1 && c == 1 && d ==1)
		return true;
	return false;
}

void dequy(int sumvong)
{
	for(int i = 0; i < M; i++)
	{
		for(int j = 0; j < M; j++)
		{
			if( visit[i][j] == 0)
			{
				if(check(i,j))
				{
					visit[i][j] = 1;
					dequy(sumvong + 1);
					visit[i][j] = 0;
				}
			}
		}
	}

	if(sum < sumvong)
		sum = sumvong;
}

int main(int argc, char** argv)
{
	int test_case;
	int T;
	int Answer;
	char Arr[4][4];
	ios::sync_with_stdio(false);
	
	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/

	freopen("input.txt", "r", stdin);
	cin >> T;

	/*
	   Read each test case from standard input.
	*/
	for(test_case = 1; test_case <= T; ++test_case)
	{
		cin >> M;
		for(int i = 0; i < M; i++)
			for(int j = 0; j < M; j++)
				cin >> Arr[i][j];
		Answer = 0;
		for(int i = 0; i < M; i++)
		{
			for(int j = 0; j < M; j++)
			{ 
				if(Arr[i][j] == 'X')
					visit[i][j] = -1;
				else
					visit[i][j] = 0;
			}
		}
		sum = 0;
		dequy(0);
		
		

		/////////////////////////////////////////////////////////////////////////////////////////////
		/*
			Please, implement your algorithm from this section.
		*/
		/////////////////////////////////////////////////////////////////////////////////////////////


		// Print the answer to standard output(screen).
		cout << "Case #" << test_case << endl;
		cout << sum << endl;
	}
	getch();
	return 0;//Your program should return 0 on normal termination.
}