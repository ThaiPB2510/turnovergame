// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include<iostream>

using namespace std;
int test_case;
int T;
int N, M;
long a[101][101];
long b[101][101];
long c[101][101];
void Matrix(long aa[101][101],long bb[101][101], long cc[101][101])
{
	int i,j,k;
	for(i = 1; i <= N; i++)
		for(j = 1; j <= N; j++)
		{
			cc[i][j] = 0;
			for(k = 1; k <= N; k++)
			{
				cc[i][j] += aa[i][k]*bb[k][j];
				cc[i][j] = cc[i][j]%100000007;
			}
		}
}

void Recursive_power(long cc[101][101], int m)
{
	int i,j;
	long temp[101][101];
	if(m == 1) 
	{
		for(i = 1; i <= N; i++)
			for(j = 1; j <= N; j++)
				cc[i][j] = a[i][j];
	}
	else
	{
		if(m%2 == 0)
		{
			Recursive_power(temp , m/2);
			Matrix(temp,temp,cc);
		}
		else
		{
			Recursive_power(temp , m/2);
			Matrix(temp,temp,cc);
			for(i = 1; i <= N; i++)
				for(j = 1; j <= N; j++)
					temp[i][j] = cc[i][j];
			Matrix(temp,a,cc);
		}

	}
}

int main(int argc, char** argv)
{
	
		
	ios::sync_with_stdio(false);
	
	/* 
	The freopen function below opens input.txt in read only mode and 
	sets your standard input to work with the opened file. 
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/

	freopen("input.txt", "r", stdin);
	cin >> T;

	/*
	   Read each test case from standard input.
	*/
	for(test_case = 1; test_case <= T; ++test_case)
	{
		cin >> N;
		cin >> M;
		for(int i = 1; i <= N; i++)
			for(int j = 1; j <= N; j++)
				cin >> a[i][j];
		Recursive_power(c,M);
		cout << "Case #" << test_case << endl;
		for(int i = 1; i <= N; i++)
		{
			for(int j = 1; j <= N; j++)
				cout << c[i][j] << " " ;
			cout << endl;
		}
	}
	return 0;//Your program should return 0 on normal termination.
}