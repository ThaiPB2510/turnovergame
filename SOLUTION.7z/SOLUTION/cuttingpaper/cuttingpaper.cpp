// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include <stdio.h>

int a[201][201];
int N;
int xanh, trang;

int kiemtra(int x, int y, int len, int k)
{
	int i,j,result = 0;
	int temp = a[x][y];
	for(i = x; i < x+len; i++)
		for(j = y; j < y+len; j++)
			if(a[i][j] != temp) result++;
			else return result;
	return result;
}

void dem(int x, int y, int len)
{
	int i,j,sum;
	sum  = kiemtra(x,y,len,a[x][y]);
	if(sum == len*len)
	{
		if(a[x][y] == 0) trang++;
		else xanh++;
	}
	else
	{
		len = len/2;
		dem(x,y,len);
		dem(x,y+len,len);
		dem(x+len,y,len);
		dem(x+len,y+len,len);
	}
}

int main(void)
{
	int test_case;
	int T;
	//freopen("input.txt", "r", stdin);

	setbuf(stdout, NULL);
	scanf("%d", &T);
	int i,j;

	for (test_case = 1; test_case <= T; ++test_case)
	{
		xanh = 0;
		trang = 0;
		scanf("%d", &N);
		for(i = 1; i <= N; i++)
			for(j = 1; j <= N; j++)
				scanf("%d", &a[i][j]);

		dem(1,1,N);
		printf("Case #%d\n", test_case);
		printf("%d %d\n", trang, xanh);
	}
	return 0; //Your program should return 0 on normal termination.
}