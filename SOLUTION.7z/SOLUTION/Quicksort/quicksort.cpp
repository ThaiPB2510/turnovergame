int arr[100000];
int N;
void quickSort(int left, int right)
{
	int center = arr[(left + right)/2];
	int i = left, j = right;
	while(i < right || left < j)
	{
		while(arr[i] < center) i++;
		while(arr[j] > center) j--;
		if(i <= j)
		{
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			i++;
			j--;
		}
		else
		{
			if(i < right) quickSort(i,right);
			if(left < j) quickSort(left,j);
			return;
		}
	}
}
int main()
{
	quickSort(0, N-1);
}