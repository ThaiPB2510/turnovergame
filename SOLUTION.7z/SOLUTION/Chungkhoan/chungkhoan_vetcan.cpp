// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <iostream>
#include<conio.h>

using namespace std;

int main(int argc, char** argv)
{
	int tc, T;
	int N, K[30];
	
	// The freopen function below opens input.txt file in read only mode, and afterward,
	// the program will read from input.txt file instead of standard(keyboard) input.
	// To test your program, you may save input data in input.txt file,
	// and use freopen function to read from the file when using cin function.
	// You may remove the comment symbols(//) in the below statement and use it.
	// Use #include<cstdio> or #include<stdio.h> to use the function in your program.
	// But before submission, you must remove the freopen function or rewrite comment symbols(//).

	 freopen("input.txt", "r", stdin);

	cin >> T;
	for(tc = 1; tc <= T; tc++)
	{
		cin >> N;
		for(int i= 0; i < N; i++)
			cin >> K[i];
		int Answer = 0;
		for(int chay = 0; chay < 50; chay++)
		{
			int max = 0; 
			for(int i = 0; i < N; i++)
			{
				if(K[max] < K[i])
				max = i;
			}
			if(max > 0)
				{
					for(int k = 0; k < max; k++ )
					{
						if(K[k] > 0)
							Answer = Answer + K[max] - K[k];
							K[k] = 0;
					}
					K[max] = 0;
				}
				else 
					K[max] = 0;
			if(max == N)
			break;
		}
		cout << "#"<<tc<<" "<<Answer<<endl;
	}
	

		/**********************************
		*  Implement your algorithm here. *
		***********************************/

		// Print the answer to standard output(screen).
		
	
	getch();
	return 0;//Your program should return 0 on normal termination.
}
