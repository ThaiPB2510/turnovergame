#include<iostream>
#include<stdio.h>
using namespace std;

int T, K, N, arr[100009], minSum, maxSum, result;

int isOk(int sumValue) {
	int k = 0, sum = 0;
	for (int i = 0; i < N; i++) {
		if (sum + arr[i] > sumValue) {
			sum = arr[i];
			k++;
			if (k == K && i < N) {
				return 1;
			}
		}
		else {
			sum += arr[i];
		}
	}
	return 0;

}

int searchSum(int left, int right) {
	if (right - left <= 1) {
		if (isOk(left) == 0) {
			return left;
		}
		else if (isOk(right) == 0) {
			return right;
		}
	}

	int center = (left + right) / 2;
	int checkSum = isOk(center);
	if (checkSum == 0) {
		return searchSum(left, center - 1);
	}
	else {
		return searchSum(center + 1, right);
	}
}


int main() {
	ios::sync_with_stdio(false);
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	cin >> T;
	for (int tc = 1; tc <= T; tc++) {
		cin >> K >> N;
		minSum = 0;
		maxSum = 0;
		for (int i = 0; i < N; i++) {
			cin >> arr[i];
			minSum = arr[i] > minSum ? arr[i] : minSum;
			maxSum += arr[i];
		}

		result = searchSum(minSum, maxSum);
		cout << "#" << tc << " " << result << endl;
	}


	return 0;
}